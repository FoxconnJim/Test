//
//  JZHomePageViewController.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZHomePageViewController.h"
#import "JZHomePageSection.h"

#import "JZFamilyIconView.h"
#import "JZWeatherView.h"
#import "JZNewsCell.h"
#import "JZTodayRemindCell.h"

#import "CoreLocation/CoreLocation.h"

#import "JZTodayRemindViewController.h"
#import "JZTodayRecommendViewController.h"
#import "JZjinrituijianViewController.h"
#import "JZFamilyInfo.h"
#import "JZOperation.h"
#import "JZHotNews.h"

#import "MJRefresh.h"
#import "UIImageView+WebCache.h"
#import "JZWeatherModel.h"

#import "JZSoundTools.h"
#import "JZSelectProvinceTableViewController.h"
#import "NSString+JZChineseToPinyin.h"
#import "XMLReader.h"

#import "LCProgressHUD.h"

@interface JZHomePageViewController () <CLLocationManagerDelegate, JZLocationDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, JZOperationDelegate, UITableViewDelegate, UITableViewDataSource, UIViewControllerPreviewingDelegate>

@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) JZWeatherView *weatherView;
@property (nonatomic, strong) JZLocation *locationInfo;

@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) NSMutableArray *personInfoArray;
@property (nonatomic, strong) NSMutableArray *remindNewsArray;
@property (nonatomic, strong) NSMutableArray *remindCellHeightArray;
@property (nonatomic, strong) NSMutableArray *hotNewsArray;
@property (nonatomic, copy) NSString *currentCityName;
@property (nonatomic, copy) NSString *currentProvinceName;

@property (nonatomic) BOOL isGetFamilyMemberEndRefresh;
@property (nonatomic) BOOL isAddressEndRefresh;
@property (nonatomic) BOOL isTodayRemindEndRefresh;
@property (nonatomic) BOOL isTodayRecommendEndRefresh;

@end

@implementation JZHomePageViewController

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (UIView *)bgView
{
    if (!_bgView) {
        _bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 114 + weatherInfoHeight + screenEdgeMargin * 2 + 40 * 2)];
        _bgView.backgroundColor = barBackgroundColor;

    }
    return _bgView;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame: CGRectMake(0, 0, screenW, screenH)];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.backgroundColor = [UIColor clearColor];
        _tbView.showsVerticalScrollIndicator = NO;
    }
    return _tbView;
}

- (JZFamilyIconView *)familyIconView
{
    if (!_familyIconView) {
        _familyIconView = [[JZFamilyIconView alloc] initWithFrame: CGRectMake(0, 0, screenW, 114)];
    }

    return _familyIconView;
}


- (JZWeatherView *)weatherView
{
    if (!_weatherView) {
        _weatherView = [[JZWeatherView alloc] initWithFrame:  CGRectMake(0, screenEdgeMargin, screenW, weatherInfoHeight)];
        [_weatherView.location addTarget:self action:@selector(getCityList:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _weatherView;
}

- (void)getCityList:(UIButton *)btn
{
    NSLog(@"%s", __FUNCTION__);
    JZSelectProvinceTableViewController *selectProvinceTBVC = [[JZSelectProvinceTableViewController alloc] init];
    [self.navigationController pushViewController:selectProvinceTBVC animated:YES];
}

- (JZHomePageSection *)todayRemindSection
{
    if (!_todayRemindSection) {
        _todayRemindSection = [[JZHomePageSection alloc] initWithFrame:CGRectMake(0, 0, screenW, 40)];
        _todayRemindSection.title.text = @"今日提醒";
        _todayRemindSection.content.text = @"";
        [_todayRemindSection.btn addTarget: self action:@selector(clickHistoryRemind) forControlEvents:UIControlEventTouchUpInside];
    }

    return _todayRemindSection;
}


- (JZHomePageSection *)todayRecommendSection
{
    if (!_todayRecommendSection) {
        _todayRecommendSection = [[JZHomePageSection alloc] initWithFrame:CGRectMake(0, 0, screenW, 40)];
        _todayRecommendSection.title.text = @"今日推荐";
        _todayRecommendSection.content.text = @"";
        [_todayRecommendSection.btn addTarget: self action:@selector(clickMoreRecommend) forControlEvents:UIControlEventTouchUpInside];
    }

    return _todayRecommendSection;
}

- (NSOperationQueue *)queue
{
    if (_queue == nil) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (NSMutableArray *)personInfoArray
{
    if (!_personInfoArray) {
        _personInfoArray = [NSMutableArray array];
    }
    return _personInfoArray;
}

- (NSMutableArray *)remindNewsArray
{
    if (!_remindNewsArray) {
        _remindNewsArray = [NSMutableArray array];
    }
    return _remindNewsArray;
}

- (NSMutableArray *)remindCellHeightArray
{
    if (!_remindCellHeightArray) {
        _remindCellHeightArray = [NSMutableArray array];
    }
    return _remindCellHeightArray;
}

- (NSMutableArray *)hotNewsArray
{
    if (!_hotNewsArray) {
        _hotNewsArray = [NSMutableArray array];
    }
    return _hotNewsArray;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *colorType = @"白";
    [colorType storeValueByKey:JZRefreshColor];
    [self.view addSubview:self.bgView];
    [self.view addSubview:self.tbView];
    NSString *isLocation = [NSString valueByKey:kIsLocation];
    if (!isLocation) {
        [@"isLocation" storeValueByKey:kIsLocation];
    }
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {

        JZPersonInfo *personInfo = [[JZPersonInfo alloc] init];
        personInfo.nickname = @"游客";
        [self.personInfoArray removeAllObjects];
        [self.personInfoArray addObject:personInfo];
        self.familyIconView.personInfoArray = self.personInfoArray;
        JZHomePageIconView *icon = [self.familyIconView.personArray firstObject];
        icon.isSelected = YES;
        [icon.btn addTarget:self action:@selector(clickToSelectPersonIcon:) forControlEvents:UIControlEventTouchUpInside];
        [personInfo storeValueByKey:kCurrentFamilyMemberInfo];
        self.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock: ^{
            self.isAddressEndRefresh = NO;
            self.isTodayRecommendEndRefresh = NO;

            [self getWeatherInfo];
            [self getTodayRecommendInfo];
        }];
    } else {
        self.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock: ^{
            self.isAddressEndRefresh = NO;
            self.isTodayRecommendEndRefresh = NO;
            self.isGetFamilyMemberEndRefresh = NO;
            self.isTodayRemindEndRefresh = NO;

            [self getFamilyIcon];
            [self getWeatherInfo];
            [self getTodayRemindInfo];
            [self getTodayRecommendInfo];
        }];

        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTodayRecommendInfo) name:cancelshoucangNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTodayRecommendInfo) name:shoucangNotification object:nil];
    }

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateLocalCity) name:selectLocalCityNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateSelectedCity) name:updateSelectedCityNotification object:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];
    if (refreshInfo.canHomeRefresh) {
        [self.tbView.mj_header beginRefreshing];
        refreshInfo.canHomeRefresh = NO;
        [refreshInfo storeValueByKey:kRefreshInfo];
    } else {
//        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
//            [self getTodayRecommendInfo];
//            [self getWeatherInfo];
//        } else {
//            [self getTodayRecommendInfo];
//            [self getWeatherInfo];
//            [self getFamilyIcon];
//            [self getTodayRemindInfo];
//        }
    }
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    NSString *colorType = @"灰";
    [colorType storeValueByKey:JZRefreshColor];
    
}

- (void)getFamilyIcon
{
    //        设置参数
    NSMutableDictionary *param = [NSMutableDictionary dictionary];

    if([[[JZFamilyInfo valueByKey: kFamilyInfo] account] rangeOfString:@"@"].location != NSNotFound) {

        param[@"mail"] = [[JZFamilyInfo valueByKey: kFamilyInfo] mail];

    } else {

        param[@"tel"] = [[JZFamilyInfo valueByKey: kFamilyInfo] tel];
    }

    //        获取成员信息
    JZOperation *operation = [JZOperation operationWithURLString:findAllFamilyMembersURL andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
    operation.name = findAllFamilyMembersOperation;
}

- (JZLocation *)locationInfo
{
    if (!_locationInfo) {
        _locationInfo = [[JZLocation alloc] init];
        _locationInfo.delegate = self;
    }
    return _locationInfo;
}

- (void)getWeatherInfo
{
    NSString *isLocation = [NSString valueByKey:kIsLocation];
    NSLog(@"isLocation = %@", isLocation);
    NSMutableDictionary *cityListParam = [NSMutableDictionary dictionary];
    cityListParam[@"key"] = JZMobAppKey;
    JZOperation *operation = [JZOperation operationWithURLString:cityListURL andParam:cityListParam getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = getCityOperation;
    if (![isLocation isEqualToString:@"isLocation"]) {
        [self updateSelectedCity];
    } else {
        [self.locationInfo getLocation];
    }

}

- (void)getTodayRemindInfo
{
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"tel"] = [[JZFamilyInfo valueByKey: kFamilyInfo] tel];
    JZOperation *operation = [JZOperation operationWithURLString:todayRemindURL andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
    operation.name = todayRemindOperation;
}

- (void)getTodayRecommendInfo
{
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"tel"] = [[JZFamilyInfo valueByKey: kFamilyInfo] tel];
    param[@"numbers"] = @"10";
    JZOperation *operation = [JZOperation operationWithURLString:todayrecommendURL andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
    operation.name = todayRecommendOperation;
}

- (void)updateLocalCity
{
    [@"isLocation" storeValueByKey:kIsLocation];
    [self getWeatherInfo];
}

- (void)updateSelectedCity
{
    [self.weatherView.tips startAnimating];
    [@"isNotLocation" storeValueByKey:kIsLocation];
    NSMutableDictionary *weatherParam = [NSMutableDictionary valueByKey:kSelectedAddressDict];
    if (!weatherParam) {
        weatherParam[@"key"] = JZMobAppKey;
        weatherParam[@"city"] = @"深圳";
        weatherParam[@"province"] = @"广东";
        [weatherParam storeValueByKey:kSelectedAddressDict];
    }
    [self.weatherView.location setTitle:[NSString stringWithFormat:@"%@▾", weatherParam[@"city"]] forState:UIControlStateNormal];
    JZOperation *operation = [JZOperation operationWithURLString:weatherURL andParam:weatherParam getOrPost:JZ_GET];
    operation.name = getWeatherOperation;
    operation.delegate = self;
}

#pragma mark JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    if ([operation.name isEqualToString:findAllFamilyMembersOperation]) {
        if ([responseObject[@"data"] isKindOfClass:[NSArray class]]) {
            NSArray *arr = responseObject[@"data"];
            [self.personInfoArray removeAllObjects];
            for (int i = 0; i < arr.count; i++) {
                JZPersonInfo *personInfo = [JZPersonInfo personInfoWithDict:arr[i]];
                personInfo.tag = i;

                [self.personInfoArray addObject: personInfo];
            }
            //            存储家庭信息
            self.familyIconView.personInfoArray = self.personInfoArray;
            for (int i = 0; i < self.familyIconView.personArray.count; i++) {
                JZHomePageIconView *icon = self.familyIconView.personArray[i];
                [icon.btn addTarget:self action:@selector(clickToSelectPersonIcon:) forControlEvents:UIControlEventTouchUpInside];
            }

            if (self.familyIconView.personArray.count) {
                JZPersonInfo *currentMember = [JZPersonInfo valueByKey:kCurrentFamilyMemberInfo];
                if (currentMember.tag == 100) {
                    JZHomePageIconView *icon = [self.familyIconView.personArray firstObject];
                    icon.isSelected = YES;
                    JZPersonInfo *personInfo = [self.personInfoArray firstObject];
                    [personInfo storeValueByKey:kCurrentFamilyMemberInfo];
                } else {
                    if (currentMember.tag < self.familyIconView.personArray.count) {
                        JZPersonInfo *personInfo = [JZPersonInfo valueByKey:kCurrentFamilyMemberInfo];
                        JZHomePageIconView *icon = self.familyIconView.personArray[personInfo.tag];
                        icon.isSelected = YES;
                        [self.personInfoArray[personInfo.tag] storeValueByKey:kCurrentFamilyMemberInfo];
                    } else {
                        JZHomePageIconView *icon = [self.familyIconView.personArray firstObject];
                        icon.isSelected = YES;
                        JZPersonInfo *personInfo = [self.personInfoArray firstObject];
                        [personInfo storeValueByKey:kCurrentFamilyMemberInfo];
                    }
                }

            }
        }
        [self.personInfoArray storeValueByKey: kAllFamilyMembersInfo];
        self.isGetFamilyMemberEndRefresh = YES;
    } else if ([operation.name isEqualToString: todayRemindOperation]) {
        if ([[NSString valueByKey:kVisitors] isEqualToString:@"users"]) {
            if ([responseObject[@"data"] isKindOfClass:[NSArray class]]) {
                NSArray *arr = responseObject[@"data"];
                [self.remindNewsArray removeAllObjects];
                [self.remindCellHeightArray removeAllObjects];
                NSInteger remindArrayCount = 0;
                if (arr.count >= 2) {
                    remindArrayCount = 2;
                } else {
                    remindArrayCount = arr.count;
                }
                for (int i = 0; i < remindArrayCount; i++) {
                    JZTodayRemindData *todayRemindData = [JZTodayRemindData todayRemindDataWithDict:arr[i]];
                    todayRemindData.tag = i;
                    [self.remindNewsArray addObject:todayRemindData];
                    CGSize size = [todayRemindData.remindContent textSizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(screenW - 100, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping];
                    NSNumber *cellHeight = [NSNumber numberWithFloat:size.height + 50];
                    [self.remindCellHeightArray addObject:cellHeight];
                }
            }
        }
        self.isTodayRemindEndRefresh = YES;
    } else if ([operation.name isEqualToString: todayRecommendOperation]) {
        if ([responseObject[@"data"] isKindOfClass:[NSArray class]]) {
            NSArray *arr = responseObject[@"data"];
            NSLog(@"arr = %@", arr);
            [self.hotNewsArray removeAllObjects];
            for (int i = 0; i < arr.count; i++) {
                JZHotNews *hotNews = [JZHotNews hotNewsWithDictionary:arr[i]];
                hotNews.tag = i;
                [self.hotNewsArray addObject: hotNews];
            }
        }
        self.isTodayRecommendEndRefresh = YES;
    } else if ([operation.name isEqualToString:getWeatherOperation]) {

        NSDictionary *dict = (NSDictionary *)responseObject;
        NSString *msg = dict[@"msg"];
        if ([msg isEqualToString:@"success"]) {

            NSArray *weatherArray = dict[@"result"];
            NSDictionary *weatherDict = [weatherArray firstObject];
            JZWeatherModel *weatherModel = [JZWeatherModel weatherModelWithDict:weatherDict];
            self.weatherView.weatherModel = weatherModel;
        } else {
            self.weatherView.weatherModel = nil;
            [LCProgressHUD showFailure:@"网络有点卡..."];
        }
    } else if ([operation.name isEqualToString:getCityOperation]) {
        NSDictionary *cityListDict = (NSDictionary *)responseObject;
        [cityListDict storeValueByKey:kCityListDict];
        if ([cityListDict isKindOfClass:[NSDictionary class]]) {
            [[NSNotificationCenter defaultCenter] postNotificationName:updateCityListNotification object:nil userInfo:cityListDict];
            self.isAddressEndRefresh = YES;
        }
    }
    [self.tbView reloadData];
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        [self.tbView.mj_header endRefreshing];

    } else {
        if (self.isTodayRecommendEndRefresh && self.isAddressEndRefresh && self.isGetFamilyMemberEndRefresh && self.isTodayRemindEndRefresh) {
            [self.tbView.mj_header endRefreshing];
        }
    }

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [self.tbView.mj_header endRefreshing];
        if ([operation.name isEqualToString:getWeatherOperation]) {
            self.weatherView.weatherModel = nil;
            [LCProgressHUD showFailure:@"网络有点卡..."];
        }
    } else {
        [self.tbView.mj_header endRefreshing];
    }

}

#pragma mark UITableViewDataSource Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        return 2;

    } else {
        return 3;

    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        switch (section) {
            case 0:
                return 2;
                break;
            case 1:
                return self.hotNewsArray.count;
                
            default:
                return 0;
                break;
        }
    } else {
        switch (section) {
            case 0:
                return 2;

                break;
            case 1:
                return self.remindNewsArray.count;

            case 2:
                return self.hotNewsArray.count;

            default:
                return 0;
                break;
        }
    }


}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    if (indexPath.section == 0) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.backgroundColor = appBackgroundColor;
        if (indexPath.row == 0) {
            [cell addSubview: self.familyIconView];
            cell.backgroundColor = barBackgroundColor;
        } else {
            [cell addSubview: self.weatherView];
            cell.backgroundColor = barBackgroundColor;
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.separatorInset = UIEdgeInsetsMake(0, screenW, 0, 0);
        return cell;

    } else if (indexPath.section == 1) {
        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            JZNewsCell *cell = [JZNewsCell cellWithTableView: tableView];
            JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
            cell.hotNews = hotNews;
            [cell.imgView sd_setImageWithURL:[NSURL URLWithString: hotNews.newsFront] placeholderImage:[UIImage imageNamed: @"资讯"]];
            if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
                [self registerForPreviewingWithDelegate:self sourceView:cell];
            }
            return cell;

        } else {
            JZTodayRemindCell *cell = [JZTodayRemindCell cellWithTableView:tableView cellID:@"JZHomePageViewController-cellID"];
            NSNumber *cellHeight = self.remindCellHeightArray[indexPath.row];
            JZTodayRemindData *remindNews = self.remindNewsArray[indexPath.row];
            cell.cellHeight = cellHeight.floatValue;
            cell.todayRemindData = remindNews;
            [cell.imgView sd_setImageWithURL:[NSURL URLWithString: remindNews.picture] placeholderImage:[UIImage imageNamed: @"默认"]];
            if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
                [self registerForPreviewingWithDelegate:self sourceView:cell];
            }
            return cell;

        }
    } else if (indexPath.section == 2) {
        JZNewsCell *cell = [JZNewsCell cellWithTableView: tableView];
        JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
        cell.hotNews = hotNews;
        [cell.imgView sd_setImageWithURL:[NSURL URLWithString: hotNews.newsFront] placeholderImage:[UIImage imageNamed: @"资讯"]];
        if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
            [self registerForPreviewingWithDelegate:self sourceView:cell];
        }
        return cell;
    } else {
        return 0;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {

        if (indexPath.row == 0) {

            return 114;

        } else {

            return weatherInfoHeight + screenEdgeMargin * 2;

        }

    } else if (indexPath.section == 1) {
        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            return newsRowHeight;
        } else {
            NSNumber *cellHeight = self.remindCellHeightArray[indexPath.row];
            if (indexPath.row == self.remindNewsArray.count - 1) {
                return cellHeight.floatValue - 10;
            } else {
                return cellHeight.floatValue;
            }
        }

    } else if (indexPath.section == 2) {

        return newsRowHeight;
    } else {
        return 0;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0;
    } else {
        return 40;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        return self.todayRecommendSection;
    } else {
        if (section == 1) {
            return self.todayRemindSection;
        } else {
            return self.todayRecommendSection;
        }
    }

}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    if (section == 2) {
        return tabBarHeight + naviHeight + statusBarHeight;

    } else {
        return 0;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, tabBarHeight + naviHeight + statusBarHeight)];
    if (section == 2) {
        return view;

    } else {
        return nil;
    }
}

#pragma mark UITableViewDelegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        if (indexPath.section == 1) {
            JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
            JZjinrituijianViewController *jrtjVC = [[JZjinrituijianViewController alloc] init];
            jrtjVC.hotNews = hotNews;
            [self.tabBarController.navigationController pushViewController:jrtjVC animated:YES];
        }
    } else {
        if (indexPath.section == 2) {
            JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
            JZjinrituijianViewController *jrtjVC = [[JZjinrituijianViewController alloc] init];
            jrtjVC.hotNews = hotNews;
            [self.tabBarController.navigationController pushViewController:jrtjVC animated:YES];
        }
    }

    [tableView deselectRowAtIndexPath: indexPath animated:YES];
}

- (void)clickHistoryRemind
{
    JZTodayRemindViewController *todayRemindVC = [[JZTodayRemindViewController alloc] init];
    [self.navigationController pushViewController:todayRemindVC animated:YES];

}

- (void)clickMoreRecommend
{
    JZTodayRecommendViewController *todayRecommendVC = [[JZTodayRecommendViewController alloc] init];
    [self.navigationController pushViewController:todayRecommendVC animated:YES];

}

- (void)clickToSelectPersonIcon:(UIButton *)button
{
    [[JZSoundTools sharedJZSoundTools] playSoundWithName:@"shortWater.wav"];
    if (![[JZFamilyInfo valueByKey:kFamilyInfo] account]) {

    }
//    JZPersonInfo *personInfo = self.personInfoArray[button.tag];
//    [personInfo storeValueByKey: kCurrentFamilyMemberInfo];

    for (JZHomePageIconView *icon in self.familyIconView.personArray) {
        if (icon.btn.tag == button.tag) {
            icon.isSelected = YES;
        } else {
            icon.isSelected = NO;
        }
    }

    [[NSUserDefaults standardUserDefaults] setInteger: button.tag forKey:kSelectIndex];
    [[NSUserDefaults standardUserDefaults] synchronize];

//    if (![JZPersonInfo valueByKey: kCurrentFamilyMemberInfo]) {
//
//        JZPersonInfo *personInfo = self.personInfoArray[button.tag];
//        [personInfo storeValueByKey: kCurrentFamilyMemberInfo];
//    }
    JZPersonInfo *personInfo = self.personInfoArray[button.tag];
    [personInfo storeValueByKey: kCurrentFamilyMemberInfo];
}


#pragma mark JZLocationDelegate Mehtods
- (void)locationFailWithMessage:(NSString *)failMessage
{
    if ([[NSString valueByKey:kIsLocation] isEqualToString:@"isLocation"]) {

        [LCProgressHUD showInfoMsg:failMessage];
        if ([UIApplication sharedApplication].keyWindow.rootViewController == self.navigationController) {
            self.weatherView.weatherModel = nil;
            [self.weatherView.weatherInfo addSubview:self.weatherView.nullcity];
            [self.weatherView.tips stopAnimating];
        } else {
            [self performSelector:@selector(locationOff) withObject:nil afterDelay:0.5];
        }
    }
    NSMutableDictionary *localAddressDict = [NSMutableDictionary dictionary];
    localAddressDict[@"key"] = JZMobAppKey;
    localAddressDict[@"city"] = @"";
    localAddressDict[@"province"] = @"";
    [localAddressDict storeValueByKey:kLocalAddressDict];

    [[NSNotificationCenter defaultCenter] postNotificationName:updateLocalCityNotification object:nil userInfo:localAddressDict];
}

- (void)locationOff
{
    if ([[NSString valueByKey:kIsLocation] isEqualToString:@"isLocation"]) {

        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"定位不成功，请确认开启定位" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction: okAction];
        if ([UIApplication sharedApplication].keyWindow.rootViewController == self.navigationController) {
            [self presentViewController: alertController animated:YES completion:^{
                if (!self.weatherView.weather.text.length) {
                    [self.weatherView.weatherInfo addSubview:self.weatherView.nullcity];

                }
                [self.weatherView.tips stopAnimating];

            }];
        } else {
            [self performSelector:@selector(locationOff) withObject:nil afterDelay:0.5];
        }
    }
    NSMutableDictionary *localAddressDict = [NSMutableDictionary dictionary];
    localAddressDict[@"key"] = JZMobAppKey;
    localAddressDict[@"city"] = @"";
    localAddressDict[@"province"] = @"";
    [localAddressDict storeValueByKey:kLocalAddressDict];


    [[NSNotificationCenter defaultCenter] postNotificationName:updateLocalCityNotification object:nil userInfo:localAddressDict];
}

- (void)locationUnvaliable
{
    if ([[NSString valueByKey:kIsLocation] isEqualToString:@"isLocation"]) {

        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"定位功能不可用" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction: okAction];
        if ([UIApplication sharedApplication].keyWindow.rootViewController == self.navigationController) {
            [self presentViewController: alertController animated:YES completion:^{
                if (!self.weatherView.weather.text.length) {
                    [self.weatherView.weatherInfo addSubview:self.weatherView.nullcity];

                }
                [self.weatherView.tips stopAnimating];
            }];
        } else {
            [self performSelector:@selector(locationOff) withObject:nil afterDelay:0.5];
        }
    }
    NSMutableDictionary *localAddressDict = [NSMutableDictionary dictionary];
    localAddressDict[@"key"] = JZMobAppKey;
    localAddressDict[@"city"] = @"";
    localAddressDict[@"province"] = @"";
    [localAddressDict storeValueByKey:kLocalAddressDict];

    [[NSNotificationCenter defaultCenter] postNotificationName:updateLocalCityNotification object:nil userInfo:localAddressDict];
}

- (void)locationInfoWithProvince:(NSString *)province city:(NSString *)city
{
    if ([[province substringFromIndex:province.length - 1] isEqualToString:@"省"]) {
        self.currentProvinceName = [province substringToIndex:province.length - 1];
    } else {
        self.currentProvinceName = province;
    }

    if ([[city substringFromIndex:city.length - 1] isEqualToString:@"市"]) {
        self.currentCityName = [city substringToIndex:city.length - 1];
    } else {
        self.currentCityName = city;
    }

    NSMutableDictionary *localAddressDict = [NSMutableDictionary dictionary];
    localAddressDict[@"key"] = JZMobAppKey;
    localAddressDict[@"city"] = self.currentCityName;
    localAddressDict[@"province"] = self.currentProvinceName;
    [localAddressDict storeValueByKey:kLocalAddressDict];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:updateLocalCityNotification object:nil userInfo:localAddressDict];
    
    NSString *isLocation = [NSString valueByKey:kIsLocation];
    if ([isLocation isEqualToString:@"isLocation"]) {
        NSMutableDictionary *weatherParam = [NSMutableDictionary dictionary];
        weatherParam[@"key"] = JZMobAppKey;
        weatherParam[@"city"] = self.currentCityName;
        weatherParam[@"province"] = self.currentProvinceName;
        [self.weatherView.location setTitle:[NSString stringWithFormat:@"%@▾", self.currentCityName] forState:UIControlStateNormal];
        JZOperation *operation = [JZOperation operationWithURLString:weatherURL andParam:weatherParam getOrPost:JZ_GET];
        operation.delegate = self;
        operation.name = getWeatherOperation;
    }
}

#pragma mark UIViewControllerPreviewingDelegate Methods
//peek(预览)
- (nullable UIViewController *)previewingContext:(id<UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location
{
    //获取按压的cell所在行， [previewingContext sourceView]就是按压的那个视图
    NSIndexPath *indexPath = [self.tbView indexPathForCell:(UITableViewCell *)[previewingContext sourceView]];

    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        if (indexPath.section == 1) {
            //设定预览的界面
            JZjinrituijianViewController *childVC = [[JZjinrituijianViewController alloc] init];
            childVC.preferredContentSize = CGSizeMake(0.f, 500.f);
            childVC.title = @"今日推荐";
            JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
            childVC.hotNews = hotNews;

            //调整不被虚化的范围，按压的那个cell不被虚化（轻轻按压时周边会被虚化，再稍用力展示预览，再加力跳页至设定界面)
            CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, newsRowHeight);
            previewingContext.sourceRect = rect;
            
            //返回预览界面
            return childVC;
        } else {
            return nil;
        }
    } else {
        if (indexPath.section == 1) {
            JZTodayRemindViewController *childVC = [[JZTodayRemindViewController alloc] init];
            childVC.preferredContentSize = CGSizeMake(0.f, 500.f);
            childVC.title = @"提醒记录";

            NSNumber *cellHeight = self.remindCellHeightArray[indexPath.row];

            CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, cellHeight.floatValue);
            previewingContext.sourceRect = rect;

            return childVC;
        } else if (indexPath.section == 2) {
            //设定预览的界面
            JZjinrituijianViewController *childVC = [[JZjinrituijianViewController alloc] init];
            childVC.preferredContentSize = CGSizeMake(0.f, 500.f);
            childVC.title = @"今日推荐";
            JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
            childVC.hotNews = hotNews;

            //调整不被虚化的范围，按压的那个cell不被虚化（轻轻按压时周边会被虚化，再稍用力展示预览，再加力跳页至设定界面)
            CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, newsRowHeight);
            previewingContext.sourceRect = rect;

            //返回预览界面
            return childVC;
        } else {
            return nil;
        }
    }

}

//pop (再加力进入)
- (void)previewingContext:(id<UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit
{
    [self showViewController:viewControllerToCommit sender:self];
}
@end




















