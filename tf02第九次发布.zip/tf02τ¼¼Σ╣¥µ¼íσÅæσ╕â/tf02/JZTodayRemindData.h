//
//  JZTodayRemindData.h
//  tf02
//
//  Created by AN PEN on 7/23/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZTodayRemindData : NSObject

@property (nonatomic, copy) NSString *picture;
@property (nonatomic, copy) NSString *nickname;
@property (nonatomic, copy) NSString *remindContent;
@property (nonatomic, copy) NSString *membersname;
@property (nonatomic, copy) NSString *createDate;
@property (nonatomic, assign) NSInteger tag;
@property (nonatomic, copy) NSString *memberId;
@property (nonatomic, copy) NSString *ID;

- (instancetype)initWithDict: (NSDictionary *)dict;
+ (instancetype)todayRemindDataWithDict: (NSDictionary *)dict;
@end
