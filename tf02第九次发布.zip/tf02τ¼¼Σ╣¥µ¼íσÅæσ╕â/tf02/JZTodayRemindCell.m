//
//  JZTodayRemindCell.m
//  tf02
//
//  Created by F7686324 on 10/6/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZTodayRemindCell.h"

@implementation JZTodayRemindCell

- (void)setCellHeight:(CGFloat)cellHeight
{
    _cellHeight = cellHeight;
}

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(margin, margin, margin * 5, margin * 5)];
        _imgView.layer.cornerRadius = margin * 2.5;
        _imgView.layer.masksToBounds = YES;
        [_imgView setImage: [UIImage imageNamed:@"默认"]];
    }
    return _imgView;
}

- (UILabel *)title
{
    if (!_title) {
        _title = [[UILabel alloc] initWithFrame:CGRectMake(margin * 7, 0, screenW - margin * 10, margin * 3)];
        _title.font = [UIFont boldSystemFontOfSize:17];
        _title.textColor = [UIColor colorWithRed:1.00 green:0.49 blue:0.20 alpha:1.00];
    }
    return _title;
}

- (UILabel *)content
{
    if (!_content) {
        _content = [[UILabel alloc] initWithFrame:CGRectMake(margin * 7, margin * 3, screenW - margin * 10, self.cellHeight - margin * 5)];
        _content.textColor = [UIColor grayColor];
        _content.font = [UIFont systemFontOfSize:15];
        _content.numberOfLines = 0;
    }
    return _content;
}

- (void)setShowIndicator:(BOOL)showIndicator
{
    _showIndicator = showIndicator;
    if (showIndicator) {
        self.content.frame = CGRectMake(self.content.frame.origin.x,
                                        self.content.frame.origin.y,
                                        self.content.frame.size.width - margin,
                                        self.content.frame.size.height);
    }
}

- (UIView *)bgView
{
    if (!_bgView) {
        _bgView = [[UIView alloc] initWithFrame: CGRectMake(margin, 0, screenW - margin * 2, self.cellHeight - margin)];
        _bgView.backgroundColor = [UIColor whiteColor];
        _bgView.layer.cornerRadius = 5;
        _bgView.layer.masksToBounds = YES;

        [_bgView addSubview: self.imgView];
        [_bgView addSubview: self.title];
        [_bgView addSubview: self.content];
    }
    return _bgView;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        margin = 10;
        [self addSubview: self.bgView];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.separatorInset = UIEdgeInsetsMake(0, screenW, 0, 0);
    }
    return self;
}

+ (JZTodayRemindCell *)cellWithTableView:(JZRemindTableView *)tableView cellID:(NSString *)cellID
{
    NSString *cellid = cellID;
    JZTodayRemindCell *cell = [tableView dequeueReusableCellWithIdentifier: cellid];
    if (!cell) {
        cell = [[JZTodayRemindCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
        cell.backgroundColor = appBackgroundColor;
    }
    return cell;
}


- (void)setTodayRemindData:(JZTodayRemindData *)todayRemindData
{
    _todayRemindData = todayRemindData;
    [self.bgView removeFromSuperview];
    _content = nil;
    _bgView = nil;
    [self addSubview:self.bgView];

    self.title.text = todayRemindData.membersname;
    self.content.text = todayRemindData.remindContent;
    [self.imgView sd_setImageWithURL: [NSURL URLWithString: todayRemindData.picture] placeholderImage:[UIImage imageNamed: @"默认"]];
}
@end
