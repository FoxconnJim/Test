//
//  JZLineChartView.m
//  tf02
//
//  Created by Jim on 16/3/18.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZLineChartView.h"

@interface JZLineChartView () <UIGestureRecognizerDelegate, UIScrollViewDelegate>
{
    CGFloat jzOffSetX;
    CGFloat scrollOffsetX;
    CGFloat scrollScale;
    CGFloat scaleWidth;
    BOOL isIndicator;
}

@end

@implementation JZLineChartView
@synthesize previousDistance;

- (JZLineChartFrame *)lineChartFrame
{
    if (!_lineChartFrame) {
        _lineChartFrame = [[JZLineChartFrame alloc] initWithFrame: self.frame];
    }
    return _lineChartFrame;
}

- (JZBackgroundLayer *)backgroundLayer
{
    if (!_backgroundLayer) {
        _backgroundLayer = [JZBackgroundLayer layer];
        _backgroundLayer.frame = self.bounds;
    }
    return _backgroundLayer;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame:self.lineChartFrame.titleLabelFrame];
        _titleLabel.font = [UIFont systemFontOfSize: self.lineChartFrame.titleLabelFrame.size.height / 2];
        _titleLabel.textColor = [UIColor whiteColor];
    }
    return _titleLabel;
}

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame:self.lineChartFrame.imgViewFrame];
    }
    return _imgView;
}

- (UILabel *)valueLabel
{
    if (!_valueLabel) {
        _valueLabel = [[UILabel alloc] initWithFrame: self.lineChartFrame.valueLabelFrame];
        _valueLabel.font = [UIFont systemFontOfSize:self.lineChartFrame.valueLabelFrame.size.height - 5];
        _valueLabel.textColor = [UIColor whiteColor];
        _valueLabel.textAlignment = NSTextAlignmentRight;
    }
    return _valueLabel;
}

- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] initWithFrame: self.lineChartFrame.timeLabelFrame];
        _timeLabel.textColor = [UIColor whiteColor];
        _timeLabel.font = [UIFont systemFontOfSize:self.lineChartFrame.timeLabelFrame.size.height];
        _timeLabel.textAlignment = NSTextAlignmentRight;
    }
    return _timeLabel;
}

- (UIView *)topLine
{
    if (!_topLine) {
        _topLine = [[UIView alloc] initWithFrame: self.lineChartFrame.topLineFrame];
        _topLine.backgroundColor = [UIColor whiteColor];
    }
    return _topLine;
}

- (UIView *)bottomLine
{
    if (!_bottomLine) {
        _bottomLine = [[UIView alloc] initWithFrame: self.lineChartFrame.bottomLineFrame];
        _bottomLine.backgroundColor = [UIColor whiteColor];
    }
    return _bottomLine;
}

//- (JZLineChartScaleView *)scaleView
//{
//    if (!_scaleView) {
//        _scaleView = [[JZLineChartScaleView alloc] initWithFrame: self.lineChartFrame.scaleViewFrame];
//    }
//    return _scaleView;
//}

- (JZPadScaleView2017 *)padScaleView
{
    if (!_padScaleView) {
        _padScaleView = [[JZPadScaleView2017 alloc] initWithFrame:self.lineChartFrame.scaleViewFrame];
    }
    return _padScaleView;
}

- (UILabel *)indicatorLabel
{
    if (!_indicatorLabel) {
        _indicatorLabel = [[UILabel alloc] initWithFrame:self.lineChartFrame.indicatorFrame];
        _indicatorLabel.text = @"无数据";
        _indicatorLabel.textAlignment = NSTextAlignmentCenter;
        _indicatorLabel.textColor = [UIColor whiteColor];
    }
    return _indicatorLabel;
}

- (JZLineChartDataView *)dataView
{
    if (!_dataView) {
        _dataView = [[JZLineChartDataView alloc] initWithFrame: self.lineChartFrame.dataViewFrame];
        _dataView.backgroundColor = [UIColor clearColor];
        
    }
    return _dataView;
}

- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame: self.lineChartFrame.scrollViewFrame];
        _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width, _scrollView.frame.size.height);
        [_scrollView addSubview:self.dataView];
//        [_scrollView addSubview:self.scaleView];
//        [_scaleView addSubview:self.padScaleView];
        _scrollView.delegate = self;
    }
    return _scrollView;
}

- (UILabel *)maxValue
{
    if (!_maxValue) {
        _maxValue = [[UILabel alloc] initWithFrame: self.lineChartFrame.maxValueFrame];
        _maxValue.textColor = [UIColor whiteColor];
        _maxValue.font = [UIFont systemFontOfSize: 10];
    }
    return _maxValue;
}

- (UILabel *)minValue
{
    if (!_minValue) {
        _minValue = [[UILabel alloc] initWithFrame: self.lineChartFrame.minValueFrame];
        _minValue.textColor = [UIColor whiteColor];
        _minValue.font = [UIFont systemFontOfSize: 10];
    }
    return _minValue;
}

- (UIView *)lineView
{
    if (!_lineView) {
        _lineView = [[UIView alloc] init];
        _lineView.backgroundColor = [UIColor whiteColor];
    }
    return _lineView;
}

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (NSMutableArray *)bigDataArray
{
    if (!_bigDataArray) {
        _bigDataArray = [NSMutableArray array];
    }
    return _bigDataArray;
}

- (UIPinchGestureRecognizer *)pinchGesture
{
    if (!_pinchGesture) {
        _pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinchGesture:)];
        _pinchGesture.delegate = self;
    }
    return _pinchGesture;
}

- (UIPanGestureRecognizer *)panGesture
{
    if (!_panGesture) {
        _panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
        _panGesture.delegate = self;
    }
    return _panGesture;
}

- (UITapGestureRecognizer *)doubleTapGesture
{
    if (!_doubleTapGesture) {
        _doubleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleDoubleTapGesture:)];
        _doubleTapGesture.delegate = self;
        _doubleTapGesture.numberOfTapsRequired = 2;
    }
    return _doubleTapGesture;
}

- (UITapGestureRecognizer *)singleTapGesture
{
    if (!_singleTapGesture) {
        _singleTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesture:)];
//        _singleTapGesture.delegate = self;
    }
    return _singleTapGesture;
}

- (JZIndicatorView *)indicatorView
{
    if (!_indicatorView) {
        _indicatorView = [[JZIndicatorView alloc] initWithFrame:self.bounds];
    }
    return _indicatorView;
}

- (void)setJzScale:(CGFloat)jzScale
{
    _jzScale = jzScale;
    self.dataView.jzScale = jzScale;
//    self.scaleView.jzScale = jzScale;
    self.padScaleView.jzScale = jzScale;
}

- (void)setJzType:(NSString *)jzType
{
    _jzType = jzType;
}

- (void)setTextArray:(NSMutableArray *)textArray
{
    _textArray = textArray;
    scaleWidth = 0;

    if (textArray) {
        for (NSString *text in self.textArray) {
            CGFloat width = [text getStringWidth];
            if (width > scaleWidth) {
                scaleWidth = width;
            }
        }
        scaleWidth += 20;
    }
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.shadowOffset = CGSizeMake(2, 2);
        self.layer.shadowOpacity = 0.7;
        self.jzScale = 1.f;
        isIndicator = NO;
        scrollScale = 1.f;
        previousDistance = 0;
        scaleWidth = 0;
        [self.layer insertSublayer:self.backgroundLayer atIndex:0];
        [self addSubview:self.scrollView];
        [self addSubview:self.titleLabel];
        [self addSubview:self.imgView];
        [self addSubview:self.valueLabel];
        [self addSubview:self.timeLabel];
        [self addSubview:self.topLine];
        [self addSubview:self.bottomLine];
        [self addSubview:self.indicatorLabel];
        [self addSubview:self.maxValue];
        [self addSubview:self.minValue];

        [self addGestureRecognizer:self.pinchGesture];
//        [self addGestureRecognizer:self.panGesture];
        [self addGestureRecognizer:self.singleTapGesture];
//        [self addGestureRecognizer:self.doubleTapGesture];
//        [self.singleTapGesture requireGestureRecognizerToFail:self.doubleTapGesture];
    }
    return self;
}

- (NSMutableDictionary *)paramWithTimeLengthString:(NSString *)timeLengthString
{
    NSString *endTimeString = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [[dateFormatter dateFromString: endTimeString] localDate];
    NSInteger endTimeInt = [date timeIntervalSince1970] + 24 * 60 * 60;
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:endTimeInt];
    NSDate *staDate;

    if ([timeLengthString isEqualToString:jzDay]) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600];

    } else if ([timeLengthString isEqualToString:jzWeek]) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600 * 7];

    } else if ([timeLengthString isEqualToString:jzMonth]) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600 * 30];

    } else if ([timeLengthString isEqualToString:jzYear]) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600 * 365];

    }
    NSString *endtime = [endDate dateToString];
    NSString *statime = [staDate dateToString];

    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"memberId"] = [[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] memberId];
    param[@"endtime"] = endtime;
    param[@"count"] = @"10000";
    param[@"statime"] = statime;
    return param;
}

- (void)initTimeAndValueWithType:(NSString *)jzType
{
    NSArray *array;
    if ([jzType isEqualToString:@"血压"]) {
        array = [JZFmdbTool queryBloodPressureDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:jzYear];

        if (array.count) {
            self.valueLabel.text = [NSString stringWithFormat:@"%@/%@ mmHg", [[array firstObject] bpSp], [[array firstObject] bpDp]];
        }
    } else if ([jzType isEqualToString:@"心率"]) {
        array = [JZFmdbTool queryHeartRateDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:jzYear];

        if (array.count) {
            self.valueLabel.text = [NSString stringWithFormat:@"%@ BPM", [[array firstObject] data]];
        }
    } else if ([jzType isEqualToString:@"血糖"]) {
        array = [JZFmdbTool queryBloodSugarDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:jzYear];

        if (array.count) {
            self.valueLabel.text = [NSString stringWithFormat:@"%@ mmol/L", [[array firstObject] data]];
        }
    } else if ([jzType isEqualToString:@"体脂"]) {
        array = [JZFmdbTool queryBodyFatDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:jzYear];

        if (array.count) {
            self.valueLabel.text = [NSString stringWithFormat:@"%@%%", [[array firstObject] data]];
        }
    } else if ([jzType isEqualToString:@"体重"]) {
        array = [JZFmdbTool queryWeightDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:jzYear];

        if (array.count) {
            self.valueLabel.text = [NSString stringWithFormat:@"%@ kg", [[array firstObject] data]];
        }
    } else if ([jzType isEqualToString:@"血氧"]) {
        array = [JZFmdbTool queryBloodOxygenDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:jzYear];

        if (array.count) {
            self.valueLabel.text = [NSString stringWithFormat:@"%@%%", [[array firstObject] data]];
        }
    }
    if (array.count) {
        NSInteger timeSpNow = [[[NSDate date] localDate] timeIntervalSince1970];
        NSInteger timeSp = [[[array firstObject] meatime] stringToTimeInteval];

        NSInteger timeScale = timeSpNow  - timeSp;
        NSString *dayString = [[[[array firstObject] meatime] componentsSeparatedByString:@" "] firstObject];
        NSArray *hourArray = [[[[[array firstObject] meatime] componentsSeparatedByString:@" "] lastObject] componentsSeparatedByString:@":"];
        NSString *hourString = [NSString stringWithFormat:@"%@:%@", hourArray[0], hourArray[1]];

        NSDate *endDate = [[NSDate date] localDate];
        NSArray *timeArray = [[[[endDate dateToString] componentsSeparatedByString: @" "] lastObject] componentsSeparatedByString: @":"];
        NSInteger timeDifference = [timeArray[0] integerValue] * 3600 + [timeArray[1] integerValue] * 60 + [timeArray[2] integerValue];

        if (timeScale < timeDifference) {
            dayString = @"今天";
        } else if (timeScale < 3600 * 24 + timeDifference) {
            dayString = @"昨天";
        } else if (timeScale < 3600 * 24 * 2 + timeDifference) {
            dayString = @"前天";
        }
        self.timeLabel.text = [NSString stringWithFormat:@"%@ %@", dayString, hourString];
    } else {
        self.timeLabel.text = @"";
        self.valueLabel.text = @"--";
    }
}

- (void)handlePinchGesture:(UIPinchGestureRecognizer *)pinchGestureRecognizer
{

    if ([pinchGestureRecognizer numberOfTouches] == 2) {
        CGPoint point1 = [pinchGestureRecognizer locationOfTouch:0 inView:self];
        CGPoint point2 = [pinchGestureRecognizer locationOfTouch:1 inView:self];
        if (pinchGestureRecognizer.state == UIGestureRecognizerStateBegan) {

            [self startMovedWithPoint:point1 point2:point2];
        } else if (pinchGestureRecognizer.state == UIGestureRecognizerStateChanged) {

            [self moveRangedWithPoint:point1 point2:point2];
        } else if (pinchGestureRecognizer.state == UIGestureRecognizerStateEnded) {

            [self endMovedWithPoint:point1 point2:point2];
        } else {
            [self endMovedWithPoint:point1 point2:point2];
        }

    }

}

- (void)startMovedWithPoint:(CGPoint)point1 point2:(CGPoint)point2
{
    self.previousDistance = fabs(point1.x - point2.x);
//    [self.scaleView.segment removeFromSuperview];
    [self.padScaleView.segment removeFromSuperview];
    self.dataView.frame = self.dataView.bounds;
    self.padScaleView.frame = CGRectMake(0, self.padScaleView.frame.origin.y, self.padScaleView.frame.size.width, self.padScaleView.frame.size.height);
}

- (void)moveRangedWithPoint:(CGPoint) point1 point2:(CGPoint)point2
{
    //    通过改变两点横坐标的间距值marginX来缩放视图（在Layer上）
    CGFloat currentDistance = fabs(point1.x - point2.x);
    self.jzScale += (currentDistance - self.previousDistance) / 100;
    self.previousDistance = currentDistance;
//    NSLog(@"scrollOffsetX = %f", scrollOffsetX);
//    NSLog(@"jzOffSetX = %f", jzOffSetX);
//    NSLog(@"self.scrollView.contentOffset.x = %f", self.scrollView.contentOffset.x);
    //    控制缩小的限度
    if (self.jzScale < 1.f) {

        scrollOffsetX = 0;
        scrollScale = 1;
        jzOffSetX = 0;
        self.jzScale = 1.f;
    }

    CGFloat width = (point1.x + point2.x) / 2 - self.scrollView.frame.origin.x;
    jzOffSetX = scrollOffsetX * self.jzScale / scrollScale + width * (self.jzScale / scrollScale - 1);

    CGFloat scale = scaleWidth * self.textArray.count / (screenW - screenEdgeMargin * 2 - 10);

    //    控制放大的限度
    if ([[NSUserDefaults standardUserDefaults] integerForKey: kSegmentIndex] == 0) {

        if (self.jzScale >= scale) {
            self.jzScale = scale > 1 ? scale : 1;
        } else {
            self.scrollView.contentOffset = CGPointMake(jzOffSetX, 0);
        }
    } else if ([[NSUserDefaults standardUserDefaults] integerForKey: kSegmentIndex] == 1) {
        if (self.jzScale >= scale) {
            self.jzScale = scale > 1 ? scale : 1;
        } else {
            self.scrollView.contentOffset = CGPointMake(jzOffSetX, 0);
        }
    } else if ([[NSUserDefaults standardUserDefaults] integerForKey: kSegmentIndex] == 2) {

        if (self.jzScale >= scale) {
            self.jzScale = scale > 1 ? scale : 1;

        } else {
            self.scrollView.contentOffset = CGPointMake(jzOffSetX, 0);
        }
    } else if ([[NSUserDefaults standardUserDefaults] integerForKey: kSegmentIndex] == 3) {
//        if (self.jzScale >= 4.f) {
//            self.jzScale = 4.f;
//        } else {
//            self.scrollView.contentOffset = CGPointMake(jzOffSetX, 0);
//        }
        if (self.jzScale >= scale) {
            self.jzScale = scale > 1 ? scale : 1;

        } else {
            self.scrollView.contentOffset = CGPointMake(jzOffSetX, 0);
        }
    }
    //    改变dataView的frame大小来控制scrollView的contentSize来改变可滑动的视图范围
    self.scrollView.contentSize = CGSizeMake(self.dataView.frame.size.width, self.dataView.frame.size.height);
    self.dataView.frame = self.dataView.bounds;
    self.padScaleView.frame = CGRectMake(0, self.padScaleView.frame.origin.y, self.padScaleView.frame.size.width, self.padScaleView.frame.size.height);
}

- (void)endMovedWithPoint:(CGPoint)point1 point2:(CGPoint)point2
{
    self.scrollView.contentSize = CGSizeMake(self.dataView.frame.size.width, self.dataView.frame.size.height);
//    self.scaleView.jzScale = self.jzScale;
    self.padScaleView.jzScale = self.jzScale;
    CGFloat width = (point1.x + point2.x) / 2 - self.scrollView.frame.origin.x;
    jzOffSetX = scrollOffsetX * self.jzScale / scrollScale + width * (self.jzScale / scrollScale - 1);
    self.scrollView.contentOffset = CGPointMake(jzOffSetX, 0);
    self.dataView.frame = self.dataView.bounds;
    self.padScaleView.frame = CGRectMake(0, self.padScaleView.frame.origin.y, self.padScaleView.frame.size.width, self.padScaleView.frame.size.height);
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    scrollOffsetX = scrollView.contentOffset.x;
    scrollScale = self.jzScale;
}

- (void)handlePanGesture: (UIPanGestureRecognizer *)pan
{
//    CGPoint locaionPoint = [pan locationInView:self.dataView];
    if (pan.state == UIGestureRecognizerStateBegan) {
        if (!isIndicator) {
            isIndicator = YES;
            [self addSubview:self.indicatorView];
        }
    } else if (pan.state == UIGestureRecognizerStateChanged) {

//        CGFloat x = locaionPoint.x / self.dataView.frame.size.width;
        if (self.bigDataArray) {
            for (NSMutableArray *dataArray in self.bigDataArray) {
                if (dataArray) {
                    if (dataArray.count == 1) {
//                        self.indicatorView.pointArray = self.dataView.bigPointArray;
                    }
                    for (int i = 0; i < dataArray.count; i++) {
//                        JZPoint *point = dataArray[i];
                        if (i == 0) {

                        } else {

                        }
                    }
                }
            }
        }
    } else if (pan.state == UIGestureRecognizerStateEnded) {
        isIndicator = NO;
        [self.indicatorView removeFromSuperview];
    }
}

- (void)handleSingleTapGesture:(UITapGestureRecognizer *)singleTap
{
    [self.delegate handleSingleTapGesture:singleTap lineChartView:self];
}

- (void)handleDoubleTapGesture:(UITapGestureRecognizer *)doubleTap
{
    if (isIndicator) {
        [self.indicatorView removeFromSuperview];
    } else {
        [self addSubview:self.indicatorView];
    }
    isIndicator = !isIndicator;
}

#pragma mark UIGestureRecognizer Methods

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    if ([otherGestureRecognizer.view isKindOfClass:[UITableView class]]) {
        return YES;
    }
    return NO;
}

@end
