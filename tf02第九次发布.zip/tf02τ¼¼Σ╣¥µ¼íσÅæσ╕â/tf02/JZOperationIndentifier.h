//
//  JZOperationIndentifier.h
//  tf02
//
//  Created by F7686324 on 04/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#ifndef JZOperationIndentifier_h
#define JZOperationIndentifier_h

#define loginOperation @"loginOperation"
#define forgetPwdOperation @"forgetPwdOperation"
#define findAllFamilyMembersOperation @"findAllFamilyMembersOperation"
#define todayRemindOperation @"todayRemindOperation"
#define todayRemindHistoryOperation @"todayRemindHistoryOperation"
#define todayRecommendOperation @"todayRecommendOperation"
#define loadshoucangOperation @"loadshoucangOperation"
#define wethercollectionOperation @"wethercollectionOperation"
#define shoucangOperation @"shoucangOperation"
#define cancelshoucangOperation @"cancelshoucangOperation"

#define bindChannelIdOperation @"bindChannelIdOperation"

#define bloodPressureOperation @"bloodPressureOperation"
#define heartRateOpreation @"heartRateOpreation"
#define bloodSugarOpreation @"bloodSugarOpreation"
#define bodyFatOperation @"bodyFatOperation"
#define weightOpreation @"weightOpreation"
#define bloodOxygenOpreation @"bloodOxygenOpreation"

#define hulizixunRementuijianOperation @"hulizixunRementuijianOperation"
#define hulizixunLaorenhuliOperation @"hulizixunLaorenhuliOperation"
#define hulizixunJiatinghuliOperation @"hulizixunJiatinghuliOperation"
#define hulizixunXiaohaihuliOperation @"hulizixunXiaohaihuliOperation"

#define familyaccountbymailOperation @"familyaccountbymailOperation"
#define familyaccountbytelOperation @"familyaccountbytelOperation"
#define findBackPasswordByMailOperation @"findBackPasswordByMailOperation"
#define findBackPasswordByTelOperation @"findBackPasswordByTelOperation"

#define getHelplistOperation @"getHelplistOperation"
#define submitFeedbackOperation @"submitFeedbackOperation"

#define getWeatherOperation @"getWeatherOperation"
#define getCityOperation @"getCityOperation"
#endif /* JZOperationIndentifier_h */
