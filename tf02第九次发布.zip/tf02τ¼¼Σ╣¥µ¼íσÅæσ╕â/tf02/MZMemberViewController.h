//
//  MZMemberViewController.h
//  tf02
//
//  Created by Mokyz on 16/10/5.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZPersonInfo.h"

@interface MZMemberViewController : UITableViewController

@property (nonatomic, strong) JZPersonInfo *personInfo;

@end
