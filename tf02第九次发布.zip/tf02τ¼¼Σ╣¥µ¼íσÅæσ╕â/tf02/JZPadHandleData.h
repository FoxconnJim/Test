//
//  JZPadHandleData.h
//  tf02
//
//  Created by F7686324 on 03/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utility.h"

@interface JZPadHandleData : NSObject

{
    CGFloat value;
    CGFloat startValue;
}

@property (nonatomic, strong) NSMutableArray *totalArray;
@property (nonatomic, strong) NSMutableArray *meatimeArray;

- (instancetype)initWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString;
+ (instancetype)dataWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString;

@end
