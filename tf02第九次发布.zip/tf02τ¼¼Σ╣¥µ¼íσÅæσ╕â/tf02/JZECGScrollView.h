//
//  JZECGScrollView.h
//  tf02
//
//  Created by F7686324 on 28/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZECGScrollView : UIScrollView
{
    CGFloat ratio;
    CGFloat smallSpace;
    CGFloat bigSpace;
    CGFloat space;
}

@end
