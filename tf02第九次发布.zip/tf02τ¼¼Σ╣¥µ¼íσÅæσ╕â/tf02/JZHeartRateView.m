//
//  JZHeartRateView.m
//  tf02
//
//  Created by AN PEN on 3/31/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHeartRateView.h"
#import "JZOperation.h"
#import "JZHeartRateData.h"
#import "NSString+Date.h"
#import "Utility.h"
#import "JZFmdbTool.h"

@interface JZHeartRateView () <JZOperationDelegate>

@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, copy) NSString *memberId;

@end

@implementation JZHeartRateView

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundLayer.startColor = [UIColor colorWithRed:1.00 green:0.42 blue:0.55 alpha:1.00];
        self.backgroundLayer.endColor = [UIColor colorWithRed:0.96 green:0.21 blue:0.39 alpha:1.00];
        self.titleLabel.text = @"心率";
        self.jzType = @"心率";

        [self.imgView setImage:[UIImage imageNamed: @"heartRate"]];
        [self initUI];

    }
    return self;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;
    [self initTimeAndValueWithType:self.jzType];

    [self.queue cancelAllOperations];

    self.jzScale = 1.f;

    self.scrollView.contentSize = CGSizeMake(screenW - screenEdgeMargin * 2 - 5 * 2, self.dataView.frame.size.height);

//    [self initUI];


    NSMutableDictionary *param = [self paramWithTimeLengthString:timeLengthString];

    JZOperation *operation = [JZOperation operationWithURLString:heartRateURL andParam:param getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = heartRateOpreation;
}

#pragma mark - JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSArray *array = responseObject[@"data"];

    [self handleDataWithArray:array success:YES];

    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error {
    if (error.code == -1009) {
        [self initUI];

        NSArray *array = [JZFmdbTool queryHeartRateDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];

        [self handleDataWithArray:array success:NO];
    }
    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)handleDataWithArray:(NSArray *)array success:(BOOL)success
{

    NSMutableArray *pointArray = [NSMutableArray array];
    if ([array isKindOfClass:[NSArray class]]) {
        [self.bigDataArray removeAllObjects];

        if (array.count) {
            [self.indicatorLabel removeFromSuperview];

            [JZFmdbTool beginTransaction];
            @try {
                [self.dataArray removeAllObjects];
                if (success) {
                    [JZFmdbTool deleteHeartRateDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                }
                for (int i = 0; i < array.count; i++) {
                    JZHeartRateData *heartRateData;
                    if (success) {
                        NSDictionary *dict = array[i];
                        heartRateData = [JZHeartRateData dataWithDictionary: dict];
                        [JZFmdbTool insertHeartRateData:heartRateData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    } else {
                        heartRateData = array[i];
                    }

                    [self.dataArray addObject: heartRateData];

                    JZDataPoint *dataPoint = [JZDataPoint dataPointWithMeatime:heartRateData.meatime data:heartRateData.data];
                    [pointArray addObject:dataPoint];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            JZPadHandleData2017 *padHandleData = [JZPadHandleData2017 dataWithArray:pointArray timeLengthString:self.timeLengthString];


            [self.bigDataArray addObject:padHandleData.totalArray];

            self.textArray = padHandleData.meatimeArray;

            //            JZHandleData *handleData = [JZHandleData dataWithArray:pointArray timeLengthString:self.timeLengthString];
            //            [self.bigDataArray addObject:handleData.dataArray];
            self.dataView.bigDataArray = self.bigDataArray;
            [self.scrollView addSubview:self.dataView];


            //            self.scaleView.timeLengthString = self.timeLengthString;
            //            [self.scrollView addSubview: self.scaleView];
            self.padScaleView.pointArray = padHandleData.totalArray;
            self.padScaleView.textArray = padHandleData.meatimeArray;
            self.padScaleView.timeLengthString = self.timeLengthString;

            [self.scrollView addSubview:self.padScaleView];
            // 细节显示
            self.maxValue.text = [NSString stringWithFormat:@"%d", (int)(self.dataView.maxValue)];
            self.minValue.text = [NSString stringWithFormat:@"%d", (int)(self.dataView.minValue)];

        } else {
            [self initUI];
        }
        
    } else {
        [self initUI];
    }
}

- (void)initUI
{
    self.maxValue.text = @"";
    self.minValue.text = @"";
//    [self.scaleView removeFromSuperview];
    [self.padScaleView removeFromSuperview];

    [self.dataView removeFromSuperview];

    [self addSubview: self.indicatorLabel];
}


@end
