//
//  JZLocation.m
//  tf02
//
//  Created by Jim on 16/3/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZLocation.h"
#import "JZOperation.h"

@implementation JZLocation

- (NSOperationQueue *)queue
{
    if (_queue == nil) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (CLLocationManager *)locationManager{
    if(!_locationManager){
        //定位功能可用，开始定位
        _locationManager = [[CLLocationManager alloc] init];
    }
    return _locationManager;
}

- (void)getLocation
{
    if (![CLLocationManager locationServicesEnabled]) {
        [self.delegate locationUnvaliable];
    }
    NSLog(@"((((((((()))))))))");
    if (([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways || [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse)) {
        // 提前调用此方法（程序打开的第一页面） 让用户授权可否访问位置信息
        [self.locationManager requestWhenInUseAuthorization];//（当用户使用时）
        self.locationManager.delegate = self;
        self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
        [self.locationManager startUpdatingLocation];
    } else {
        [self.delegate locationOff];
    }
}
#pragma mark - CoreLocation Delegate
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    NSBlockOperation *blockOperation = [NSBlockOperation blockOperationWithBlock: ^{
        //此处locations存储了持续更新的位置坐标值，取最后一个值为最新位置，如果不想让其持续更新位置，则在此方法中获取到一个值之后让locationManager stopUpdatingLocation
        CLLocation *currentLocation = [locations lastObject];
        // 获取当前所在的城市名
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        //根据经纬度反向地理编译出地址信息
        [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *array, NSError *error) {
             if (array.count > 0)
             {
                 CLPlacemark *placemark = [array objectAtIndex:0];
                 //获取城市
//                 NSLog(@"name = %@", placemark.name);
//                 NSLog(@"thoroughfare = %@", placemark.thoroughfare);
//                 NSLog(@"subThoroughfare = %@", placemark.subThoroughfare);
//                 NSLog(@"locality = %@", placemark.locality);
//                 NSLog(@"subLocality = %@", placemark.subLocality);
//                 NSLog(@"administrativeArea = %@", placemark.administrativeArea);
//                 NSLog(@"subAdministrativeArea = %@", placemark.subAdministrativeArea);
//                 NSLog(@"postalCode = %@", placemark.postalCode);
//                 NSLog(@"ISOcountryCode = %@", placemark.ISOcountryCode);
//                 NSLog(@"country = %@", placemark.country);
//                 NSLog(@"inlandWater = %@", placemark.inlandWater);
//                 NSLog(@"ocean = %@", placemark.ocean);
//                 NSLog(@"areasOfInterest = %@", placemark.areasOfInterest);
                 //回到主线程刷新数据
                 dispatch_async(dispatch_get_main_queue(), ^(){
                     [self.delegate locationInfoWithProvince:placemark.administrativeArea city:placemark.locality];
                 });
             }
             else if (error == nil && [array count] == 0)
             {
                 NSLog(@"No results were returned.");
             }
             else if (error != nil)
             {
                 NSLog(@"JZLocation error = %@", error);
             }
         }];
        //系统会一直更新数据，直到选择停止更新，因为我们只需要获得一次经纬度即可，所以获取之后就停止更新
        [manager stopUpdatingLocation];
    }];
    [self.queue addOperation:blockOperation];
}
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    
    NSString *errorMessage;
    if ([error code] == kCLErrorDenied) {
        errorMessage = @"你的访问被拒绝";
    }
    if ([error code] == kCLErrorLocationUnknown) {
        errorMessage = @"无法定位到你的位置！";
    }

    [self.delegate locationFailWithMessage: errorMessage];
}



@end
