//
//  JZHotNews.m
//  tf02
//
//  Created by AN PEN on 8/3/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHotNews.h"

@implementation JZHotNews

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.newsFront = [NSString stringWithFormat:@"%@", dict[@"newsFront"]];
        self.newsHead = [NSString stringWithFormat:@"%@", dict[@"newsHead"]];
        self.newsContent = [NSString stringWithFormat:@"%@", dict[@"newsDescription"]];
        self.urlString = [NSString stringWithFormat: @"%@", dict[@"netUrl"]];
        self.ID = [NSString stringWithFormat:@"%@", dict[@"id"]];
        self.delflag = [NSString stringWithFormat: @"%@", dict[@"delflag"]];

    }
    return self;
}

+ (instancetype)hotNewsWithDictionary: (NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

@end
