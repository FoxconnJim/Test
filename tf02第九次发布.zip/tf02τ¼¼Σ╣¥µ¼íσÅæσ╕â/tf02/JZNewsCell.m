
//
//  JZNewsCell.m
//  tf02
//
//  Created by AN PEN on 8/8/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZNewsCell.h"
@interface JZNewsCell ()
{
    CGFloat margin;
}

@end

@implementation JZNewsCell

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(margin, margin, newsRowHeight - margin * 2, newsRowHeight - margin * 2)];

        [_imgView setImage: [UIImage imageNamed:@"资讯"]];

        _imgView.layer.cornerRadius = 5;
        _imgView.layer.masksToBounds = YES;
    }
    return _imgView;
}

- (UILabel *)title
{
    if (!_title) {
        _title = [[UILabel alloc] initWithFrame:CGRectMake(newsRowHeight, margin * 1.5, screenW - newsRowHeight - margin,  margin * 2)];
        _title.font = [UIFont systemFontOfSize:17];

    }
    return _title;
}

- (UILabel *)content
{
    if (!_content) {
        _content = [[UILabel alloc] initWithFrame:CGRectMake(newsRowHeight, margin * 4, screenW - newsRowHeight - margin, newsRowHeight - margin * 5)];
        _content.textColor = [UIColor grayColor];
        _content.font = [UIFont systemFontOfSize: 15];
        _content.numberOfLines = 0;
        _content.lineBreakMode = NSLineBreakByTruncatingTail;
    }
    return _content;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        margin = 10;
        [self addSubview: self.imgView];
        [self addSubview: self.title];
        [self addSubview: self.content];
        self.separatorInset = UIEdgeInsetsMake(0, margin, 0, 0);
    }
    return self;
}

+ (JZNewsCell *)cellWithTableView:(UITableView *)tableView
{
    static NSString *cellid = @"todayRecommendID";
    JZNewsCell *cell = [tableView dequeueReusableCellWithIdentifier: cellid];
    if (!cell) {
        cell = [[JZNewsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    return cell;
}

- (void)setHotNews:(JZHotNews *)hotNews
{
    _hotNews = hotNews;

    self.title.text = hotNews.newsHead;
    self.content.text = hotNews.newsContent;
    [self resetContent];
}

- ( void )resetContent{

    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString: self.content.text];

    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];

    paragraphStyle.alignment = NSTextAlignmentLeft;

    paragraphStyle.maximumLineHeight = 20;  //最大的行高

    paragraphStyle.lineSpacing = 5;  //行自定义行高度

    [attributedString addAttribute: NSParagraphStyleAttributeName value: paragraphStyle range: NSMakeRange (0 , [self.content.text length])];

    self.content.attributedText = attributedString;
    self.content.lineBreakMode = NSLineBreakByTruncatingTail;
}

@end
