//
//  JZWeatherView.m
//  tf02
//
//  Created by Jim on 16/3/12.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZWeatherView.h"


@implementation JZWeatherView

- (JZWeatherFrame *)weatherFrame
{
    if (!_weatherFrame) {
        _weatherFrame = [[JZWeatherFrame alloc] init];
    }
    return _weatherFrame;
}

- (UIActivityIndicatorView *)tips
{
    if (!_tips) {
        _tips = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(5, 5, self.weatherFrame.locationFrame.origin.x - 10, self.weatherFrame.frame.size.height - 10)];
        _tips.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
        [_tips startAnimating];
    }
    return _tips;
}

- (UILabel *)nullcity
{
    if (!_nullcity) {
        _nullcity = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, self.weatherFrame.locationFrame.origin.x - 10, self.weatherFrame.frame.size.height - 10)];
        _nullcity.text = @"不知道要获取哪座城市的天气(ಥ_ಥ)";
        _nullcity.numberOfLines = 0;
        _nullcity.textColor = [UIColor whiteColor];
        _nullcity.textAlignment = NSTextAlignmentCenter;
    }
    return _nullcity;
}

- (UIView *)weatherInfo
{
    if (!_weatherInfo) {
        _weatherInfo = [[UIView alloc] initWithFrame: self.weatherFrame.frame];
        _weatherInfo.backgroundColor = [UIColor colorWithRed:0.16 green:0.5 blue:0.91 alpha:1];
        _weatherInfo.layer.cornerRadius = 5;
        _weatherInfo.layer.masksToBounds = YES;
        [_weatherInfo addSubview:self.tips];
        [_weatherInfo addSubview:self.location];
        [_weatherInfo addSubview:self.weather];
        [_weatherInfo addSubview:self.temp];
        [_weatherInfo addSubview:self.wind];
        [_weatherInfo addSubview:self.leftImage];
        [_weatherInfo addSubview:self.mid];
        [_weatherInfo addSubview:self.rightImage];
        [_weatherInfo addSubview:self.weatherImage];
        [_weatherInfo addSubview:self.airCondition];

    }
    return _weatherInfo;
}

- (UIImageView *)weatherImage
{
    if (!_weatherImage) {
        _weatherImage = [[UIImageView alloc] initWithFrame:self.weatherFrame.weatherImageFrame];
    }
    return _weatherImage;
}

- (UIImageView *)leftImage
{
    if (!_leftImage) {
        _leftImage = [[UIImageView alloc] initWithFrame:self.weatherFrame.leftImageFrame];
    }
    return _leftImage;
}

- (UILabel *)mid
{
    if (!_mid) {
        _mid = [[UILabel alloc] initWithFrame:self.weatherFrame.midFrame];
        _mid.textColor = [UIColor whiteColor];
        _mid.textAlignment = NSTextAlignmentCenter;

    }
    return _mid;
}

- (UIImageView *)rightImage
{
    if (!_rightImage) {
        _rightImage = [[UIImageView alloc] initWithFrame:self.weatherFrame.rightImageFrame];
    }
    return _rightImage;
}

- (UIButton *)location
{
    if (!_location) {
        _location = [[UIButton alloc] initWithFrame: self.weatherFrame.locationFrame];
        _location.showsTouchWhenHighlighted = YES;
        _location.titleLabel.numberOfLines = 0;
        _location.titleLabel.textAlignment = NSTextAlignmentCenter;
        [_location setTitle:@"[自定义城市]▾" forState:UIControlStateNormal];
    }
    return _location;
}

- (UILabel *)weather
{
    if (!_weather) {
        _weather = [[UILabel alloc] initWithFrame: self.weatherFrame.weatherLabelFrame];
        _weather.textColor = [UIColor whiteColor];
        _weather.textAlignment = NSTextAlignmentCenter;
        _weather.numberOfLines = 2;
        _weather.font = [UIFont systemFontOfSize:16];
    }
    return _weather;
}

- (UILabel *)temp
{
    if (!_temp) {
        _temp = [[UILabel alloc] initWithFrame: self.weatherFrame.temFrame];
        _temp.textColor = [UIColor whiteColor];
        _temp.font = [UIFont systemFontOfSize:25];
        _temp.textAlignment = NSTextAlignmentCenter;
    }
    return _temp;
}

- (UILabel *)airCondition
{
    if (!_airCondition) {
        _airCondition = [[UILabel alloc] initWithFrame:self.weatherFrame.humidityFrame];
        _airCondition.font = [UIFont systemFontOfSize:17];
        _airCondition.textAlignment = NSTextAlignmentCenter;
        _airCondition.textColor = [UIColor whiteColor];
    }
    return _airCondition;
}

- (UILabel *)wind
{
    if (!_wind) {
        _wind = [[UILabel alloc] initWithFrame: self.weatherFrame.winFrame];
        _wind.textColor = [UIColor whiteColor];
        _wind.font = [UIFont systemFontOfSize: 17];
        _wind.textAlignment = NSTextAlignmentCenter;
        _wind.numberOfLines = 0;
    }
    return _wind;
}

- (void)setWeatherModel:(JZWeatherModel *)weatherModel
{
    _weatherModel = weatherModel;
    [self.tips stopAnimating];
    if (weatherModel) {
        [self.nullcity removeFromSuperview];
        self.weather.text = weatherModel.weather;
        NSArray *future = weatherModel.future;
        if ([future isKindOfClass:[NSArray class]]) {
            NSString *date = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
            for (NSDictionary *dict in future) {
                NSString *dateString = dict[@"date"];
                if ([date isEqualToString:dateString]) {
                    NSString *temperature = dict[@"temperature"];
                    if ([temperature containsString:@"/"]) {
                        NSArray *array = [temperature componentsSeparatedByString:@"/"];
                        self.temp.text = [NSString stringWithFormat:@"%@~%@", [array lastObject], [array firstObject]];
                    } else {
                        self.temp.text = temperature;
                    }
                }
            }
        }

        self.wind.text = weatherModel.wind;
        self.airCondition.text = [NSString stringWithFormat:@"空气质量:%@", weatherModel.airCondition];
        self.weatherImage.image = [UIImage imageNamed:weatherModel.weather];
    } else {
        [self addSubview:self.nullcity];
        self.weather.text = @"";
        self.temp.text = @"";
        self.wind.text = @"";
        self.airCondition.text = @"";
        self.weatherImage.image = nil;
        [_location setTitle:@"[自定义城市]▾" forState:UIControlStateNormal];
    }

}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.18 green:0.55 blue:1 alpha:1];
        [self addSubview: self.weatherInfo];
      
    }
    return self;
}




































@end
