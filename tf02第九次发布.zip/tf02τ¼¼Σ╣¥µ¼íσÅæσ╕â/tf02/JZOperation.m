//
//  JZOperation.m
//  tf02
//
//  Created by F7686324 on 2017/1/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZOperation.h"

@implementation JZOperation

+ (AFHTTPSessionManager *)manager
{
    static AFHTTPSessionManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [AFHTTPSessionManager manager];
    });
    return manager;
}

+ (instancetype)operationWithURLString: (NSString *)urlString andParam: (NSMutableDictionary *)param getOrPost: (NSString *)getOrPost
{
    JZOperation *operation = [[JZOperation alloc] init];
    operation.url = urlString;
    operation.param = param;
    operation.getOrPost = getOrPost;
    NSInteger method = 0;
    if ([getOrPost isEqualToString:JZ_GET]) {
        method = METHOD_GET;
    } else if ([getOrPost isEqualToString:JZ_POST]) {
        method = METHOD_POST;
    }
    [operation requestAFURL:urlString httpMethod:method parameters:param];
    return operation;
}

/**
 * AF网络请求
 */
- (void)requestAFURL:(NSString *)URLString
         httpMethod:(NSInteger)method
         parameters:(id)parameters

{
    // 0.设置API地址
    //    URLString = [NSString stringWithFormat:@"%@%@",BASE_URL,[URLString stringByReplacingOccurrencesOfString:@" " withString:@"%20"]];
    NSLog(@"\n AF网络请求参数列表:%@\n\n 接口名: %@\n\n",parameters,URLString);

    // 1.创建请求管理者
    AFHTTPSessionManager *manager = [JZOperation manager];

    manager.requestSerializer = [AFJSONRequestSerializer serializer];

    // 2.申明返回的结果是JSON类型
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    JZFamilyInfo *familyInfo = [JZFamilyInfo valueByKey:kFamilyInfo];
    if (familyInfo) {
        NSLog(@"token = %@", familyInfo.token);
        [manager.requestSerializer setValue: familyInfo.token forHTTPHeaderField:@"token"];
    }

    // 3.如果接受类型不一致请替换
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/plain", @"text/xml", nil];

    NSLog(@"%@_param_%@ = %@", self.name, self.getOrPost, [self.param JSONString]);

    // 4.请求超时，时间设置
    manager.requestSerializer.timeoutInterval = 10;

    // 5.选择请求方式 GET 或 POST
    switch (method) {
        case METHOD_GET:
        {
            [manager GET:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {

                [self successWithTask:task responseObject:responseObject];

            } failure:^(NSURLSessionDataTask *task, NSError *error) {
                [self failureWithTask:task error:error];
            }];
        }
            break;

        case METHOD_POST:
        {
            [manager POST:URLString parameters:parameters progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {


                [self successWithTask:task responseObject:responseObject];

            } failure:^(NSURLSessionDataTask *task, NSError *error) {

                [self failureWithTask:task error:error];

            }];
        }
            break;

        default:
            break;
    }
}

- (void)successWithTask:(NSURLSessionDataTask *)task responseObject:(id)responseObject
{
    NSLog(@"请求成功");
    if ([responseObject isKindOfClass:[NSDictionary class]]) {
        NSLog(@"%@_responseObject = %@", self.name, [responseObject JSONString]);

        if ([responseObject[@"code"] integerValue] == 7099)
        {
            NSLog(@"token值错误");
//            [LCProgressHUD showInfoMsg:@"token值错误"];
            JZLoginViewController *loginVC = [[JZLoginViewController alloc] init];
            [UIApplication sharedApplication].keyWindow.rootViewController = loginVC;
            return;
        }

        [self.delegate didFinishDownLoadWithOperation:self andResponseObject:responseObject];

    } else {
        NSLog(@"返回值不是字典");
//       [self.delegate didFinishDownLoadWithOperation:self andResponseObject:responseObject];
    }
}

- (void)failureWithTask:(NSURLSessionDataTask *)task error:(NSError *)error
{
    [self.delegate didFailureWithOperation:self error:error];
    NSLog(@"\n 请求失败:%@\n\n",error);
}


+ (void)cancelAFHTTPRequest
{
    // 1.创建请求管理者
    AFHTTPSessionManager *manager = [JZOperation manager];
    NSArray *dataTasks = [manager dataTasks];
    for (NSURLSessionDataTask *dataTask in dataTasks) {
        [dataTask cancel];
    }

}
@end
