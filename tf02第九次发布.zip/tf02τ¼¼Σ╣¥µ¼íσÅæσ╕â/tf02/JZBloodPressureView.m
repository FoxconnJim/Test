//
//  JZBloodPressureView.m
//  tf02
//
//  Created by AN PEN on 3/31/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZBloodPressureView.h"
#import "JZBloodPressureData.h"
#import "JZOperation.h"
#import "Utility.h"
#import "JZFmdbTool.h"

@interface JZBloodPressureView () <JZOperationDelegate>

@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, copy) NSString *memberId;

@end

@implementation JZBloodPressureView

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        [self initUI];
        self.backgroundLayer.startColor = [UIColor colorWithRed:0.65 green:0.43 blue:0.79 alpha:1.00];
        self.backgroundLayer.endColor = [UIColor colorWithRed:0.40 green:0.19 blue:0.55 alpha:1.00];
        self.titleLabel.text = @"血压";
        self.jzType = @"血压";
        [self.imgView setImage:[UIImage imageNamed: @"bloodPressure"]];

    }
    return self;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;
    [self initTimeAndValueWithType:self.jzType];

//    [self.queue cancelAllOperations];

    self.jzScale = 1.f;

    self.scrollView.contentSize = CGSizeMake(screenW - screenEdgeMargin * 2 - 5 * 2, self.dataView.frame.size.height);
//    [self initUI];

    NSMutableDictionary *param = [self paramWithTimeLengthString:timeLengthString];
    
    JZOperation *operation = [JZOperation operationWithURLString:bloodPressureURL andParam:param getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = bloodPressureOperation;
}

#pragma mark - JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSArray *arr = responseObject[@"data"];
    NSArray *array = (NSArray *)arr;

    [self handleDataWithArray:array success:YES];

    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error {
    if (error.code == -1009) {
        [self initUI];
        [LCProgressHUD showInfoMsg:@"网络有点卡..."];
        NSArray *array = [JZFmdbTool queryBloodPressureDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
        [self handleDataWithArray:array success:NO];
    }
    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)handleDataWithArray:(NSArray *)array success:(BOOL)success
{

    NSMutableArray *pointArray1 = [NSMutableArray array];
    NSMutableArray *pointArray2 = [NSMutableArray array];
    if ([array isKindOfClass:[NSArray class]]) {
        [self.bigDataArray removeAllObjects];

        if (array.count) {
            [self.indicatorLabel removeFromSuperview];

            [JZFmdbTool beginTransaction];
            @try {
                [self.dataArray removeAllObjects];

                if (success) {
                    [JZFmdbTool deleteBloodPressureDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                }

                for (int i = 0; i < array.count; i++) {
                    JZBloodPressureData *bloodPressureData;
                    if (success) {
                        NSDictionary *dict = array[i];
                        bloodPressureData = [JZBloodPressureData dataWithDictionary:dict];

                        if([JZFmdbTool insertBloodPressureData:bloodPressureData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]]) {
                            NSLog(@"存入血压数据成功");
                        } else {
                            NSLog(@"存入血压数据失败");
                        }//存数据库

                    } else {
                        bloodPressureData = array[i];
                    }

                    [self.dataArray addObject: bloodPressureData];


                    JZDataPoint *dataPoint1 = [JZDataPoint dataPointWithMeatime:bloodPressureData.meatime data:bloodPressureData.bpDp];
                    [pointArray1 addObject:dataPoint1];

                    JZDataPoint *dataPoint2 = [JZDataPoint dataPointWithMeatime:bloodPressureData.meatime data:bloodPressureData.bpSp];
                    [pointArray2 addObject:dataPoint2];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }


            JZPadHandleData2017 *padHandleData1 = [JZPadHandleData2017 dataWithArray:pointArray1 timeLengthString:self.timeLengthString];
            JZPadHandleData2017 *padHandleData2 = [JZPadHandleData2017 dataWithArray:pointArray2 timeLengthString:self.timeLengthString];

            self.textArray = padHandleData1.meatimeArray;
            
            [self.bigDataArray addObject:padHandleData1.totalArray];
            [self.bigDataArray addObject:padHandleData2.totalArray];
            //            JZHandleData *handleData1 = [JZHandleData dataWithArray:pointArray1 timeLengthString:self.timeLengthString];
            //            JZHandleData *handleData2 = [JZHandleData dataWithArray:pointArray2 timeLengthString:self.timeLengthString];
            //            [self.bigDataArray addObject:handleData1.dataArray];
            //            [self.bigDataArray addObject:handleData2.dataArray];

            self.dataView.bigDataArray = self.bigDataArray;
            self.dataView.colorArray = [NSArray arrayWithObjects:[UIColor whiteColor], [UIColor greenColor], nil];
            [self.scrollView addSubview:self.dataView];

            NSLog(@"padHandleData1.meatimeArray = %@", padHandleData1.meatimeArray);
            //            self.scaleView.timeLengthString = self.timeLengthString;
            //            [self.scrollView addSubview:self.scaleView];
            self.padScaleView.pointArray = padHandleData1.totalArray;
            self.padScaleView.textArray = padHandleData1.meatimeArray;
            self.padScaleView.timeLengthString = self.timeLengthString;
            [self.scrollView addSubview:self.padScaleView];

            // 细节显示
            self.maxValue.text = [NSString stringWithFormat:@"%d", (int)(self.dataView.maxValue)];
            self.minValue.text = [NSString stringWithFormat:@"%d", (int)(self.dataView.minValue)];

        } else {
            [self initUI];
        }
    } else {
        [self initUI];
    }

}

- (void)initUI
{
    self.maxValue.text = @"";
    self.minValue.text = @"";
//    [self.scaleView removeFromSuperview];
    [self.padScaleView removeFromSuperview];
    [self.dataView removeFromSuperview];
    [self addSubview: self.indicatorLabel];
}


@end
