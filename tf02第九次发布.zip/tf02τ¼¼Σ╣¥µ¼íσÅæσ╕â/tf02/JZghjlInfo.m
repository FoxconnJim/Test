//
//  JZghjlInfo.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZghjlInfo.h"

@implementation JZghjlInfo

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.formNumber = [NSString stringWithFormat:@"5214523"];
        self.patientName = [NSString stringWithFormat:@"张晓明"];
        self.hospital = [NSString stringWithFormat:@"龙华新区人民医院"];
        self.time = [NSString stringWithFormat:@"2016-04-14 10:00-11:30"];
        self.type = [NSString stringWithFormat:@"内科"];
        self.doctorName = [NSString stringWithFormat:@"张文"];
        self.cost = [NSString stringWithFormat:@"18元"];
        self.payWay = [NSString stringWithFormat:@"现场支付"];
        self.info = [NSString stringWithFormat:@"有私事处理"];
        self.status = [NSString stringWithFormat:@"取消"];
    }
    return self;
}

+ (instancetype)ghjlInfoWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict: dict];
}

@end
