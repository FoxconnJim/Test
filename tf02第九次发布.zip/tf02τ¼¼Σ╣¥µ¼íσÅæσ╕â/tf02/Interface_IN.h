//
//  Interface_IN.h
//  tf02
//
//  Created by F7686324 on 9/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#ifndef Interface_IN_h
#define Interface_IN_h

#pragma mark 数据接口
#define bloodPressureURL @"http://10.244.171.37/TF02/V2/medicaldata/bloodpressure/list"
#define heartRateURL @"http://10.244.171.37/TF02/V2/medicaldata/heartrate/list"
#define bloodSugarURL @"http://10.244.171.37/TF02/V2/medicaldata/bloodsugar/list"
#define bodyFatURL @"http://10.244.171.37/TF02/V2/medicaldata/bodyfat/list"
#define oxygenURL @"http://10.244.171.37/TF02/V2/medicaldata/bloodraise/list"

#define usersLoginURL @"http://10.244.171.37/TF02/V2/account/familyaccount/login"
#define changePwdByTel @"http://10.244.171.37/TF02/V2/account/pwdbytel/update"
#define changePwdByMail @"http://10.244.171.37/TF02/V2/account/pwdbymail/update"
#define usersRegisterURL @"http://10.244.171.37/TF02/V2/account/familyaccount/create"
#define bindChannelId @"http://120.76.233.207/TF02/V2/push/messagepush/create"

#define getHeartRateURL @""
#define findAllFamilyMembersURL @"http://10.244.171.37/TF02/V2/info/allfamilymembers/list"
#define listCareNewsBySecondURL @"http://10.244.171.37/TF02/news/listCareNewsBySecond.json"
#define todayrecommendURL @"http://10.244.171.37/TF02/V2/news/todayrecommend/list"
#define todayRemindURL @"http://10.244.171.37/TF02/V2/remind/todayremind/list"
#define todayRemindHistoryURL @"http://10.244.171.37/TF02/V2/remind/alltodayremind/list"

#define chunyuyishengHLZXURL @"https://www.chunyuyisheng.com/health_news/?vendor=foxconn"
#define chunyuyishengJYZXURL @"https://test.chunyu.me/cooperation/wap/login/"
#define weatherURLString @"http://wthrcdn.etouch.cn/weather_mini?city="
#define hulizixunNewsURL @"http://10.244.171.37/TF02/V2/news/carenewsbysecond/list"
#define hulizixunADURL @"http://10.244.171.37/TF02/V2/news/carenewsad/list"
#define shoucangURL @"http://10.244.171.37/TF02/V2/collect/newscollect/create"
#define cancelshoucangURL @"http://10.244.171.37/TF02/V2/collect/newscollect/delete"
#define loadshoucangURL @"http://10.244.171.37/TF02/V2/collect/newscollect/list"

#define familyaccountbymailURL @"http://10.244.171.37/TF02/V2/account/familyaccountbymail/validate"
#define familyaccountbytelURL @"http://10.244.171.37/TF02/V2/account/familyaccountbytel/validate"
#define findBackPasswordByMailURL @""

#define healthServiceADURL @"http://10.244.171.37/TF02/V2/news/healthservicead/list"

#endif /* Interface_IN_h */
