//
//  JZTime.m
//  tf02
//
//  Created by F7686324 on 15/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//
/*
 写这段代码的时候，只有我和上帝知道，他是怎么实现的。
 现在，只有上帝知道。
 */
#import "JZTime.h"

@implementation JZTime

- (NSMutableArray *)dayArray
{
    if (!_dayArray) {
        _dayArray = [NSMutableArray array];
        NSArray *dayArray1 = [NSArray arrayWithObjects:@"04:00", @"08:00", @"12:00", @"16:00", @"20:00", nil];
        [_dayArray addObject: dayArray1];
        NSArray *dayArray2 = [NSArray arrayWithObjects:@"03:00", @"06:00", @"09:00", @"12:00", @"15:00", @"18:00", @"21:00", nil];
        [_dayArray addObject: dayArray2];
        NSArray *dayArray3 = [NSArray arrayWithObjects:@"02:00", @"04:00", @"06:00", @"08:00", @"10:00", @"12:00", @"14:00", @"16:00", @"18:00", @"20:00", @"22:00", nil];
        [_dayArray addObject: dayArray3];
        NSArray *dayArray4 = [NSArray arrayWithObjects:@"01:00", @"02:00", @"03:00", @"04:00", @"05:00", @"06:00", @"07:00", @"08:00", @"09:00", @"10:00", @"11:00", @"12:00", @"13:00", @"14:00", @"15:00", @"16:00", @"17:00", @"18:00", @"19:00", @"20:00", @"21:00", @"22:00", @"23:00", nil];
        [_dayArray addObject: dayArray4];
    }
    return _dayArray;
}

- (NSMutableArray *)weekArray
{
    if (!_weekArray) {
        _weekArray = [NSMutableArray array];
    }
    return _weekArray;
}

- (NSMutableArray *)monthArray
{
    if (!_monthArray) {
        _monthArray = [NSMutableArray array];
    }
    return _monthArray;
}

- (NSMutableArray *)yearArray
{
    if (!_yearArray) {
        _yearArray = [NSMutableArray array];

    }
    return _yearArray;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSString *endTimeString = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        NSDate *date = [[dateFormatter dateFromString:endTimeString] localDate];
        NSInteger endTimeInt = [date timeIntervalSince1970] + 24 * 60 * 60;

        [self getWeekArrayWithEndTimeInt:endTimeInt];
        [self getMonthArrayWithEndTimeInt:endTimeInt];
        [self getYearArrayWithNowTime:[[NSDate dateWithTimeIntervalSince1970:endTimeInt] dateToString]];
    }
    return self;
}

- (void)getWeekArrayWithEndTimeInt:(NSInteger)endTimeInt
{
    NSMutableArray *weekArray1 = [self getWeekArrayWithEndTimeInt:endTimeInt marginInt:24];   //24h
    NSMutableArray *weekArray2 = [self getWeekArrayWithEndTimeInt:endTimeInt marginInt:12];   //12h
    NSMutableArray *weekArray3 = [self getWeekArrayWithEndTimeInt:endTimeInt marginInt:8];    //8h
    NSMutableArray *weekArray4 = [self getWeekArrayWithEndTimeInt:endTimeInt marginInt:6];    //6h
    NSMutableArray *weekArray5 = [self getWeekArrayWithEndTimeInt:endTimeInt marginInt:4];    //4h
    [self.weekArray addObject: weekArray1];
    [self.weekArray addObject: weekArray2];
    [self.weekArray addObject: weekArray3];
    [self.weekArray addObject: weekArray4];
    [self.weekArray addObject: weekArray5];
}

- (void)getMonthArrayWithEndTimeInt:(NSInteger)endTimeInt
{
    NSMutableArray *monthArray1 = [self getMonthArrayWithEndTimeInt:endTimeInt marginInt:6];       //6day
    NSMutableArray *monthArray2 = [self getMonthArrayWithEndTimeInt:endTimeInt marginInt:5];       //5day
    NSMutableArray *monthArray3 = [self getMonthArrayWithEndTimeInt:endTimeInt marginInt:3];       //3day
    NSMutableArray *monthArray4 = [self getMonthArrayWithEndTimeInt:endTimeInt marginInt:2];       //2day
    NSMutableArray *monthArray5 = [self getMonthArrayWithEndTimeInt:endTimeInt marginInt:1];       //1day

    [self.monthArray addObject:monthArray1];
    [self.monthArray addObject:monthArray2];
    [self.monthArray addObject:monthArray3];
    [self.monthArray addObject:monthArray4];
    [self.monthArray addObject:monthArray5];
}


- (void)getYearArrayWithNowTime:(NSString *)nowTime
{
    NSMutableArray *yearArray1 = [self getYearArrayWithNowTime:nowTime marginInt:3];    //3month
    NSMutableArray *yearArray2 = [self getYearArrayWithNowTime:nowTime marginInt:2];    //2month
    NSMutableArray *yearArray3 = [self getYearArrayWithNowTime:nowTime marginInt:1];    //1month

    [self.yearArray addObject:yearArray1];
    [self.yearArray addObject:yearArray2];
    [self.yearArray addObject:yearArray3];
}

- (NSMutableArray *)getWeekArrayWithEndTimeInt:(NSInteger)endTimeInt marginInt:(NSInteger)marginInt
{
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (int i = 1; i < 7 * 24 / marginInt; i++) {
        NSDate *date = [NSDate dateWithTimeIntervalSince1970: endTimeInt - i * 60 * 60 * marginInt];
        NSString *dateString = [date dateToString];
        [mutableArray addObject:dateString];
    }
    mutableArray = [mutableArray changeOrder];
    NSMutableArray *array = [NSMutableArray array];//去掉分秒
    if (marginInt == 24) {
        for (NSString *str in mutableArray) {
            [array addObject:[[str componentsSeparatedByString:@" "] firstObject]];
        }
    } else {
        for (NSString *str in mutableArray) {
            [array addObject:[NSString stringWithFormat:@"%@时", [str substringToIndex:13]]];
        }
    }

    return [self dealWithFormatWithArray:array];
}

- (NSMutableArray *)getMonthArrayWithEndTimeInt:(NSInteger)endTimeInt marginInt:(NSInteger)marginInt
{
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (int i = 1; i < 30 / marginInt; i++) {
        NSDate *date = [NSDate dateWithTimeIntervalSince1970: endTimeInt - i * 60 * 60 * 24 * marginInt];
        NSString *dateString = [date dateToString];
        [mutableArray addObject:dateString];
    }
    mutableArray = [mutableArray changeOrder];
    NSMutableArray *array = [NSMutableArray array];
    for (NSString *str in mutableArray) {
        [array addObject:[[str componentsSeparatedByString:@" "] firstObject]];
    }
    
    return [self dealWithFormatWithArray:array];
}

- (NSMutableArray *)getYearArrayWithNowTime:(NSString *)nowTime marginInt:(NSInteger)marginInt
{
    NSMutableArray *mutableArray = [NSMutableArray array];

    NSString *yearString = [[[[NSDate date] localDate] dateToString] substringToIndex:4];

    NSInteger monthInt = [[[[nowTime componentsSeparatedByString:@" "] firstObject] componentsSeparatedByString:@"-"][1] integerValue];
    for (int i = 1; i < 12 / marginInt; i++) {
        NSInteger lastYearMonth = monthInt + i * marginInt;
        NSString *lastYearString;
        if (lastYearMonth <= 12) {
//            if (i == 1) {
//                lastYearString = [NSString stringWithFormat:@"%ld年%ld月", yearString.integerValue - 1, lastYearMonth];
//            } else {
//                lastYearString = [NSString stringWithFormat:@"%ld月", lastYearMonth];
//            }
            lastYearString = [NSString stringWithFormat:@"%ld/%ld", yearString.integerValue - 1, (long)lastYearMonth];
            [mutableArray addObject: lastYearString];
        }

    }
    NSMutableArray *array = [NSMutableArray array];
    for (int i = 12 / marginInt - 1; i >= 0; i--) {
        NSInteger nowYearMonth = monthInt - i * marginInt;
        if (nowYearMonth >= 1) {
            NSString *nowYearString = [NSString stringWithFormat:@"%ld", (long)nowYearMonth];

            [array addObject:nowYearString];
        }
    }

    for (int i = 0; i < array.count; i++) {
//        if (i == 0) {
//            [mutableArray addObject:[NSString stringWithFormat:@"%@年%@月", yearString, array[i]]];
//        } else {
//            [mutableArray addObject:[NSString stringWithFormat:@"%@月", array[i]]];
//        }
        [mutableArray addObject:[NSString stringWithFormat:@"%@/%@", yearString, array[i]]];

    }

    return mutableArray;
}

- (NSMutableArray *)dealWithFormatWithArray:(NSMutableArray *)array
{
    NSMutableArray *array1 = [NSMutableArray array];//去掉月
    [array1 addObject:[array firstObject]];
    NSString *month = [[array firstObject] substringWithRange:NSMakeRange(5, 2)];
    for (int i = 1; i < array.count; i++) {
        NSString *str = [array objectAtIndex:i];
        NSMutableString *mutableString = [NSMutableString stringWithString:str];
        if ([[str substringWithRange:NSMakeRange(5, 2)] isEqualToString:month]) {
            [mutableString deleteCharactersInRange:NSMakeRange(5, 3)];
            if (mutableString.length > 7) {
                [mutableString replaceCharactersInRange:NSMakeRange(7, 1) withString:@"日"];
            }
            [array1 addObject:mutableString];
        } else {
            month = [mutableString substringWithRange:NSMakeRange(5, 2)];
            [mutableString replaceCharactersInRange:NSMakeRange(7, 1) withString:@"月"];
            if (mutableString.length > 10) {
                [mutableString replaceCharactersInRange:NSMakeRange(10, 1) withString:@"日"];
            } else {
                [mutableString appendString:@"日"];
            }
            [array1 addObject:mutableString];
        }
    }

    NSMutableArray *array2 = [NSMutableArray array];//去掉年
    NSMutableString *firstString = [NSMutableString stringWithString:[array1 firstObject]];
    [firstString replaceCharactersInRange:NSMakeRange(7, 1) withString:@"月"];
    if (firstString.length > 10) {
        [firstString replaceCharactersInRange:NSMakeRange(10, 1) withString:@"日"];
    } else {
        [firstString appendString:@"日"];
    }
    [array2 addObject:[firstString substringFromIndex:5]];
    NSString *year = [[array1 firstObject] substringToIndex:4];
    for (int i = 1; i < array1.count; i++) {
        NSString *str = [array1 objectAtIndex:i];
        if ([[str substringToIndex:4] isEqualToString: year]) {
            [array2 addObject:[str substringFromIndex:5]];
        } else {
            NSMutableString *mutableString = [NSMutableString stringWithString:str];
            [mutableString replaceCharactersInRange:NSMakeRange(4, 1) withString:@"年"];
            [array2 addObject:mutableString];
        }
    }
    return array2;

}
  
@end
