//
//  JZECGBGView.m
//  tf02
//
//  Created by Jim on 2016/11/30.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZECGBGView.h"

@implementation JZECGBGView


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        ratio = 64;
        smallSpace = ratio / 10;
        bigSpace = ratio / 2;
        space = ratio / 60;
        
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    //    矩形，并填充颜色
    CGContextSetStrokeColorWithColor(context, [UIColor colorWithRed:1 green:0.58 blue:0.62 alpha:1.00].CGColor);//画笔线的颜色
    CGContextSetLineWidth(context, 1.0);//线的宽度
    
    CGContextSetFillColorWithColor(context, [UIColor whiteColor].CGColor);//填充颜色
    CGContextAddRect(context, CGRectMake(0, 0, self.frame.size.width, self.frame.size.height));// 画方框
    CGContextDrawPath(context, kCGPathFillStroke);//绘画路径
    
    for (int i = 1; i < self.frame.size.height / bigSpace; i++) {
        CGContextMoveToPoint(context, 0, self.frame.size.height - bigSpace * i);
        CGContextAddLineToPoint(context, self.frame.size.width, self.frame.size.height - bigSpace * i);
        CGContextStrokePath(context);
    }
    for (int i = 1; i < self.frame.size.width / bigSpace ; i++) {
        CGContextMoveToPoint(context, bigSpace * i, 0);
        CGContextAddLineToPoint(context, bigSpace * i, self.frame.size.height);
        CGContextStrokePath(context);
    }
    
    CGContextSetLineWidth(context, 0.2);//线的宽度
    //    CGFloat lengths[] = {5,2};
    //    CGContextSetLineDash(context, 0, lengths, 2);
    for (int j = 1; j < self.frame.size.height / smallSpace; j++) {
        CGContextMoveToPoint(context, 0, self.frame.size.height - smallSpace * j);
        CGContextAddLineToPoint(context, self.frame.size.width, self.frame.size.height - smallSpace * j);
        CGContextStrokePath(context);
    }
    
    for (int j = 1; j < self.frame.size.width / smallSpace; j++) {
        CGContextMoveToPoint(context, smallSpace * j, 0);
        CGContextAddLineToPoint(context, smallSpace * j, self.frame.size.height);
        CGContextStrokePath(context);
    }
}
@end
