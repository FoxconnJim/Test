//
//  iRonIconImageView.m
//  tf02
//
//  Created by IDSBG-00 on 2016/9/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "iRonIconImageView.h"
#import "iRonIconCell.h"
#import "Utility.h"
#import "NSObject+JZStoreValue.h"
#import "JZFamilyInfo.h"
#import "UIAlertController+MZAdd.h"

@interface iRonIconImageView()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) JZFamilyInfo *familyInfo;

@end
@implementation iRonIconImageView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = appBackgroundColor;
        CGRect frame = self.bounds;
        frame.size.height -= (44+20);
        UITableView *tbView = [[UITableView alloc] initWithFrame:frame style:UITableViewStyleGrouped];
        tbView.backgroundColor = appBackgroundColor;
        tbView.delegate = self;
        tbView.dataSource = self;
        [self addSubview: tbView];
    }
    return self;
}

#pragma mark UITableViewDelegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        
        return 1;
    } else {
        
        return 3;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"iRonImageCellid";
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleValue1 reuseIdentifier:cellid];
    if (!cell) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    }
    cell.backgroundColor = [UIColor whiteColor];
    
    if (indexPath.section == 0) {
        iRonIconCell *iconCell = [[iRonIconCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"iRonCellID"];
        iconCell.selectionStyle = UITableViewCellSelectionStyleNone;
        [iconCell.iconImageView sd_setImageWithURL:[NSURL URLWithString: self.familyInfo.photo] placeholderImage:[UIImage imageNamed:@"默认"]];
        iconCell.familyNameLabel.text = self.familyInfo.family;
   
        return iconCell;
        
    } else if (indexPath.section == 1) {
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(screenW / 2, 0, screenW / 2 - 40, 44)];
        lbl.text = @"1.0.0";
        lbl.textAlignment = NSTextAlignmentRight;
        switch (indexPath.row) {
            case 0:
                cell.textLabel.text = @"家庭名称";
                cell.detailTextLabel.text = self.familyInfo.family;
                break;
            case 1:
                cell.textLabel.text = @"手机";
                cell.detailTextLabel.text = self.familyInfo.tel;
                break;
            case 2:
                cell.textLabel.text = @"邮箱";
                cell.detailTextLabel.text = self.familyInfo.mail;
                break;
                
            default:
                break;
        }
        
    }
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return YES;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        
        return 100 + mySectionHeight;
        
    } else {
        
        return myRowHeight;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.01;
        
    } else if (section == 1) {
        return 0.01;
        
    } else {
        return mySectionHeight;
        
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.delegate respondsToSelector:@selector(didSelectRowAtIndexPath:)]) {
        [self.delegate didSelectRowAtIndexPath:indexPath];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}



- (JZFamilyInfo *)familyInfo
{
    if (!_familyInfo) {
        _familyInfo = [JZFamilyInfo valueByKey: kFamilyInfo ];
    }
    return _familyInfo;
}

@end
