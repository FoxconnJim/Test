//
//  JZLineChartDataLayer.h
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface JZLineChartDataLayer : CAShapeLayer

@property (nonatomic, strong) NSMutableArray *pointArray;
@property (nonatomic, assign) CGFloat jzLayerScale;

- (instancetype)initWithFrame: (CGRect)frame;

@end
