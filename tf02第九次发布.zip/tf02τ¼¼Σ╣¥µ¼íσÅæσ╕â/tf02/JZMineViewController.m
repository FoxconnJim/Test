//
//  JZMineViewController.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZMineViewController.h"
#import "JZMineView.h"  

#import "JZHPwodejiatingViewController.h"
#import "JZHPbangzhuViewController.h"
#import "JZHPyijianfankuiViewController.h"

#import "JZzixunshoucangViewController.h"
#import "JZLoginViewController.h"
#import "JZpromptLabel.h"

#import "iRonIconImageViewController.h"
#import "UIAlertController+MZAdd.h"
#import "JZContactUsViewController.h"
#import "JZMeasureRemindTableViewController.h"

#import "UMSocialUIManager.h"
#import <UMSocialCore/UMSocialCore.h>
#import "UMSocialSinaHandler.h"

#import "JZOperation.h"

@interface JZMineViewController () <JZMineViewDelegate,JZOperationDelegate>

@property (nonatomic, strong)JZpromptLabel *promptLabel;

@property (nonatomic, strong) NSOperationQueue *queue;

@end

@implementation JZMineViewController

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (JZMineView *)mineView
{
    if (!_mineView) {
        _mineView = [[JZMineView alloc] initWithFrame:self.view.bounds];
        _mineView.delegate = self;
    }
    return _mineView;
}

- (JZpromptLabel *)promptLabel
{
    if (!_promptLabel) {
        _promptLabel = [[JZpromptLabel alloc] init];
    }
    return _promptLabel;
}

- (void)viewDidLoad {
    [super viewDidLoad];


    [self.view addSubview: self.mineView];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
}

- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            if (indexPath.row == 0) {
                [self banbengengxinAction];
            } else if (indexPath.row == 1) {
                [self AppfenxiangAction];
            } else if (indexPath.row == 2) {
                [self bangzhuyufankuiAction];
            } else if (indexPath.row == 3) {
                [self lianxiwomenAction];
            }
        } else {
            if (indexPath.row == 0) {
                //我的家庭
                JZHPwodejiatingViewController *wdjtVC = [[JZHPwodejiatingViewController alloc] init];
                wdjtVC.personInfoArray = [NSMutableArray valueByKey: kAllFamilyMembersInfo];
                [self.tabBarController.navigationController pushViewController: wdjtVC animated:YES];
            } else if (indexPath.row == 1) {
                //资讯收藏
                JZzixunshoucangViewController *zxscVC = [[JZzixunshoucangViewController alloc] init];
                [self.tabBarController.navigationController pushViewController: zxscVC animated:YES];
            } else if (indexPath.row == 2) {
                //测量提醒
                JZMeasureRemindTableViewController *measureRemindTVC = [[JZMeasureRemindTableViewController alloc] init];
                [self.tabBarController.navigationController pushViewController:measureRemindTVC animated:YES];
            }

        }

    }else if (indexPath.section == 2) {
        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            [self tuichudengluAction];
        } else {
            if (indexPath.row == 0) {
                [self banbengengxinAction];
            }else if (indexPath.row == 1){
                [self AppfenxiangAction];
            }else if (indexPath.row == 2){
                [self bangzhuyufankuiAction];
            }else if (indexPath.row == 3){
                [self lianxiwomenAction];
            }
        }
    } else if (indexPath.section == 3) {
        [self tuichudengluAction];
    }
}

- (void)banbengengxinAction
{
    JZOperation *operation = [JZOperation operationWithURLString:@"http://120.76.233.207/TF02/V2/version/iosversion.json" andParam:nil getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = @"banbengengxin";

}

- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    if ([operation.name isEqualToString:@"banbengengxin"]) {
        NSLog(@"~~~responseObject=%@",responseObject);
        //本地版本号
        NSString *curVersion= [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
        
        if ([responseObject[@"versionCode"] floatValue] > [curVersion floatValue]) {
            UIAlertController *alertCtl = [UIAlertController alertControllerWithTitle:@"有更新哦" message:responseObject[@"updateContent"] preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
            UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                //TODO: 跳转动作
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"itms-services:///?action=download-manifest&url=https://10.244.171.106/AppDownload/iFoxEKnowniRon.plist"]];
            }];
            
            [alertCtl addAction:cancel];
            [alertCtl addAction:ok];
            [self presentViewController:alertCtl animated:YES completion:nil];
        } else {
            [LCProgressHUD showInfoMsg:@"当前已是最新版本"];
        }
    }
}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    
}

- (void)AppfenxiangAction
{
    NSString *title = @"医疗平板长照App";
    NSString *content = @"医疗平板长照App";
    UIImage *image = [UIImage imageNamed:@"JZAppIcon"];
    NSURL *url = [NSURL URLWithString:@"https://10.244.171.106/AppDownload/jsp/download.html"];
    NSArray *activityItems = @[title, content, image, url];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:nil];
    activityVC.excludedActivityTypes = @[UIActivityTypePostToFacebook,
                                         UIActivityTypePostToTwitter,
                                         UIActivityTypePrint,
                                         UIActivityTypeAssignToContact,
                                         UIActivityTypeSaveToCameraRoll,
                                         UIActivityTypeAddToReadingList,
                                         UIActivityTypePostToFlickr,
                                         UIActivityTypePostToVimeo,
                                         UIActivityTypePostToTencentWeibo,
                                         UIActivityTypeAirDrop];
    NSString* deviceType = [UIDevice currentDevice].model;
    if ([deviceType isEqualToString:@"iPhone"]) {

        [self presentViewController:activityVC animated:YES completion:nil];
        activityVC.completionWithItemsHandler = ^(UIActivityType activityType, BOOL completed, NSArray * returnedItems, NSError * activityError) {
            if (activityType == UIActivityTypePostToWeibo) {
                if (completed) {
                    [LCProgressHUD showInfoMsg:@"微博分享已完成"];

                }
            }
        };
    } else if ([deviceType isEqualToString:@"iPad"]) {
        UIPopoverPresentationController *popover = activityVC.popoverPresentationController;

        if (popover) {
            popover.permittedArrowDirections = UIPopoverArrowDirectionUp;
            //设置相关属性
            popover.sourceView = self.view;
            popover.sourceRect = CGRectMake(screenW - 40, 0, 1, 1);
            popover.backgroundColor = [UIColor whiteColor];
        }

        [self presentViewController:activityVC animated:YES completion:nil];
    }
    //显示分享面板
//    __weak typeof(self) weakSelf = self;
//    [UMSocialUIManager showShareMenuViewInWindowWithPlatformSelectionBlock:^(UMShareMenuSelectionView *shareSelectionView, UMSocialPlatformType platformType) {
//
//        [weakSelf shareWebPageToPlatformType:platformType];
//    }];

}

//网页分享
- (void)shareWebPageToPlatformType:(UMSocialPlatformType)platformType
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];

    //创建网页内容对象
    //    UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:@"分享标题" descr:@"分享内容描述" thumImage:[UIImage imageNamed:@"icon"]];
    NSString* thumbURL =  @"http://weixintest.ihk.cn/ihkwx_upload/heji/material/img/20160414/1460616012469.jpg";
    UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:@"分享标题test test test" descr:@"分享内容描述 test test test" thumImage:thumbURL];
    //设置网页地址
    shareObject.webpageUrl =@"http://mobile.umeng.com/social";

    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;

    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:self completion:^(id data, NSError *error) {
        if (error) {
            UMSocialLogInfo(@"************Share fail with error %@*********",error);
        }else{
            if ([data isKindOfClass:[UMSocialShareResponse class]]) {
                UMSocialShareResponse *resp = data;
                //分享结果消息
                UMSocialLogInfo(@"response message is %@",resp.message);
                //第三方原始返回的数据
                UMSocialLogInfo(@"response originalResponse data is %@",resp.originalResponse);

            }else{
                UMSocialLogInfo(@"response data is %@",data);
            }
        }
        [self alertWithError:error];
    }];
}

- (void)alertWithError:(NSError *)error
{
    NSString *result = nil;
    if (!error) {
        result = [NSString stringWithFormat:@"Share succeed"];
    }
    else{
        if (error) {
            result = [NSString stringWithFormat:@"Share fail with error code: %d\n",(int)error.code];
        }
        else{
            result = [NSString stringWithFormat:@"Share fail"];
        }
    }
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"share" message:result preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"sure", @"确定") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {

    }];
    [alertController addAction:okAction];
}

- (void)bangzhuyufankuiAction
{
    //帮助与反馈
    JZHPbangzhuViewController *bzVC = [[JZHPbangzhuViewController alloc] init];
    [self.navigationController pushViewController:bzVC animated:YES];
}

- (void)lianxiwomenAction
{
    //联系我们
    JZContactUsViewController *contactUsVC = [[JZContactUsViewController alloc] init];
    [self.tabBarController.navigationController pushViewController:contactUsVC animated:YES];
}

- (void)tuichudengluAction
{
    NSLog(@"退出登录");
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"您确定要注销登录吗" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *alertAction) {

        JZLoginViewController *loginVC = [[JZLoginViewController alloc] init];
        [UIApplication sharedApplication].keyWindow.rootViewController = loginVC;

    }];

    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler: ^(UIAlertAction *alertAction) {

    }];
    [alertController addAction: cancelAction];
    [alertController addAction: okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}
- (void)didSelectIconImage
{
    iRonIconImageViewController *iconControler = [[iRonIconImageViewController alloc] init];
    [self.navigationController pushViewController:iconControler animated:YES];
}

@end
