//
//  JZPadHandleData2017.m
//  tf02
//
//  Created by F7686324 on 2017/1/13.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZPadHandleData2017.h"

@interface JZPadHandleData2017()

@property (nonatomic, strong) NSMutableArray *xArray;
@property (nonatomic, strong) NSMutableArray *yArray;

@end

@implementation JZPadHandleData2017

- (NSMutableArray *)totalArray
{
    if (!_totalArray) {
        _totalArray = [NSMutableArray array];
    }
    return _totalArray;
}

- (NSMutableArray *)meatimeArray
{
    if (!_meatimeArray) {
        _meatimeArray = [NSMutableArray array];
    }
    return _meatimeArray;
}

- (NSMutableArray *)yArray
{
    if (!_yArray) {
        _yArray = [NSMutableArray array];
    }
    return _yArray;
}

- (NSMutableArray *)xArray
{
    if (!_xArray) {
        _xArray = [NSMutableArray array];
    }
    return _xArray;
}

- (instancetype)initWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString
{
    if (self = [super init]) {

        [self.xArray removeAllObjects];
        [self.yArray removeAllObjects];
        [self.meatimeArray removeAllObjects];
        [self.totalArray removeAllObjects];

        if ([timeLengthString isEqualToString:jzYear]) {

            dataArray = [dataArray sortByMonth];

            // 确定yArray、meatimeArray
            for (NSMutableArray *array in dataArray) {
                if (array.count) {
                    CGFloat dataValue = 0.f;
                    NSString *meatimeStr;
                    for (JZDataPoint *dataPoint in array) {
                        dataValue += [dataPoint.data floatValue];
                        meatimeStr = dataPoint.meatime;
                    }
                    [self.yArray addObject:[NSString stringWithFormat:@"%f", dataValue / array.count]];
                    [self.meatimeArray addObject:[self stringToFormatWithString:meatimeStr timeLengthString:timeLengthString]];
                }
            }

            CGFloat viewWidth = screenW - screenEdgeMargin * 2;
            CGFloat layerWidth = viewWidth - 10;
            CGFloat pointWidth = layerWidth / self.yArray.count;
            CGFloat showLayerWidth = layerWidth - pointWidth;

            // 确定xArray
            if (self.yArray.count >= 2) {
                for (int i = 0; i < self.yArray.count; i++) {
                    CGFloat x = pointWidth / 2 / layerWidth + showLayerWidth / layerWidth / (self.yArray.count - 1) * i;
                    [self.xArray addObject:[NSString stringWithFormat:@"%f", x]];
                }
            } else if (self.yArray.count == 1) {
                [self.xArray addObject:@"0.5"];
            }

        } else {
            dataArray = [dataArray changeOrder];

            CGFloat viewWidth = screenW - screenEdgeMargin * 2;
            CGFloat layerWidth = viewWidth - 10;
            CGFloat pointWidth = layerWidth / dataArray.count;
            CGFloat showLayerWidth = layerWidth - pointWidth;

            if (dataArray.count >= 2) {
                for (int i = 0; i < dataArray.count; i++) {
                    JZDataPoint *dataPoint = [dataArray objectAtIndex:i];
                    CGFloat x = pointWidth / 2 / layerWidth + showLayerWidth / layerWidth / (dataArray.count - 1) * i;
                    [self.xArray addObject:[NSString stringWithFormat:@"%f", x]];
                    [self.yArray addObject:[NSString stringWithFormat:@"%@", dataPoint.data]];
                    [self.meatimeArray addObject:[self stringToFormatWithString:dataPoint.meatime timeLengthString:timeLengthString]];
                }
            } else if (dataArray.count == 1) {
                JZDataPoint *dataPoint = [dataArray firstObject];
                [self.xArray addObject:@"0.5"];
                [self.yArray addObject:dataPoint.data];
                [self.meatimeArray addObject:[self stringToFormatWithString:dataPoint.meatime timeLengthString:timeLengthString]];
            }
        }

        if (self.xArray.count == self.yArray.count) {
            for (int i = 0; i < self.xArray.count; i++) {
                NSString *xStr = self.xArray[i];
                NSString *yStr = self.yArray[i];
                JZPoint *point = [JZPoint pointWithX:xStr.floatValue y:yStr.floatValue];
                [self.totalArray addObject:point];
            }
        } else {
            NSLog(@"横纵坐标数不等");
        }
    }
    return self;
}

- (nonnull NSString *)stringToFormatWithString:(NSString *)string timeLengthString:(NSString *)timeLengthString
{
    if (string) {
        NSArray *Arr = [string componentsSeparatedByString:@" "];
        NSArray *arr = [Arr.firstObject componentsSeparatedByString:@"-"];
        NSString *yearStr = [arr objectAtIndex:0];
        NSString *monthStr = [arr objectAtIndex:1];
        NSString *dayStr = [arr objectAtIndex:2];
        NSString *meatimeStr;
        if ([timeLengthString isEqualToString:jzYear]) {
            meatimeStr = [NSString stringWithFormat:@"%@/%@", yearStr, monthStr];

        } else {
            meatimeStr = [NSString stringWithFormat:@"%@/%@", monthStr, dayStr];
        }
        return meatimeStr;

    } else {
        return @"";
    }

}

+ (instancetype)dataWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString
{
    return [[self alloc] initWithArray:dataArray timeLengthString:timeLengthString];
}

@end
