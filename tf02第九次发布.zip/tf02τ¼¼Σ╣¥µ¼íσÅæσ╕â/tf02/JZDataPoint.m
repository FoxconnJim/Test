//
//  JZDataPoint.m
//  tf02
//
//  Created by F7686324 on 01/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZDataPoint.h"

@implementation JZDataPoint

- (void)setMeatime:(NSString *)meatime
{
    _meatime = meatime;
}

- (void)setData:(NSString *)data
{
    _data = data;
}

- (instancetype)initWithMeatime:(NSString *)meatime data:(NSString *)data
{
    if (self = [super init]) {

        self.meatime = meatime;
        self.data = data;
    }
    return self;
}

+ (instancetype)dataPointWithMeatime:(NSString *)meatime data:(NSString *)data
{
    return [[self alloc] initWithMeatime:meatime data:data];
}
@end
