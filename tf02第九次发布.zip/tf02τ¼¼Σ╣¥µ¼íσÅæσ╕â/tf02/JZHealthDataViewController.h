//
//  JZHealthDataViewController.h
//  tf02
//
//  Created by AN PEN on 5/16/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZHealthDataViewController : UIViewController

@property (nonatomic, copy) NSString *jzType;
@property (nonatomic, strong) NSMutableArray *detailDataArray;
@property (nonatomic, copy) NSString *timeLengthString;

@end
