//
//  JZjiayizixunViewController.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZjiayizixunViewController.h"
#import "Utility.h"
#import "JZh5View.h"
#import "JZGoBackView.h"

#import "NSString+Hash.h"
#import "NSString+Date.h"

#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVFoundation.h>
#import <MediaPlayer/MediaPlayer.h>

#import "JZFamilyInfo.h"
#import <Photos/Photos.h>


@interface JZjiayizixunViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate, PHPhotoLibraryChangeObserver>

@property (nonatomic, strong) JZh5View *h5View;
@property (nonatomic, strong) JZGoBackView *goBackView;
@property (nonatomic, strong) UIImagePickerController *imagePickerController;
@property (nonatomic, strong) PHFetchResult *assetsFetchResults;
@property (nonatomic) BOOL needLogin;

@end

@implementation JZjiayizixunViewController

@synthesize needLogin;

- (JZGoBackView *)goBackView
{
    if (!_goBackView) {
        _goBackView = [[JZGoBackView alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
        [_goBackView.backBtn addTarget: self action:@selector(clickGoBack) forControlEvents:UIControlEventTouchUpInside];
        [_goBackView.closeBtn addTarget: self action:@selector(clickClose) forControlEvents:UIControlEventTouchUpInside];
    }
    return _goBackView;
}


- (UIImagePickerController *)imagePickerController
{
    if (!_imagePickerController) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.delegate = self;
        _imagePickerController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
        _imagePickerController.allowsEditing = YES;
//        _imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;

        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            _imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;

        }
    }
    return _imagePickerController;
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo {
    NSLog(@"%s", __FUNCTION__);
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"%s", __FUNCTION__);

}
#pragma mark - UIImageViewPickerDelegate 相机/相册 回调
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    NSLog(@"%s", __FUNCTION__);

    //选择完成后dismiss选择控制器，同时处理选择的图
    [picker dismissViewControllerAnimated:YES completion:^
     {
         //info中有选中图片的全部信息，根据需要去获取，此处获取的为原图
         UIImage *choiceImage = [info objectForKey:UIImagePickerControllerOriginalImage];

         if (picker.sourceType == UIImagePickerControllerSourceTypeCamera)
         {
             //若为相机拍摄则保存到相册
             UIImageWriteToSavedPhotosAlbum(choiceImage, NULL, NULL, NULL);
         }
     }];
}

- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    NSLog(@"%s", __FUNCTION__);

}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"家医咨询";
    needLogin = YES;
    JZGoBackView *backView = [[JZGoBackView alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
    [backView.closeBtn removeFromSuperview];
    [backView.backBtn addTarget:self action:@selector(clickToBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backView];
    self.navigationItem.leftBarButtonItem = backBarButtonItem;
    self.h5View = [[JZh5View alloc] initWithFrame: CGRectMake(0, 0, screenW, screenH - statusBarHeight - naviHeight)];
    [self.view addSubview:self.h5View];

    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusRestricted ||
        status == PHAuthorizationStatusDenied) {
        // 这里便是无访问权限
        //可以弹出个提示框，叫用户去设置打开相册权限
        NSLog(@"无权限");
    }  else {
        //这里就是有权限
        NSLog(@"有权限");

    }

    [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];    //创建监听者





    
}

//相册变化回调
- (void)photoLibraryDidChange:(PHChange *)changeInstance
{
    NSLog(@"photoLibraryDidChange");
    dispatch_sync(dispatch_get_main_queue(), ^{
        //修改UI
        self.h5View.isCamera = YES;
    });

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (needLogin) {
        needLogin = NO;
        NSString *user_id = [[JZFamilyInfo valueByKey:kFamilyInfo] account];
        NSDate *date = [NSDate date];
        NSString *atime = [NSString stringWithFormat:@"%ld", (long)[date timeIntervalSince1970]];
        NSString *partner = @"fushikang_h5";
        NSString *partner_key = @"alsdj8da2x90sopn";
        NSString *sign = [[NSString stringWithFormat:@"%@%@%@", partner_key, atime, user_id] md5String];
        NSString *urlStr = [NSString stringWithFormat:@"%@?user_id=%@&partner=%@&atime=%@&sign=%@", chunyuyishengJYZXURL, user_id, partner, atime, sign];

        self.h5View.urlString = urlStr;
    }

}

- (void)clickToBack
{
    NSLog(@"clickToBack");
    if (self.h5View.webView.canGoBack) {
        [self.h5View.webView goBack];
        UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.goBackView];
        self.navigationItem.leftBarButtonItem = backBarButtonItem;
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)clickGoBack
{
    NSLog(@"clickGoBack");
    if (self.h5View.webView.canGoBack) {
        [self.h5View.webView goBack];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)clickClose
{
    NSLog(@"clickClose");
    [self.navigationController popViewControllerAnimated:YES];
}


@end
