//
//  JZHPwodejiatingFrame.h
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZHPwodejiatingFrame : NSObject

@property (nonatomic, assign) CGRect bgViewFrame;
@property (nonatomic, assign) CGRect imgViewFrame;
@property (nonatomic, assign) CGRect upLabelFrame;
@property (nonatomic, assign) CGRect downLabelFrame;
@property (nonatomic, assign) CGFloat cellHeight;
@property (nonatomic, assign) CGRect arrowFrame;
@end
