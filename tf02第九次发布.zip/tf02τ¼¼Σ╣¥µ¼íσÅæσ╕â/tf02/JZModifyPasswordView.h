//
//  JZModifyPasswordView.h
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZCustomField.h"
#import "JZModifyPasswordFrame.h"
#import "JZTipView.h"

@interface JZModifyPasswordView : UIView

@property (nonatomic, strong) JZModifyPasswordFrame *modifyPasswordFrame;
@property (nonatomic, strong) UIImageView *backgroundImageView;

@property (nonatomic, strong) UIImageView *imgView;

@property (nonatomic, strong) UILabel *title;

@property (nonatomic, strong) UILabel *upLabel;
@property (nonatomic, strong) UILabel *upSublabel;
@property (nonatomic, strong) JZCustomField *upField;
@property (nonatomic, strong) JZTipView *upTipView;

@property (nonatomic, strong) UILabel *downLabel;
@property (nonatomic, strong) UILabel *downSublabel;
@property (nonatomic, strong) JZCustomField *downField;
@property (nonatomic, strong) JZTipView *downTipView;

@property (nonatomic, strong) UIButton *modifyBtn;

@property (nonatomic, strong) UIButton *backBtn;

@end
