//
//  JZPageControlView.h
//  tf02
//
//  Created by AN PEN on 4/13/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZADModel.h"   

@protocol JZPageControlViewDelegate <UIScrollViewDelegate>

@optional
- (void)clickToguanggaoWithCurrentPage: (NSInteger)currentPage;

@end

@interface JZPageControlView : UIView <UIScrollViewDelegate>
{
    NSInteger pageNumbers;
}
@property (nonatomic, strong) UIScrollView* helpScrView;
@property (nonatomic, strong) UIPageControl* pageCtrl;
@property (nonatomic, strong) NSMutableArray *ADModelArray;

@property (nonatomic, weak) id <JZPageControlViewDelegate> delegate;
@end
