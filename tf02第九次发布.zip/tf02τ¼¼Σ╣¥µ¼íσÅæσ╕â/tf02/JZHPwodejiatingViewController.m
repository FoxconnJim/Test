//
//  JZHPwodejiatingViewController.m
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHPwodejiatingViewController.h"
#import "Utility.h"
#import "JZPersonInfo.h"
#import "JZHPwodejiatingCell.h"
#import "MZMemberViewController.h"
#import "UIImageView+WebCache.h"

@interface JZHPwodejiatingViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) JZHPwodejiatingFrame *wdjtFrame;

@end

@implementation JZHPwodejiatingViewController

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - statusBarHeight - naviHeight) style:UITableViewStyleGrouped];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tbView.backgroundColor = appBackgroundColor;
    }
    return _tbView;
}

- (JZHPwodejiatingFrame *)wdjtFrame
{
    if (!_wdjtFrame) {
        _wdjtFrame = [[JZHPwodejiatingFrame alloc] init];
    }
    return _wdjtFrame;
}

- (void)setPersonInfoArray:(NSMutableArray *)personInfoArray
{
    _personInfoArray = personInfoArray;
    [self.tbView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的家庭";
    [self.view addSubview: self.tbView];
//    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addMember)];
}

//- (void)addMember
//{
//    MZAddMemberViewController *addMemberVC = [[MZAddMemberViewController alloc] init];
//    [self.navigationController pushViewController: addMemberVC animated:YES];
//}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.personInfoArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZPersonInfo *personInfo = self.personInfoArray[indexPath.row];
    JZHPwodejiatingCell *cell = [JZHPwodejiatingCell cellWithTableView: tableView];
    cell.personInfo = personInfo;

    [cell.imgView sd_setImageWithURL:[NSURL URLWithString:[personInfo picture]] placeholderImage:[UIImage imageNamed:@"默认"]];
    return cell; 
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return self.wdjtFrame.cellHeight + 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 10)];
    headerView.backgroundColor = appBackgroundColor;
    return headerView;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"选中第%ld行", (long)indexPath.row);
    MZMemberViewController *memberVC = [[MZMemberViewController alloc] init];
    memberVC.personInfo = self.personInfoArray[indexPath.row];
    [self.navigationController pushViewController: memberVC animated:YES];
    [tableView deselectRowAtIndexPath: indexPath animated:YES];

}
@end
