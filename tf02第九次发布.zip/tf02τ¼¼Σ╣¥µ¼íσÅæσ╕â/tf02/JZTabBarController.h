//
//  JZTabBarController.h
//  tf02
//
//  Created by AN PEN on 5/16/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZHomePageViewController.h"
#import "JZHealthIndicatorViewController.h"
#import "JZHealthServicesViewController.h"
#import "JZMineViewController.h"
#import "Utility.h"

@interface JZTabBarController : UITabBarController

@property (nonatomic, strong) JZHomePageViewController *homePageVC;
@property (nonatomic, strong) JZHealthIndicatorViewController *healthIndicatorVC;
@property (nonatomic, strong) JZHealthServicesViewController *healthServicesVC;
@property (nonatomic, strong) JZMineViewController *mineVC;

@end
