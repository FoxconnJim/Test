//
//  JZjinrituijianViewController.m
//  tf02
//
//  Created by F7686324 on 8/31/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZjinrituijianViewController.h"
#import "JZh5View.h"
#import "Utility.h"
#import "JZOperation.h"
#import "JZpromptLabel.h"
#import "JZHotNews.h"
#import "JZCollectAndShareView.h"

//#import "UMSocialUIManager.h"
//#import <UMSocialCore/UMSocialCore.h>
//#import "UMSocialSinaHandler.h"

#import "JZGoBackView.h"


@interface JZjinrituijianViewController () <JZOperationDelegate>

@property (nonatomic, strong) JZh5View *h5View;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) JZpromptLabel *promptLabel;
@property (nonatomic, strong) JZCollectAndShareView *collectAndShareView;
@property (nonatomic) BOOL isCollected;
@property (nonatomic, strong) JZGoBackView *goBackView;

@end

@implementation JZjinrituijianViewController

- (JZCollectAndShareView *)collectAndShareView
{
    if (!_collectAndShareView) {
        _collectAndShareView = [[JZCollectAndShareView alloc] initWithFrame:CGRectMake(0, 0, 60, 44)];
        [_collectAndShareView.shareBtn addTarget: self action:@selector(shareAction:) forControlEvents: UIControlEventTouchUpInside];
        [_collectAndShareView.collectBtn addTarget: self action:@selector(collectAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _collectAndShareView;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (JZh5View *)h5View
{
    if (!_h5View) {
        _h5View = [[JZh5View alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight)];
    }
    return _h5View;
}

- (JZpromptLabel *)promptLabel
{
    if (!_promptLabel) {
        _promptLabel = [[JZpromptLabel alloc] init];
    }
    return _promptLabel;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.isCollected = NO;
    [self.collectAndShareView.collectBtn setImage:[UIImage imageNamed:@"未收藏"] forState:UIControlStateNormal];
    UIBarButtonItem *shoucangItem = [[UIBarButtonItem alloc] initWithCustomView: self.collectAndShareView];
    self.navigationItem.rightBarButtonItem = shoucangItem;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%s", __FUNCTION__);

    self.view.backgroundColor = appBackgroundColor;
    self.title = @"今日推荐";
    [self.view addSubview: self.h5View];

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSLog(@"%s", __FUNCTION__);
    self.h5View.urlString = [self.hotNews urlString];

    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"tel"] = [[JZFamilyInfo valueByKey:kFamilyInfo] tel];
    param[@"id"] = self.hotNews.ID;
    JZOperation *operation = [JZOperation operationWithURLString:wethercollectionURL andParam:param getOrPost:JZ_POST];
    operation.name = wethercollectionOperation;
    operation.delegate = self;
}


- (JZGoBackView *)goBackView
{
    if (!_goBackView) {
        _goBackView = [[JZGoBackView alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
        [_goBackView.backBtn addTarget: self action:@selector(clickGoBack) forControlEvents:UIControlEventTouchUpInside];
        [_goBackView.closeBtn addTarget: self action:@selector(clickClose) forControlEvents:UIControlEventTouchUpInside];
    }
    return _goBackView;
}

- (void)setHotNews:(JZHotNews *)hotNews
{
    _hotNews = hotNews;
    NSLog(@"hotNews.urlString = %@", hotNews.urlString);
    NSLog(@"hotNews.delflag = %@", hotNews.delflag);
    JZGoBackView *backView = [[JZGoBackView alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
    [backView.closeBtn removeFromSuperview];
    [backView.backBtn addTarget:self action:@selector(clickToBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backView];
    self.navigationItem.leftBarButtonItem = backBarButtonItem;
}

- (void)clickToBack
{
    NSLog(@"clickToBack");
    if (self.h5View.webView.canGoBack) {
        [self.h5View.webView goBack];
        UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.goBackView];
        self.navigationItem.leftBarButtonItem = backBarButtonItem;
    } else {
        NSLog(@"NSThread.currentThread = %@", [NSThread currentThread]);

        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)clickGoBack
{
    NSLog(@"clickGoBack");
    if (self.h5View.webView.canGoBack) {
        [self.h5View.webView goBack];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)clickClose
{
    NSLog(@"clickClose");
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)collectAction:(UIButton *)btn
{
    [UIView animateWithDuration:0.3 delay:0 usingSpringWithDamping:0.3 initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.collectAndShareView.collectBtn.transform = CGAffineTransformMakeScale(1.5, 1.5);
    } completion:^(BOOL finished) {
        if (finished) {
            [UIView animateWithDuration:0.15 delay:0 usingSpringWithDamping:0.3 initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseIn animations:^{
                self.collectAndShareView.collectBtn.transform = CGAffineTransformIdentity;

            }completion:nil];
        }
    }];
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        self.promptLabel.jz_text = @"游客模式下无法收藏~";
        [self.view addSubview: self.promptLabel];
    } else {
        NSMutableDictionary *param = [NSMutableDictionary dictionary];
        param[@"tel"] = [[JZFamilyInfo valueByKey: kFamilyInfo] tel];
        param[@"id"] = self.hotNews.ID;

        if (self.isCollected) {
            JZOperation *operation = [JZOperation operationWithURLString:cancelshoucangURL andParam:param getOrPost:JZ_GET];
            operation.delegate = self;
            operation.name = cancelshoucangOperation;
        } else {
            JZOperation *operation = [JZOperation operationWithURLString:shoucangURL andParam:param getOrPost:JZ_GET];
            operation.delegate = self;
            operation.name = shoucangOperation;
        }

    }

}

- (void)shareAction: (UIButton *)btn
{
    NSString *title = self.hotNews.newsHead;
    NSString *content = self.hotNews.newsContent;
    UIImageView *imageView = [[UIImageView alloc] init];
    [imageView sd_setImageWithURL:[NSURL URLWithString:self.hotNews.newsFront] placeholderImage:[UIImage imageNamed:@"资讯"]];
    UIImage *image = imageView.image;
    NSURL *url = [NSURL URLWithString:self.hotNews.urlString];
    NSArray *activityItems = @[title, content, image, url];
    UIActivityViewController *activityVC = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:nil];
    activityVC.excludedActivityTypes = @[UIActivityTypePostToFacebook,
                                         UIActivityTypePostToTwitter,
                                         UIActivityTypePrint,
                                         UIActivityTypeAssignToContact,
                                         UIActivityTypeSaveToCameraRoll,
                                         UIActivityTypeAddToReadingList,
                                         UIActivityTypePostToFlickr,
                                         UIActivityTypePostToVimeo,
                                         UIActivityTypePostToTencentWeibo,
                                         UIActivityTypeAirDrop];
    NSString* deviceType = [UIDevice currentDevice].model;
    NSLog(@"deviceType = %@", deviceType);
    if ([deviceType isEqualToString:@"iPhone"]) {

        [self presentViewController:activityVC animated:YES completion:nil];
        activityVC.completionWithItemsHandler = ^(UIActivityType activityType, BOOL completed, NSArray * returnedItems, NSError * activityError) {
            if (activityType == UIActivityTypePostToWeibo) {
                if (completed) {
                    [LCProgressHUD showInfoMsg:@"微博分享已完成"];

                }
            }
        };
    } else if ([deviceType isEqualToString:@"iPad"]) {
        UIPopoverPresentationController *popover = activityVC.popoverPresentationController;

        if (popover) {
            popover.permittedArrowDirections = UIPopoverArrowDirectionUp;
            //设置相关属性
            popover.sourceView = self.view;
            popover.sourceRect = CGRectMake(screenW - 40, 0, 1, 1);
            popover.backgroundColor = [UIColor whiteColor];
        }

        [self presentViewController:activityVC animated:YES completion:nil];
    }
////    //显示分享面板
//    __weak typeof(self) weakSelf = self;
//    [UMSocialUIManager showShareMenuViewInWindowWithPlatformSelectionBlock:^(UMShareMenuSelectionView *shareSelectionView, UMSocialPlatformType platformType) {
//
//        [weakSelf shareWebPageToPlatformType:platformType];
//    }];
}

//网页分享
//- (void)shareWebPageToPlatformType:(UMSocialPlatformType)platformType
//{
//    //创建分享消息对象
//    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
//
//    //创建网页内容对象
//    //    UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:@"分享标题" descr:@"分享内容描述" thumImage:[UIImage imageNamed:@"icon"]];
//    NSString* thumbURL = self.hotNews.newsFront;
//    UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:self.hotNews.newsHead descr:self.hotNews.newsContent thumImage:thumbURL];
//    //设置网页地址
//    shareObject.webpageUrl = self.hotNews.urlString;
//
//    //分享消息对象设置分享内容对象
//    messageObject.shareObject = shareObject;
//
//    //调用分享接口
//    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:self completion:^(id data, NSError *error) {
//        if (error) {
//            UMSocialLogInfo(@"************Share fail with error %@*********",error);
//        }else{
//            if ([data isKindOfClass:[UMSocialShareResponse class]]) {
//                UMSocialShareResponse *resp = data;
//                //分享结果消息
//                UMSocialLogInfo(@"response message is %@",resp.message);
//                //第三方原始返回的数据
//                UMSocialLogInfo(@"response originalResponse data is %@",resp.originalResponse);
//
//            }else{
//                UMSocialLogInfo(@"response data is %@",data);
//            }
//        }
//        [self alertWithError:error];
//    }];
//}

- (void)alertWithError:(NSError *)error
{
    NSString *result = nil;
    if (!error) {
        result = [NSString stringWithFormat:@"Share succeed"];
    }
    else{
        if (error) {
            result = [NSString stringWithFormat:@"Share fail with error code: %d\n",(int)error.code];
        }
        else{
            result = [NSString stringWithFormat:@"Share fail"];
        }
    }
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"share" message:result preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"sure", @"确定") style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {

    }];
    [alertController addAction:okAction];
}


- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject {

    NSString *code = [NSString stringWithFormat:@"%@", responseObject[@"code"]];

    if ([operation.name isEqualToString:shoucangOperation]) {
        self.promptLabel.jz_text = [NSString stringWithFormat:@"%@", responseObject[@"info"]];
        [self.view addSubview: self.promptLabel];
        if (![code integerValue]) {
            self.isCollected = YES;
            [self.collectAndShareView.collectBtn setImage: [UIImage imageNamed:@"已收藏"] forState:UIControlStateNormal];
            UIBarButtonItem *shoucangItem = [[UIBarButtonItem alloc] initWithCustomView: self.collectAndShareView];
            self.navigationItem.rightBarButtonItem = shoucangItem;

            NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
            userInfo[@"tag"] = [NSString stringWithFormat:@"%ld", (long)self.hotNews.tag];
            [[NSNotificationCenter defaultCenter] postNotificationName:shoucangNotification object:self userInfo:userInfo];
        }
    } else if ([operation.name isEqualToString:cancelshoucangOperation]) {
        self.promptLabel.jz_text = [NSString stringWithFormat:@"%@", responseObject[@"info"]];
        [self.view addSubview: self.promptLabel];
        if (![code integerValue]) {
            self.isCollected = NO;
            [self.collectAndShareView.collectBtn setImage:[UIImage imageNamed:@"未收藏"] forState:UIControlStateNormal];
            UIBarButtonItem *shoucangItem = [[UIBarButtonItem alloc] initWithCustomView: self.collectAndShareView];
            self.navigationItem.rightBarButtonItem = shoucangItem;

            NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
            userInfo[@"tag"] = [NSString stringWithFormat:@"%ld", (long)self.hotNews.tag];
            [[NSNotificationCenter defaultCenter] postNotificationName:cancelshoucangNotification object:self userInfo:userInfo];
        }

    } else if ([operation.name isEqualToString:wethercollectionOperation]) {
        if (code.integerValue == 0) {
            self.isCollected = YES;
            [self.collectAndShareView.collectBtn setImage:[UIImage imageNamed:@"已收藏"] forState:UIControlStateNormal];
            UIBarButtonItem *shoucangItem = [[UIBarButtonItem alloc] initWithCustomView: self.collectAndShareView];
            self.navigationItem.rightBarButtonItem = shoucangItem;
        } else if (code.integerValue == 1) {
            self.promptLabel.jz_text = [NSString stringWithFormat:@"%@", responseObject[@"info"]];
            [self.view addSubview: self.promptLabel];
        } else if (code.integerValue == 2) {
            self.isCollected = NO;
            [self.collectAndShareView.collectBtn setImage:[UIImage imageNamed:@"未收藏"] forState:UIControlStateNormal];
            UIBarButtonItem *shoucangItem = [[UIBarButtonItem alloc] initWithCustomView: self.collectAndShareView];
            self.navigationItem.rightBarButtonItem = shoucangItem;
        }
    }

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error {
    if (error.code == -1009) {
        [LCProgressHUD showFailure:@"网络有点卡..."];

    }
}


//- (NSArray<id<UIPreviewActionItem>> *)previewActionItems {
////     setup a list of preview actions
//
//    UIPreviewAction *action1 = [UIPreviewAction actionWithTitle:@"收藏" style:UIPreviewActionStyleDefault handler:^(UIPreviewAction * _Nonnull action, UIViewController * _Nonnull previewViewController) {
//        if ([[self.hotNews delflag] integerValue] == 0) {
//            [self collectAction:[[UIButton alloc] init]];
//        }
//    }];
//
//    UIPreviewAction *action2 = [UIPreviewAction actionWithTitle:@"分享" style:UIPreviewActionStyleDefault handler:^(UIPreviewAction * _Nonnull action, UIViewController * _Nonnull previewViewController) {
//        [self shareAction:[[UIButton alloc] init]];
//    }];
//
//    NSArray *actions = @[action1,action2];
//    return actions;
////     and return them (return the array of actions instead to see all items ungrouped)
//}
@end
