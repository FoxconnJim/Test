//
//  JZMineView.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZMineView.h"
#import "JZNewsCell.h"
#import "iRonIconCell.h"
#import "JZFamilyInfo.h"

@implementation JZMineView

- (JZMineFrame *)mineFrame
{
    if (!_mineFrame) {
        _mineFrame = [[JZMineFrame alloc] init];
    }
    return _mineFrame;
}

- (UIImageView *)iconImg
{
    if (!_iconImg) {
        _iconImg = [[UIImageView alloc] initWithFrame: self.mineFrame.iconImgFrame];
        _iconImg.layer.cornerRadius = self.mineFrame.iconImgFrame.size.height / 2;
        _iconImg.layer.masksToBounds = YES;
    }
    return _iconImg;
}

- (UILabel *)iconName
{
    if (!_iconName) {
        _iconName = [[UILabel alloc] initWithFrame: self.mineFrame.iconNameFrame];
        _iconName.textAlignment = NSTextAlignmentCenter;
        _iconName.adjustsFontSizeToFitWidth = YES;
    }
    return _iconName;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = appBackgroundColor;

        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight - tabBarHeight) style:UITableViewStyleGrouped];
        _tbView.backgroundColor = appBackgroundColor;
        _tbView.delegate = self;
        _tbView.dataSource = self;
        [self addSubview: _tbView];
        
    }
    return self;
}

#pragma mark UITableViewDelegate methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        return 3;
    } else {
        return 4;

    }

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        if (section == 0) {
            return 1;
        } else if (section == 1) {
            return 4;
        } else {
            return 1;
        }
    } else {
        if (section == 0) {

            return 1;
        } else if (section == 1) {

            return 3;
        } else if (section == 2){

            return 4;
        }else{
            return 1;
        }
    }

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"JZMineCellid";
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleValue1 reuseIdentifier:cellid];
    if (!cell) {
        cell = [tableView dequeueReusableCellWithIdentifier: cellid];
    }
    cell.backgroundColor = [UIColor whiteColor];
    cell.separatorInset = UIEdgeInsetsMake(0, 15, 0, 0);
    if (indexPath.section == 0) {
//        JZNewsCell *iconCell = [JZNewsCell cellWithTableView: tableView];
        iRonIconCell *iconCell = [[iRonIconCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"iRonCellID"];
        iconCell.selectionStyle = UITableViewCellSelectionStyleNone;
        JZFamilyInfo *familyInfo = [JZPersonInfo valueByKey:kFamilyInfo];
        NSLog(@"family.photo = %@", familyInfo.photo);
        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            iconCell.iconImageView.image = [UIImage imageNamed:@"游客"];
            iconCell.familyNameLabel.text = @"游客";
        } else {
            [iconCell.iconImageView sd_setImageWithURL:[NSURL URLWithString: [familyInfo photo]] placeholderImage:[UIImage imageNamed:@"默认"]];
            iconCell.familyNameLabel.text = familyInfo.family;
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageViewPress)];
            [iconCell addGestureRecognizer:tap];
        }

        

        return iconCell;

    } else if (indexPath.section == 1) {

        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            switch (indexPath.row) {
                case 0:
                    [cell.imageView setImage:[UIImage imageNamed:@"banbengengxin"]];
                    cell.textLabel.text = @"版本更新";
                    cell.detailTextLabel.text = @"2.7";
                    break;
                case 1:
                    [cell.imageView setImage:[UIImage imageNamed:@"appfenxiang"]];
                    cell.textLabel.text = @"APP分享";
                    break;
                case 2:
                    [cell.imageView setImage:[UIImage imageNamed:@"mineSetting"]];
                    cell.textLabel.text = @"帮助与反馈";
                    break;
                case 3:
                    [cell.imageView setImage:[UIImage imageNamed:@"lianxiwomen"]];
                    cell.textLabel.text = @"联系我们";
                    break;
                default:
                    break;
            }
        } else {
            switch (indexPath.row) {
                case 0:
                    [cell.imageView setImage:[UIImage imageNamed:@"wodejiating"]];
                    cell.textLabel.text = @"我的家庭";
                    break;
                case 1:
                    [cell.imageView setImage:[UIImage imageNamed:@"zixunshoucang"]];
                    cell.textLabel.text = @"资讯收藏";
                    break;
                case 2:
                    [cell.imageView setImage:[UIImage imageNamed:@"celiangtixing"]];
                    cell.textLabel.text = @"测量提醒";
                    break;

                default:
                    break;
            }
        }

    }else if (indexPath.section == 2) {
        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, screenW, 44)];
            lbl.textAlignment = NSTextAlignmentCenter;
            lbl.text = @"退出登录";
            [cell addSubview:lbl];
        } else {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            switch (indexPath.row) {
                case 0:
                    [cell.imageView setImage:[UIImage imageNamed:@"banbengengxin"]];
                    cell.textLabel.text = @"版本更新";
                    cell.detailTextLabel.text = @"2.7";

                    break;
                case 1:
                    [cell.imageView setImage:[UIImage imageNamed:@"appfenxiang"]];
                    cell.textLabel.text = @"APP分享";
                    break;
                case 2:
                    [cell.imageView setImage:[UIImage imageNamed:@"mineSetting"]];
                    cell.textLabel.text = @"帮助与反馈";

                    break;
                case 3:
                    [cell.imageView setImage:[UIImage imageNamed:@"lianxiwomen"]];
                    cell.textLabel.text = @"联系我们";

                    break;
                    
                default:
                    break;
            }

        }
    } else {
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, screenW, 44)];
        lbl.textAlignment = NSTextAlignmentCenter;
        lbl.text = @"退出登录";
        [cell addSubview:lbl];
    }

    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{

    return YES;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {

        return 100 + mySectionHeight;

    } else {

        return myRowHeight;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.01;

    } else if (section == 1) {
        return 0.01;

    } else {
        return mySectionHeight / 2;

    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.delegate didSelectRowAtIndexPath: indexPath];
    [tableView deselectRowAtIndexPath: indexPath animated:YES];
}
//icon->imageView点击事件
- (void)imageViewPress
{
    if ([self.delegate respondsToSelector:@selector(didSelectIconImage)]) {

        [self.delegate didSelectIconImage];
    }
}


@end
