//
//  JZyishoucangViewController.h
//  tf02
//
//  Created by F7686324 on 9/26/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JZHotNews;
@interface JZyishoucangViewController : UIViewController

@property (nonatomic, strong) JZHotNews *hotNews;

@end
