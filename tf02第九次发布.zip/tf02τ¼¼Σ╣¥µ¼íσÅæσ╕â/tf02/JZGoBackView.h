//
//  JZGoBackView.h
//  tf02
//
//  Created by AN PEN on 8/13/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZGoBackView : UIView

@property (nonatomic, strong) UIButton *backBtn;
@property (nonatomic, strong) UIButton *closeBtn;

@end
