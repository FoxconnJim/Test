//
//  JZModifyPasswordViewController.m
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZModifyPasswordViewController.h"
#import "JZModifyPasswordView.h"
#import "JZOperation.h"
#import <MessageUI/MessageUI.h>
#import "JZGetCaptchaViewController.h"
#import <SMS_SDK/SMSSDK.h>
#import "LCProgressHUD.h"
#import "JZLoginViewController.h"


@interface JZModifyPasswordViewController () <JZOperationDelegate>

@property (nonatomic, strong) JZModifyPasswordView *modifyPasswordView;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) JZLoginViewController *loginVC;

@end

@implementation JZModifyPasswordViewController

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (void)setAccount:(NSString *)account
{
    _account = account;
}

- (JZModifyPasswordView *)modifyPasswordView
{
    if (!_modifyPasswordView) {
        _modifyPasswordView = [[JZModifyPasswordView alloc] initWithFrame:self.view.bounds];
        _modifyPasswordView.title.text = @"设置新密码";
        _modifyPasswordView.upLabel.text = @"新密码:";
        _modifyPasswordView.upSublabel.text = @"请输入6-20位数字字母组合";
        _modifyPasswordView.upField.text = @"";

        _modifyPasswordView.downLabel.text = @"再次输入:";
        _modifyPasswordView.downSublabel.text = @"请输入一致密码";
        _modifyPasswordView.downField.text = @"";

        [_modifyPasswordView.upField addTarget:self action:@selector(upInputAction:) forControlEvents:UIControlEventEditingChanged];
        [_modifyPasswordView.downField addTarget:self action:@selector(downInputAction:) forControlEvents:UIControlEventEditingChanged];
        [_modifyPasswordView.modifyBtn setTitle:@"修改" forState:UIControlStateNormal];
        [_modifyPasswordView.modifyBtn addTarget:self action:@selector(clickToModifyPassword) forControlEvents:UIControlEventTouchUpInside];
        [_modifyPasswordView.backBtn addTarget:self action:@selector(clickBackToLast) forControlEvents:UIControlEventTouchUpInside];

    }
    return _modifyPasswordView;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor whiteColor];

    [self.view addSubview:self.modifyPasswordView];
}

- (void)upInputAction:(JZCustomField *)textField
{
    self.modifyPasswordView.upTipView.OK = NO;
    [self.modifyPasswordView addSubview:self.modifyPasswordView.upTipView];
    NSString *regex = @"^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];

    if (textField.text.length >= 6 && textField.text.length <= 20) {
        if ([predicate evaluateWithObject:textField.text]) {
            self.modifyPasswordView.upTipView.OK = YES;
        }
    } else if (textField.text.length == 0) {
        [self.modifyPasswordView.upTipView removeFromSuperview];
    }

}

- (void)downInputAction:(JZCustomField *)textField
{
    self.modifyPasswordView.downTipView.OK = NO;
    [self.modifyPasswordView addSubview:self.modifyPasswordView.downTipView];

    if (textField.text.length >= 6 && textField.text.length <= 20) {
        if ([textField.text isEqualToString:self.modifyPasswordView.upField.text]) {
            self.modifyPasswordView.downTipView.OK = YES;
        }
    } else if (textField.text.length == 0) {
        [self.modifyPasswordView.downTipView removeFromSuperview];
    }
}

- (void)clickToModifyPassword
{
    [self.modifyPasswordView.upField resignFirstResponder];
    [self.modifyPasswordView.downField resignFirstResponder];
    if ([self.modifyPasswordView.upField.text isEqualToString:self.modifyPasswordView.downField.text]) {
        if (self.modifyPasswordView.upTipView.OK && self.modifyPasswordView.downTipView.OK) {
            NSMutableDictionary *param = [NSMutableDictionary dictionary];
            param[@"tel"] = self.account;
            param[@"pwd"] = self.modifyPasswordView.upField.text;

            JZOperation *operation = [JZOperation operationWithURLString:changePwdByTel andParam:param getOrPost:JZ_POST];
            operation.delegate = self;
            operation.name = findBackPasswordByTelOperation;
        } else {
            [LCProgressHUD showInfoMsg:@"请输入6-20位数字字母组合的密码"];
        }

    } else {
        [LCProgressHUD showInfoMsg:@"两次输入的密码不一致"];
    }


}

- (void)clickBackToLast
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"确认返回上一级?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];

}

#pragma mark JZOperationDelegate Methods

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [LCProgressHUD showFailure:@"网络有点卡..."];

    }

}

- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSString *code = [NSString stringWithFormat:@"%@", responseObject[@"code"]];
    NSString *info = [NSString stringWithFormat:@"%@", responseObject[@"info"]];
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message: info preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *alertAction) {
        if ([code intValue] == 0) {
            _loginVC = [[JZLoginViewController alloc] init];
            [UIApplication sharedApplication].keyWindow.rootViewController = _loginVC;

        }
    }];
    [alertController addAction: okAction];
    [self presentViewController: alertController animated:YES completion:nil];

}

@end
