//
//  JZRemindTableView.m
//  tf02
//
//  Created by F7686324 on 10/12/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZRemindTableView.h"

@implementation JZRemindTableView

-(UILabel *)tips
{
    if (!_tips) {
        _tips = [[UILabel alloc] initWithFrame:CGRectMake(0, (self.frame.size.height - 20) / 2, self.frame.size.width, 20)];
        _tips.textAlignment = NSTextAlignmentCenter;
        _tips.text = @"暂无提醒消息～";
        _tips.textColor = [UIColor grayColor];
    }
    return _tips;
}

- (void)setDataArray:(NSArray *)dataArray
{
    _dataArray = dataArray;
    [self.tips removeFromSuperview];
    if (dataArray.count == 0) {
        [self addSubview:self.tips];
    }
    [self reloadData];
}

- (void)setCellHeightArray:(NSArray *)cellHeightArray
{
    _cellHeightArray = cellHeightArray;

}

- (void)setCellID:(NSString *)cellID
{
    _cellID = cellID;
}

- (void)setShowIndicator:(BOOL)showIndicator
{
    _showIndicator = showIndicator;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.dataSource = self;
        self.delegate = self;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;

    }
    return self;
}

#pragma mark UITableViewDataSource Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZTodayRemindData *remindData = self.dataArray[indexPath.row];

    NSNumber *cellHeight = self.cellHeightArray[indexPath.row];

    JZTodayRemindCell *cell = [JZTodayRemindCell cellWithTableView: tableView cellID: self.cellID];

    cell.cellHeight = cellHeight.floatValue;

    cell.todayRemindData = remindData;

    cell.showIndicator = self.showIndicator;

    if (self.showIndicator) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return cell;

}

#pragma mark UITableViewDelegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath: indexPath animated:YES];
    if ([self.remindDelegate respondsToSelector:@selector(remindTableView:didSelectRowsAtIndexPath:)]) {
        [self.remindDelegate remindTableView:self didSelectRowsAtIndexPath:indexPath];

    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSNumber *cellHeight = self.cellHeightArray[indexPath.row];

    return cellHeight.floatValue;

}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 10)];
    headerView.backgroundColor = appBackgroundColor;
    return headerView;
}

@end
