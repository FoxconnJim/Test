//
//  JZHandleData.h
//  tf02
//
//  Created by F7686324 on 01/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utility.h"

@interface JZHandleData : NSObject
{
    CGFloat value;
    CGFloat startValue;
}

@property (nonatomic, strong) NSMutableArray *dataArray;

@property (nonatomic, strong) NSMutableArray *xArray;
@property (nonatomic, strong) NSMutableArray *yArray;

- (instancetype)initWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString;
+ (instancetype)dataWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString;

@end
