//
//  JZHomePageSection.m
//  tf02
//
//  Created by F7686324 on 8/23/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHomePageSection.h"
#import "Utility.h"
@implementation JZHomePageSection

- (UILabel *)title
{
    if (!_title) {
        _title = [[UILabel alloc] initWithFrame:CGRectMake(screenEdgeMargin, 5, screenW / 2, 30)];

    }
    return _title;
}

- (UILabel *)content
{
    if (!_content) {
        _content = [[UILabel alloc] initWithFrame:CGRectMake(screenW / 2, 5, screenW / 2 - screenEdgeMargin - 25, 30)];
        _content.textAlignment = NSTextAlignmentRight;
    }
    return _content;
}

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame: CGRectMake(screenW - screenEdgeMargin - 20, 10, 10, 20)];
        [_imgView setImage:[UIImage imageNamed:@"arrow"]];
    }
    return _imgView;
}

- (UIButton *)btn
{
    if (!_btn) {
        _btn = [[UIButton alloc] initWithFrame: self.bounds];
    }
    return _btn;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = appBackgroundColor;
        [self addSubview: self.title];
        [self addSubview: self.content];
        [self addSubview: self.imgView];
        [self addSubview: self.btn];
    }
    return self;
}

@end
