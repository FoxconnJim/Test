//
//  JZRefreshInfo.h
//  tf02
//
//  Created by F7686324 on 2017/1/18.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZRefreshInfo : NSObject

@property (nonatomic) BOOL canHomeRefresh;
@property (nonatomic) BOOL canHealthIndicatorRefresh;
@property (nonatomic) BOOL canHealthDetailDataRefresh;
@property (nonatomic) BOOL canTodayRemindRefresh;
@property (nonatomic) BOOL canHistoryRemindMemberListRefresh;
@property (nonatomic) BOOL canHistoryRemindRefresh;
@property (nonatomic) BOOL canTodayRecommendRefresh;
@property (nonatomic) BOOL canCollectionNewsRefresh;

@end
