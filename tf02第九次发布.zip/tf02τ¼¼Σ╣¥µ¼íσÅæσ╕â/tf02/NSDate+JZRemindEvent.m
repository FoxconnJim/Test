//
//  NSDate+JZRemindEvent.m
//  tf02
//
//  Created by F7686324 on 12/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "NSDate+JZRemindEvent.h"
#import "NSDate+local.h"
#import "NSDate+JZString.h"
@implementation NSDate (JZRemindEvent)

- (NSString *)dateToRemindTime
{
    NSString *jzdateString = [[self localDate] dateToString];
    NSArray *dateArray = [[[jzdateString componentsSeparatedByString:@" "] lastObject] componentsSeparatedByString:@":"];
    NSString *timeStr;
    if ([[dateArray firstObject] integerValue] < 12) {
        timeStr = @"上午";
    } else {
        timeStr = @"下午";
    }
    NSInteger hour = [[dateArray firstObject] integerValue];
    NSString *hourStr = [NSString stringWithFormat:@"%ld", (long)(hour > 12 ? hour - 12 : hour)];
    NSString *minStr = dateArray[1];
    return [NSString stringWithFormat:@"%@ %@:%@", timeStr, hourStr, minStr];
}

@end
