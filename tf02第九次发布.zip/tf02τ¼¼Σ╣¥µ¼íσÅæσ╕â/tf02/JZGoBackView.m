//
//  JZGoBackView.m
//  tf02
//
//  Created by AN PEN on 8/13/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZGoBackView.h"

@implementation JZGoBackView

- (UIButton *)backBtn
{
    if (!_backBtn) {
        _backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 44)];
        [_backBtn setTitle:@"返回" forState:UIControlStateNormal];
        UIImage *image = [UIImage imageNamed: @"backArrow"];
        _backBtn.titleLabel.font = [UIFont systemFontOfSize:17];
        [_backBtn setImage:image forState:UIControlStateNormal];
        [_backBtn setTitleColor:[UIColor grayColor] forState:UIControlStateSelected];
        [_backBtn setTitleEdgeInsets:UIEdgeInsetsMake(10, 15 - image.size.width, 10, 0)];
        [_backBtn setImageEdgeInsets:UIEdgeInsetsMake(10, 0, 10, 35)];
    }
    return _backBtn;
}

- (UIButton *)closeBtn
{
    if (!_closeBtn) {
        _closeBtn = [[UIButton alloc] initWithFrame:CGRectMake(50, 0, 50, 44)];
        _closeBtn.titleLabel.font = [UIFont systemFontOfSize:17];
        [_closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
        [_closeBtn setTitleColor:[UIColor grayColor] forState:UIControlStateSelected];
    }
    return _closeBtn;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.backBtn];
        [self addSubview:self.closeBtn];
    }
    return self;
}

@end

