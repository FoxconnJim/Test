//
//  JZOperation.h
//  tf02
//
//  Created by F7686324 on 2017/1/7.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "AFNetworking.h"
#import "Utility.h"
#import "NSDictionary+JSONString.m"
#import "JZFamilyInfo.h"
#import "JZLoginViewController.h"

#pragma mark 网络请求类型
enum HTTPMETHOD{

    METHOD_GET   = 0,    //GET请求
    METHOD_POST  = 1,    //POST请求
};

@class JZOperation;
@protocol JZOperationDelegate <NSObject>

@required
- (void)didFinishDownLoadWithOperation: (JZOperation *)operation andResponseObject: (id) responseObject;
- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error;

@end

@interface JZOperation : NSObject

+ (instancetype)operationWithURLString: (NSString *)urlString andParam: (NSMutableDictionary *)param getOrPost: (NSString *)getOrPost;

/**
 * AF数据请求
 */
- (void)requestAFURL:(NSString *)URLString
         httpMethod:(NSInteger)method
         parameters:(id)parameters;


@property (nonatomic, weak) id <JZOperationDelegate> delegate;
@property (nonatomic, strong) NSDictionary *param;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *getOrPost;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *jzName;

+ (void)cancelAFHTTPRequest;

@end

