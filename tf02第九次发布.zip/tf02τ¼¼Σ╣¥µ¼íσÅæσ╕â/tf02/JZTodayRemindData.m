
//
//  JZTodayRemindData.m
//  tf02
//
//  Created by AN PEN on 7/23/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZTodayRemindData.h"

@implementation JZTodayRemindData

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.picture = [NSString stringWithFormat:@"%@", dict[@"picture"]];
        self.nickname = [NSString stringWithFormat:@"%@", dict[@"nickname"]];
        self.remindContent = [NSString stringWithFormat:@"%@", dict[@"remindContent"]];
        self.membersname = [NSString stringWithFormat:@"%@", dict[@"membersname"]];
        self.createDate = [NSString stringWithFormat:@"%@", dict[@"createDate"]];
        self.memberId = [NSString stringWithFormat:@"%@", dict[@"memberId"]];
        self.ID = [NSString stringWithFormat:@"%@", dict[@"id"]];
    }
    return self;
}

+ (instancetype)todayRemindDataWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
