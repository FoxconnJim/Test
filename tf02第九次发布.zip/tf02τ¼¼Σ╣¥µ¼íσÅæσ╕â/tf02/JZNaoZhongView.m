//
//  JZNaoZhongView.m
//  tf02
//
//  Created by F7686324 on 03/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZNaoZhongView.h"
#import "NSDate+JZRemindEvent.h"
#import "NSMutableArray+JZArrayToRemindRepeat.h"

@implementation JZNaoZhongView

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, 44 * 3)];
        _tbView.separatorInset = UIEdgeInsetsZero;
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.bounces = NO;
    }
    return _tbView;
}

//- (UISwitch *)jzSwitch
//{
//    if (!_jzSwitch) {
//        _jzSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(screenW - 65, 7, 50, 30)];
//        _jzSwitch.on = NO;
//        [_jzSwitch addTarget:self action:@selector(click:) forControlEvents:UIControlEventValueChanged];
//     }
//    return _jzSwitch;
//}

//- (void)click:(UISwitch *)sender
//{
//    if ([[UIApplication sharedApplication] currentUserNotificationSettings].types) {
//        if (sender.on) {
//            [sender setOn:NO animated:YES];
//            NSLog(@"off");
//            return;
//        } else {
//            [sender setOn:YES animated:YES];
//            NSLog(@"on");
//            return;
//
//        }
//    } else {
//        [sender setOn:NO animated:YES];
//        NSLog(@"userNotificationSettingoff");
//    }
//    NSLog(@"types = %ld", (unsigned long)[[UIApplication sharedApplication] currentUserNotificationSettings].types);
//
//}

- (JZSelectWeekDayView *)selectWeekDayView
{
    if (!_selectWeekDayView) {
        _selectWeekDayView = [[JZSelectWeekDayView alloc] initWithFrame:CGRectMake(0, 0, screenW, 44)];

    }
    return _selectWeekDayView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.jzShow = NO;
        [self addSubview:self.tbView];
        self.backgroundColor = appBackgroundColor;
    }
    return self;
}

#pragma mark UITableViewDelegate, UITableViewDataSource Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 2;
    } else if (section == 1) {
        if (self.jzShow) {
            return 1;
        } else {
            return 0;
        }
    } else if (section == 2) {
        return 1;
    } else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];

    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"提醒时间";
            if (self.remindDate) {
                NSString *jzRemindTime = [self.remindDate dateToRemindTime];
                cell.detailTextLabel.text = jzRemindTime;

            } else {
                cell.detailTextLabel.text = [[NSDate date] dateToRemindTime];

            }

        } else if (indexPath.row == 1) {
            cell.textLabel.text = @"重复";

            if (self.remindRepeatArray) {
                NSString *jzRemindRepeat = [self.remindRepeatArray arrayToRemindRepeat];
                cell.detailTextLabel.text = jzRemindRepeat;
            } else {
                cell.detailTextLabel.text = @"今天";

            }
        }
    } else if (indexPath.section == 1) {
        cell.accessoryType = UITableViewCellAccessoryNone;

        [self.selectWeekDayView removeFromSuperview];
        [cell addSubview:self.selectWeekDayView];
    } else if (indexPath.section == 2) {
        cell.textLabel.text = @"提醒内容";
        if (!self.jzRemindInfo.length) {
            cell.detailTextLabel.text = @"测量提醒";

        } else {
            cell.detailTextLabel.text = self.jzRemindInfo;

        }
    }
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        return NO;
    } else if (indexPath.section == 2) {
        return YES;

    } else {
        return YES;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (indexPath.row == 1) {
            self.jzShow = !self.jzShow;
            if (self.jzShow) {
                [UIView animateWithDuration:0.3 animations:^{
                    tableView.frame = CGRectMake(0, 0, screenW, 44 * 4);
                }];
            } else {
                [UIView animateWithDuration:0.3 animations:^{
                    tableView.frame = CGRectMake(0, 0, screenW, 44 * 3);
                }];
            }
            [tableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationFade];
        }
    }
    [self.delegate naoZhongView:self didSelectRowAtIndexPath:indexPath];

}

@end
