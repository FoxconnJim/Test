//
//  JZBackgroundLayer.h
//  tf02
//
//  Created by AN PEN on 8/12/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIkit.h>


@interface JZBackgroundLayer : CAGradientLayer

@property (nonatomic, strong) UIColor *startColor;
@property (nonatomic, strong) UIColor *endColor;

@end
