//
//  JZNaoZhongView.h
//  tf02
//
//  Created by F7686324 on 03/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZSelectWeekDayView.h"

@class JZNaoZhongView;
@protocol JZNaoZhongViewDelegate <NSObject>

- (void)naoZhongView:(JZNaoZhongView *)naoZhongView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface JZNaoZhongView : UIView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) id <JZNaoZhongViewDelegate> delegate;
@property (nonatomic, strong) UITableView *tbView;
//@property (nonatomic, strong) UISwitch *jzSwitch;
@property (nonatomic) BOOL jzShow;
@property (nonatomic, strong) JZSelectWeekDayView *selectWeekDayView;
@property (nonatomic, strong) NSDate *remindDate;
@property (nonatomic, copy) NSString *jzRemindInfo;
@property (nonatomic, strong) NSMutableArray *remindRepeatArray;

@end
