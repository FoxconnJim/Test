//
//  NSArray+Log.m
//  tf02
//
//  Created by AN PEN on 4/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "NSArray+Log.h"

@implementation NSArray (Log)



- (NSString *)descriptionWithLocale:(id)locale {
    NSMutableString *str = [NSMutableString string];

    [str appendString:@"[\n"];

    // 遍历数组所有元素
    [self enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [str appendFormat:@"%@, \n", obj];
    }];

    [str appendString:@"]"];

    return str;
}
@end
