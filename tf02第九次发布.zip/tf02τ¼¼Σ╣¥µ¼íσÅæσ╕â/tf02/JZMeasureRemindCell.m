//
//  JZMeasureRemindCell.m
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZMeasureRemindCell.h"
#import "Utility.h"

@implementation JZMeasureRemindCell

- (UISwitch *)jzSwitch
{
    if (!_jzSwitch) {
        _jzSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(screenW - 65, 25, 50, 30)];
        _jzSwitch.on = YES;
    }
    return _jzSwitch;
}

- (UILabel *)leftLabel
{
    if (!_leftLabel) {
        _leftLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 20, 60, 30)];
        _leftLabel.font = [UIFont systemFontOfSize:25];
    }
    return _leftLabel;
}

- (UILabel *)rightLabel
{
    if (!_rightLabel) {
        _rightLabel = [[UILabel alloc] initWithFrame:CGRectMake(75, 10, 150, 45)];
        _rightLabel.font = [UIFont systemFontOfSize:45];
    }
    return _rightLabel;
}

- (UILabel *)downLabel
{
    if (!_downLabel) {
        _downLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 55, screenW - 30, 15)];
        _downLabel.font = [UIFont systemFontOfSize:15];
        _downLabel.textColor = [UIColor grayColor];
    }
    return _downLabel;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self addSubview:self.leftLabel];
        [self addSubview:self.rightLabel];
        [self addSubview:self.downLabel];
        [self addSubview:self.jzSwitch];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

+ (JZMeasureRemindCell *)cellWithTableView:(UITableView *)tableView
{
    static NSString *cellid = @"JZMeasureRemindCellID";
    JZMeasureRemindCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[JZMeasureRemindCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    return cell;
}

@end
