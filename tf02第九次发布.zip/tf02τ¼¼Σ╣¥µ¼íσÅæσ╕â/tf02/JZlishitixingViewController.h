//
//  JZlishitixingViewController.h
//  tf02
//
//  Created by F7686324 on 2017/1/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZlishitixingViewController : UIViewController

@property (nonatomic, copy) NSString *memberId;

@property (nonatomic) BOOL canHistoryRemindRefresh;

@end
