//
//  JZBloodSugarData.h
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZData.h"

@interface JZBloodSugarData : JZData

@end
