//
//  JZWeightData.m
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZWeightData.h"

@implementation JZWeightData

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super initWithDictionary:dict]) {
        self.data = [NSString stringWithFormat:@"%0.1f", [dict[@"bfWeight"] floatValue]];
        if ([[[self.data componentsSeparatedByString:@"."] lastObject] integerValue] == 0) {
            self.data = [[self.data componentsSeparatedByString:@"."] firstObject];
        }

        self.physicalstate = [NSString stringWithFormat:@"%@", dict[@"physicalstate"]];
        if (self.physicalstate.integerValue == 0) {
            self.physicalstate = @"刚起床 (起床立即测量)";
        } else if (self.physicalstate.integerValue == 1) {
            self.physicalstate = @"睡前 (睡前半小时)";
        } else {
            self.physicalstate = @"其他 (除上述情况外正常测量)";
        }
    }
    return self;
}
@end
