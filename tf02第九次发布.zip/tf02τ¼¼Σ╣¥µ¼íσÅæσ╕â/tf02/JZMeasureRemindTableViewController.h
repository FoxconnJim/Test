//
//  JZMeasureRemindTableViewController.h
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZMeasureRemindTableViewController : UITableViewController

@end
