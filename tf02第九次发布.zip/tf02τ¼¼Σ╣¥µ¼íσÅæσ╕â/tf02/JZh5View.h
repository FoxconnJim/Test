//
//  JZh5View.h
//  tf02
//
//  Created by Jim on 16/8/18.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "NSString+Hash.h"
#import <SystemConfiguration/SystemConfiguration.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "AFNetworking.h"
#import "NSDictionary+JSONString.h"
#import <WebKit/WebKit.h>
#import "WebViewJavascriptBridge.h"


@interface JZh5View : UIView 

@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) UIActivityIndicatorView *aiView;
@property (nonatomic, copy) NSString *urlString;

@property (nonatomic) BOOL isCamera;

@property WebViewJavascriptBridge *bridge;

@end
