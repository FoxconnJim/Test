//
//  JZpromptLabel.h
//  tf02
//
//  Created by Jim on 16/8/19.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZpromptLabel : UILabel

@property (nonatomic, copy) NSString *jz_text;
@property (nonatomic) BOOL isRemoved;

@end
