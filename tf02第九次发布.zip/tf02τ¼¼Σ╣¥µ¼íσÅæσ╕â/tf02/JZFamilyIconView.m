//
//  JZFamilyIconView.m
//  tf02
//
//  Created by Jim on 16/3/11.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZFamilyIconView.h"

@implementation JZFamilyIconView

- (JZFamilyIconFrame *)familyIconFrame
{
    if (!_familyIconFrame) {
        _familyIconFrame = [[JZFamilyIconFrame alloc] init];
    }
    return _familyIconFrame;
}

- (UIImageView *)tickImgView
{
    if (!_tickImgView) {
        _tickImgView = [[UIImageView alloc] init];
        _tickImgView.image = [UIImage imageNamed:@"tick"];
    }
    return _tickImgView;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] initWithFrame: self.familyIconFrame.titleFrame];
        _titleLabel.text = @"我的家人";
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.font = [UIFont systemFontOfSize: self.familyIconFrame.titleFrame.size.height];
    }
    return _titleLabel;
}

- (UIScrollView *)iconScrollView
{
    if (!_iconScrollView) {
        _iconScrollView = [[UIScrollView alloc] initWithFrame: self.familyIconFrame.frame];
        _iconScrollView.showsHorizontalScrollIndicator = NO;
    }
    return _iconScrollView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:0.18 green:0.55 blue:1 alpha:1];
        self.personArray = [NSMutableArray array];
        [self addSubview: self.titleLabel];
        [self addSubview: self.iconScrollView];
    }
    return self;
}

- (void)setPersonInfoArray:(NSMutableArray *)personInfoArray
{
    _personInfoArray = personInfoArray;
    self.familyIconFrame.personInfoArray = personInfoArray;
    self.iconScrollView.contentSize = self.familyIconFrame.contentSize;

    for (JZHomePageIconView *icon in self.iconScrollView.subviews) {
        [icon removeFromSuperview];
    }

    [self.personArray removeAllObjects];
    
    for (int i = 0; i < personInfoArray.count; i++) {
        CGRect frame = CGRectFromString(self.familyIconFrame.frameArray[i]);
        JZPersonInfo *personInfo = personInfoArray[i];
        JZHomePageIconView *icon = [[JZHomePageIconView alloc] initWithFrame: frame];
        icon.btn.tag = i;
        icon.lbl.text = [personInfo nickname];
        if ([personInfo picture]) {
            [icon.imgView sd_setImageWithURL:[NSURL URLWithString:[personInfo picture]] placeholderImage:[UIImage imageNamed:@"默认"]];

        } else {
            if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
                icon.imgView.image = [UIImage imageNamed:@"游客"];
            }
        }

        [self.iconScrollView addSubview: icon];
        [self.personArray addObject: icon];
    }
}



























@end
