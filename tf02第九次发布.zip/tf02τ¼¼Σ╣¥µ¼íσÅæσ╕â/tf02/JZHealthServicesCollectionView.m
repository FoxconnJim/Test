//
//  JZHealthServicesCollectionView.m
//  tf02
//
//  Created by F7686324 on 2016/12/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZHealthServicesCollectionView.h"

@implementation JZHealthServicesCollectionView

static NSString *const cellid = @"cellid";
static NSString *const headerid = @"headerid";
static NSString *const footerid = @"footerid";

- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        _collectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:layout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:cellid];
        [_collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerid];
        _collectionView.backgroundColor = [UIColor clearColor];
    }
    return _collectionView;
}

- (JZPageControlView *)pageView
{
    if (!_pageView) {
        _pageView = [[JZPageControlView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenW * 340 / 720)];

        NSMutableArray *ADModelArray = [NSMutableArray valueByKey:kADModelArray];
        if (!ADModelArray) {
            ADModelArray = [NSMutableArray array];
            [ADModelArray storeValueByKey:kADModelArray];
        }
        _pageView.ADModelArray = ADModelArray;
    }
    return _pageView;
}

- (JZHealthServicesOptView *)hlzxView
{
    if (!_hlzxView) {
        _hlzxView = [[JZHealthServicesOptView alloc] initWithFrame:CGRectMake(0, 0, 75, 105)];
        _hlzxView.imgView.image = [UIImage imageNamed:@"jiankang1"];
        _hlzxView.lbl.text = @"健康资讯";
    }
    return _hlzxView;
}

- (JZHealthServicesOptView *)jyzxView
{
    if (!_jyzxView) {
        _jyzxView = [[JZHealthServicesOptView alloc] initWithFrame:CGRectMake(0, 0, 75, 105)];
        _jyzxView.imgView.image =[UIImage imageNamed:@"jiayi1"];
        _jyzxView.lbl.text = @"家医咨询";
    }
    return _jyzxView;
}

//- (JZHealthServicesOptView *)xsghView
//{
//    if (!_xsghView) {
//        _xsghView = [[JZHealthServicesOptView alloc] initWithFrame:CGRectMake(0, 0, 75, 105)];
//        _xsghView.imgView.image = [UIImage imageNamed:@"xianshangguahao"];
//        _xsghView.lbl.text = @"线上挂号";
//    }
//    return _xsghView;
//}
//
//- (JZHealthServicesOptView *)xsyjView
//{
//    if (!_xsyjView) {
//        _xsyjView = [[JZHealthServicesOptView alloc] initWithFrame:CGRectMake(0, 0, 75, 105)];
//        _xsyjView.imgView.image = [UIImage imageNamed:@"xianshangyaoju"];
//        _xsyjView.lbl.text = @"线上药局";
//    }
//    return _xsyjView;
//}

- (JZHealthServicesOptView *)jtysView
{
    if (!_jtysView) {
        _jtysView = [[JZHealthServicesOptView alloc] initWithFrame:CGRectMake(0, 0, 75, 105)];
        _jtysView.imgView.image = [UIImage imageNamed:@"jiatingyaoshi"];
        _jtysView.lbl.text = @"家庭药师";
    }
    return _jtysView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.collectionView];
    }
    return self;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 3;
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellid forIndexPath:indexPath];
    cell.backgroundColor = [UIColor clearColor];
    if (indexPath.item == 0) {
        [cell addSubview:self.jyzxView];

    } else if (indexPath.item == 1) {
        [cell addSubview:self.hlzxView];

    } else if (indexPath.item == 2) {
        [cell addSubview:self.jtysView];

//        [cell addSubview:self.xsghView];
//    } else if (indexPath.item == 3) {
//        [cell addSubview:self.xsyjView];
//    } else if (indexPath.item == 4) {
//        [cell addSubview:self.jtysView];

    }
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    NSString *reuseIdentifier;
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        reuseIdentifier = headerid;
    } else {
        reuseIdentifier = footerid;
    }

    UICollectionReusableView *view = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:reuseIdentifier forIndexPath:indexPath];

    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        [view addSubview:self.pageView];
    }
    return view;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(75, 105);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(15, 15, 15, 15);
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    return CGSizeMake(screenW, screenW * 340 / 720);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 15;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 15;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self.delegate healthServicesCollectionView:self didSelectItemsAtIndexPath:indexPath];
}

@end
