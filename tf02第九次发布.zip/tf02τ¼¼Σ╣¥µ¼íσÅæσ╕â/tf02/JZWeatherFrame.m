//
//  JZWeatherFrame.m
//  tf02
//
//  Created by Jim on 16/3/12.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZWeatherFrame.h"
#import "Utility.h"

@implementation JZWeatherFrame

- (instancetype)init
{
    self = [super init];
    if (self) {

        CGFloat weatherInfoX = screenEdgeMargin;
        CGFloat weatherInfoY = 0;
        CGFloat weatherInfoW = screenW - screenEdgeMargin * 2;
        CGFloat weatherInfoH = weatherInfoHeight;
        self.frame = CGRectMake(weatherInfoX, weatherInfoY, weatherInfoW, weatherInfoH);
        
        CGFloat weatherImageX = screenW / 15;
        CGFloat weatherImageY = 10;
        CGFloat weatherImageW = 50;
        CGFloat weatherImageH = 46;
        
        self.weatherImageFrame = CGRectMake(weatherImageX, weatherImageY, weatherImageW, weatherImageH);

        CGFloat weatherLabelX = 0;
        CGFloat weatherLabelY = weatherImageY + weatherImageH + 5;
        CGFloat weatherLabelW = weatherImageX * 2 + weatherImageW;
        CGFloat weatherLabelH = weatherInfoH - weatherLabelY;
        self.weatherLabelFrame = CGRectMake(weatherLabelX, weatherLabelY, weatherLabelW, weatherLabelH);

        CGFloat leftImageX = 5;
        CGFloat leftImageW = (weatherLabelW - leftImageX * 2 - 15) / 2;
        CGFloat leftImageH = leftImageW / 25 * 23;
        CGFloat leftImageY = weatherImageY + (weatherImageH - leftImageH) / 2;
        self.leftImageFrame = CGRectMake(leftImageX, leftImageY, leftImageW, leftImageH);

        CGFloat midX = leftImageX + leftImageW;
        CGFloat midY = leftImageY;
        CGFloat midW = weatherLabelW - leftImageX * 2 - leftImageW * 2;
        CGFloat midH = leftImageH;
        self.midFrame = CGRectMake(midX, midY, midW, midH);
        
        CGFloat rightImageX = weatherLabelW - leftImageW - leftImageX;
        CGFloat rightImageY = leftImageY;
        CGFloat rightImageW = leftImageW;
        CGFloat rightImageH = leftImageH;
        self.rightImageFrame = CGRectMake(rightImageX, rightImageY, rightImageW, rightImageH);

        CGFloat locationW = screenW / 5;
        CGFloat locationH = weatherInfoH;
        CGFloat locationX = weatherInfoW - locationW - 5;
        CGFloat locationY = 0;

        self.locationFrame = CGRectMake(locationX, locationY, locationW, locationH);

        CGFloat tempX = weatherLabelX + weatherLabelW;
        CGFloat tempY = 10;
        CGFloat tempW = weatherInfoW - weatherLabelW - locationW;
        CGFloat tempH = weatherLabelY;
        self.tempFrame = CGRectMake(tempX, tempY, tempW, tempH);

        CGFloat windX = tempX;
        CGFloat windY = weatherLabelY;
        CGFloat windW = tempW;
        CGFloat windH = weatherLabelH;
        self.windFrame = CGRectMake(windX, windY, windW, windH);

        CGFloat temX = tempX;
        CGFloat temY = 10;
        CGFloat temW = tempW;
        CGFloat temH = (weatherInfoH - temY) / 3;
        self.temFrame = CGRectMake(temX, temY, temW, temH);

        CGFloat winX = temX;
        CGFloat winY = temY + temH;
        CGFloat winW = temW;
        CGFloat winH = temH;
        self.winFrame = CGRectMake(winX, winY, winW, winH);

        CGFloat humidityX = temX;
        CGFloat humidityY = winY + winH;
        CGFloat humidityW = temW;
        CGFloat humidityH = temH;
        self.humidityFrame = CGRectMake(humidityX, humidityY, humidityW, humidityH);

    }
    return self;
}

@end
