//
//  JZFamilyIconFrame.h
//  tf02
//
//  Created by Jim on 16/3/11.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JZFamilyIconFrame : NSObject

@property (nonatomic, assign) CGRect titleFrame;
@property (nonatomic, assign) CGRect frame;
@property (nonatomic, strong) NSMutableArray *personInfoArray;
@property (nonatomic, strong) NSMutableArray *frameArray;
@property (nonatomic, assign) CGSize contentSize;
@end
