//
//  JZSelectWeekDayView.h
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZSelectWeekDayView : UIView

@property (nonatomic, strong) NSMutableArray *btnArray;

@end
