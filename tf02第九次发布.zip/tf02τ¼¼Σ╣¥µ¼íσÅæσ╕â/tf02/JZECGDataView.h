//
//  JZECGDataView.h
//  tf02
//
//  Created by F7686324 on 27/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JZECGDataView;
@protocol JZECGDataViewDelegate <NSObject>

- (void)showECGGainWithECGDataView:(JZECGDataView *)ECGDataView;

@end

@interface JZECGDataView : UIView
{
    CGFloat ratio;
    CGFloat smallSpace;
    CGFloat bigSpace;
    CGFloat space;
    CGFloat proportion;

}
@property (nonatomic, weak) id <JZECGDataViewDelegate> delegate;
@property (nonatomic, strong) CAShapeLayer *shapeLayer;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, assign) CGFloat jzHeight;
@property (nonatomic, copy) NSString *lblText;


@end
