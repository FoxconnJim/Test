//
//  JZHealthRecordViewController.h
//  tf02
//
//  Created by F7686324 on 20/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZData.h"
#import "JZBloodPressureData.h"
#import "JZHeartRateData.h"

@interface JZHealthRecordViewController : UIViewController

@property (nonatomic, copy) NSString *jzType;
@property (nonatomic, strong) JZData *jzdata;
@property (nonatomic, strong) JZBloodPressureData *bpData;
@property (nonatomic, strong) JZHeartRateData *hrData;

@end
