//
//  JZPoint.m
//  tf02
//
//  Created by F7686324 on 01/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZPoint.h"

@implementation JZPoint

- (void)setX:(CGFloat)x
{
    _x = x;
}

- (void)setY:(CGFloat)y
{
    _y = y;
}

- (instancetype)initWithX:(CGFloat)x y:(CGFloat)y
{
    if (self = [super init]) {
        self.x = x;
        self.y = y;
    }
    return self;
}

+ (instancetype)pointWithX:(CGFloat)x y:(CGFloat)y
{
    return [[self alloc] initWithX:x y:y];
}

@end
