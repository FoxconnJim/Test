//
//  JZContactUsView.m
//  tf02
//
//  Created by F7686324 on 03/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZContactUsView.h"
#import "iRonIconCell.h"
#import "Utility.h"

@implementation JZContactUsView

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight) style:UITableViewStyleGrouped];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.separatorInset = UIEdgeInsetsZero;
        _tbView.backgroundColor = appBackgroundColor;
    }
    return _tbView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.tbView];

    }
    return self;
}

#pragma mark UITableViewDelegate,UITableViewDataSource Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        iRonIconCell *cell = [[iRonIconCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = appBackgroundColor;
        cell.iconImageView.image = [UIImage imageNamed:@"JZAppIcon"];
        cell.iconImageView.layer.cornerRadius = 15;
        cell.familyNameLabel.text = @"TF02 V2.7";
        return cell;
    } else {
        static NSString *cellid = @"JZContactUsViewCellID";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellid];
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if (indexPath.row == 1) {
            cell.textLabel.text = @"官网";
            cell.detailTextLabel.text = @"www.baidu.com";
        } else if (indexPath.row == 2) {
            cell.textLabel.text = @"客服热线";
            cell.detailTextLabel.text = @"400-888-8888";
        } else if (indexPath.row == 3) {
            cell.textLabel.text = @"客服邮箱";
            cell.detailTextLabel.text = @"foxconn@mail.com";
        } else if (indexPath.row == 4) {
            cell.textLabel.text = @"联系地址";
            cell.detailTextLabel.text = @"请查看";
        } else {
            cell.textLabel.text = @"联系邮编";
            cell.detailTextLabel.text = @"518000";
        }
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 130;
    } else {
        return 44;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.1f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.delegate contactUsView:self didSelectRowAtIndex:indexPath];
}
@end
