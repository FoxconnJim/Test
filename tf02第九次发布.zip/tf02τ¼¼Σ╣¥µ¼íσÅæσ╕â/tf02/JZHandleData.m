//
//  JZHandleData.m
//  tf02
//
//  Created by F7686324 on 01/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHandleData.h"

@implementation JZHandleData

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (NSMutableArray *)yArray
{
    if (!_yArray) {
        _yArray = [NSMutableArray array];
    }
    return _yArray;
}

- (NSMutableArray *)xArray
{
    if (!_xArray) {
        _xArray = [NSMutableArray array];
    }
    return _xArray;
}

- (instancetype)initWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString
{
    if (self = [super init]) {

        if ([timeLengthString isEqual: jzDay]) {
            value = 3600 * 24;
        } else if ([timeLengthString isEqual:jzWeek]) {
            value = 3600 * 24 * 7;
        } else if ([timeLengthString isEqual:jzMonth]) {
            value = 3600 * 24 * 30;
        } else if ([timeLengthString isEqual:jzYear]) {
            value = 3600 * 24 * 365;
        }
        NSString *endTimeString = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        NSDate *date = [[dateFormatter dateFromString: endTimeString] localDate];
        NSInteger endValue = [date timeIntervalSince1970] + 24 * 60 * 60;
        startValue = endValue - value;

        [self.xArray removeAllObjects];
        [self.yArray removeAllObjects];

        if ([timeLengthString isEqualToString:jzYear]) {
            NSString *monthStr = [[[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject] componentsSeparatedByString:@"-"][1];
            dataArray = [dataArray sortByMonth];

            int monthInt = monthStr.intValue;
            NSMutableArray *orderArray = [NSMutableArray array];
            for (int i = monthInt; i < 12; i++) {
                [orderArray addObject: dataArray[i]];
            }

            for (int i = 0; i < monthInt; i++) {
                [orderArray addObject: dataArray[i]];
            }

            for (NSMutableArray *array in orderArray) {
                if (array.count) {
                    CGFloat dataValue = 0.f;
                    for (JZDataPoint *dataPoint in array) {
                        dataValue += [dataPoint.data floatValue];
                    }
                    [self.yArray addObject:[NSString stringWithFormat:@"%f", dataValue / array.count]];
                } else {
                    [self.yArray addObject:@"0"];
                }
            }
            for (int i = 0; i < 12; i++) {
                CGFloat x = 1.f / 24.f + i * 1.f / 12.f;
                [self.xArray addObject:[NSString stringWithFormat:@"%f", x]];
            }
        } else if ([timeLengthString isEqualToString:jzMonth]){
            NSMutableArray *orderArray = [dataArray sortByDay];

            NSMutableArray *orderDetailArray = [NSMutableArray array];

            for (NSMutableArray *array in orderArray) {
                NSMutableArray *totalArray = [NSMutableArray array];
                for (int i = 0; i < 5; i++) {
                    NSMutableArray *arr = [NSMutableArray array];
                    [totalArray addObject:arr];
                }
                if (array.count) {
                    for (JZDataPoint *dataPoint in array) {
                        
                        NSInteger hourInt = [[[[[dataPoint.meatime componentsSeparatedByString:@" "] lastObject] componentsSeparatedByString:@"-"] firstObject] integerValue];
                        if (hourInt >= 0 && hourInt <= 4) {
                            NSMutableArray *arr = totalArray[0];
                            [arr addObject:dataPoint];
                        } else if (hourInt > 4 && hourInt <= 10) {
                            NSMutableArray *arr = totalArray[1];
                            [arr addObject:dataPoint];
                        } else if (hourInt > 10 && hourInt <= 15) {
                            NSMutableArray *arr = totalArray[2];
                            [arr addObject:dataPoint];
                        } else if (hourInt > 15 && hourInt <= 21) {
                            NSMutableArray *arr = totalArray[3];
                            [arr addObject:dataPoint];
                        } else if (hourInt > 21 && hourInt <= 24) {
                            NSMutableArray *arr = totalArray[4];
                            [arr addObject:dataPoint];
                        }
                    }
                }
                [orderDetailArray addObject:totalArray];

            }

            for (int i = 0; i < orderDetailArray.count; i++) {
                NSMutableArray *array = orderDetailArray[i];
                for (int j = 0; j < 5; j++) {
                    NSMutableArray *arr = array[j];
                    if (arr.count) {
                        CGFloat dataValue = 0.f;
                        for (JZDataPoint *dataPoint in arr) {
                            dataValue += [dataPoint.data floatValue];
                        }
                        [self.yArray addObject:[NSString stringWithFormat:@"%f", dataValue / arr.count]];
                        CGFloat x = 0.f;
                        switch (j) {
                            case 0:
                                x = i * 1.f / 30.f + 1.f / 30.f / 24.f * 2;
                                break;
                            case 1:
                                x = i * 1.f / 30.f + 1.f / 30.f / 24.f * 7;
                                break;
                            case 2:
                                x = i * 1.f / 30.f + 1.f / 30.f / 24.f * 12.5;
                                break;
                            case 3:
                                x = i * 1.f / 30.f + 1.f / 30.f / 24.f * 18;
                                break;
                            case 4:
                                x = i * 1.f / 30.f + 1.f / 30.f / 24.f * 22.5;
                                break;

                            default:
                                break;
                        }
                        [self.xArray addObject:[NSString stringWithFormat:@"%f", x]];
                    }
                }

            }

        } else {
            if (dataArray.count) {
                dataArray = [dataArray changeOrder];
                for (JZDataPoint *dataPoint in dataArray) {
                    CGFloat timeValue = [dataPoint.meatime stringToTimeInteval];
                    CGFloat x = (timeValue - startValue) / value;
                    [self.xArray addObject:[NSString stringWithFormat:@"%f", x]];
                    [self.yArray addObject:[NSString stringWithFormat:@"%@", dataPoint.data]];
                }
            }
        }

        if (self.xArray.count == self.yArray.count) {
            for (int i = 0; i < self.xArray.count; i++) {
                NSString *xStr = self.xArray[i];
                NSString *yStr = self.yArray[i];
                JZPoint *point = [JZPoint pointWithX:xStr.floatValue y:yStr.floatValue];
                [self.dataArray addObject:point];
            }
        } else {
            NSLog(@"横纵坐标数不等");
        }
    }
    return self;
}

+ (instancetype)dataWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString
{
    return [[self alloc] initWithArray:dataArray timeLengthString:timeLengthString];
}

@end
