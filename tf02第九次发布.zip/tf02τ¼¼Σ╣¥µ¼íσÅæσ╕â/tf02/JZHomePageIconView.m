//
//  JZHomePageIconView.m
//  tf02
//
//  Created by F7686324 on 15/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHomePageIconView.h"

@implementation JZHomePageIconView

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(13.5, 19.5, 40, 40)];
        _imgView.layer.cornerRadius = 20.f;
        _imgView.layer.masksToBounds = YES;
        _imgView.layer.borderColor = [UIColor whiteColor].CGColor;
        _imgView.layer.borderWidth = 1.f;
        _imgView.alpha = 0.7f;
    }
    return _imgView;
}

- (UILabel *)lbl
{
    if (!_lbl) {
        _lbl = [[UILabel alloc] initWithFrame: CGRectMake(6, 72, 55, 15)];
        _lbl.font = [UIFont systemFontOfSize: 13];
        _lbl.textColor = [UIColor colorWithWhite:1 alpha:0.7f];
        _lbl.textAlignment = NSTextAlignmentCenter;
    }
    return _lbl;
}

- (UIButton *)btn
{
    if (!_btn) {
        _btn = [[UIButton alloc] initWithFrame: self.bounds];

    }
    return _btn;
}

- (UIImageView *)tickView
{
    if (!_tickView) {
        _tickView = [[UIImageView alloc] initWithFrame: CGRectMake(self.bounds.size.width / 2, 0, self.bounds.size.width / 2, self.bounds.size.width / 2)];
        [_tickView setImage:[UIImage imageNamed:@"tick"]];
    }
    return _tickView;
}

- (void)setIsSelected:(BOOL)isSelected
{
    _isSelected = isSelected;
    if (isSelected) {
        self.lbl.textColor = [UIColor whiteColor];
        self.imgView.alpha = 1.f;

        self.imgView.frame = CGRectMake(13.5, 19.5, 40, 40);
        self.imgView.layer.cornerRadius = 20.f;
        self.imgView.layer.masksToBounds = YES;
        self.imgView.layer.borderWidth = 1.f;
        self.lbl.font = [UIFont systemFontOfSize:13];

        [UIView animateWithDuration:1 delay:0 usingSpringWithDamping:0.3 initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseOut animations:^{
            self.lbl.font = [UIFont systemFontOfSize:15];

            self.imgView.frame = CGRectMake(6, 12, 55, 55);
            self.imgView.layer.cornerRadius = 27.5f;
            self.imgView.layer.masksToBounds = YES;
            self.imgView.layer.borderWidth = 1.5f;

        } completion:nil];
    } else {
        self.lbl.textColor = [UIColor colorWithWhite:1 alpha:0.7];
        self.imgView.alpha = 0.7f;

        [UIView animateWithDuration:1 delay:0 usingSpringWithDamping:0.3  initialSpringVelocity:10 options:UIViewAnimationOptionCurveEaseOut animations:^{
            self.lbl.font = [UIFont systemFontOfSize:13];

            self.imgView.frame = CGRectMake(13.5, 19.5, 40, 40);
            self.imgView.layer.cornerRadius = 20.f;
            self.imgView.layer.masksToBounds = YES;
            self.imgView.layer.borderWidth = 1.f;

        } completion:nil];
    }
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        [self addSubview: self.imgView];
        [self addSubview: self.lbl];
        [self addSubview: self.btn];
    }
    return self;
}


@end
