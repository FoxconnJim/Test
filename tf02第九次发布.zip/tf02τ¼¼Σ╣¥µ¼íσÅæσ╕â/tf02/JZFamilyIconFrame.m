//
//  JZFamilyIconFrame.m
//  tf02
//
//  Created by Jim on 16/3/11.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZFamilyIconFrame.h"
#import "Utility.h"

@implementation JZFamilyIconFrame

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.frameArray = [NSMutableArray array];

        CGFloat titleLabelX = 20;
        CGFloat titleLabelY = 10;
        CGFloat titleLabelW = 100;
        CGFloat titleLabelH = 17;
        
        self.titleFrame = CGRectMake(titleLabelX, titleLabelY, titleLabelW, titleLabelH);
        
        CGFloat iconScrollViewX = 14;
        CGFloat iconScrollViewY = 27;
        CGFloat iconScrollViewW = screenW - 14 * 2;
        CGFloat iconScrollViewH = 87;
        
        self.frame = CGRectMake(iconScrollViewX, iconScrollViewY, iconScrollViewW, iconScrollViewH);
    }
    return self;
}

- (void)setPersonInfoArray:(NSMutableArray *)personInfoArray
{
    _personInfoArray = personInfoArray;

    [self.frameArray removeAllObjects];

    for (int i = 0; i < personInfoArray.count; i++) {
        CGFloat buttonW = 67;
        CGFloat buttonH = 87;
        CGFloat buttonX = 67 * i;
        CGFloat buttonY = 0;
        CGRect myFrame = CGRectMake(buttonX, buttonY, buttonW, buttonH);
        [self.frameArray addObject:NSStringFromCGRect(myFrame)];
    }
    self.contentSize = CGSizeMake(67 * personInfoArray.count > self.frame.size.width ? 67 * personInfoArray.count : self.frame.size.width, 87);
}

@end
