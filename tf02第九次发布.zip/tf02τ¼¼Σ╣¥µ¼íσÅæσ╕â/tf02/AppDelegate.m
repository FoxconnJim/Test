//
//  AppDelegate.m
//  tf02
//
//  Created by Jim on 16/3/9.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "AppDelegate.h"
#import "Utility.h"
#import "JZLoginViewController.h"
#import "JZHomePageViewController.h"
#import "JZHealthIndicatorViewController.h"
#import "JZHealthServicesViewController.h"
#import "JZMineViewController.h"
#import "JZTodayRemindViewController.h"
#import <HealthKit/HealthKit.h>
#import "NSString+Date.h"
#import "LogControl.h"

#import "BPush.h"
#import <UserNotifications/UserNotifications.h>
#define BaiduPush_ApiKey @"SvpAlhue1uCPU0QCVoypnQSs"
#define MZKeyWindow [UIApplication sharedApplication].keyWindow
static BOOL isBackGroundActivateApplication;

#import <SMS_SDK/SMSSDK.h>
//#define JZappKey @"1729801fdd024"
//#define JZappSecret @"8c67250babe2f8a3a723a2c3922a0aa6"

//#import <UMSocialCore/UMSocialCore.h>

#import "JZTabBarController.h"
#import "JZMeasureRemindTableViewController.h"
#import "MZNavigationController.h"

#import <CoreLocation/CoreLocation.h>
#import <CoreLocation/CLLocationManagerDelegate.h>

#import "JZRefreshInfo.h"

#import "EventManger.h"
#import "JZRemindEvent.h"

@interface AppDelegate ()

@property (nonatomic, strong) HKHealthStore *health;
@property (nonatomic, strong) CLLocationManager *clLocationManager;

@end

@implementation AppDelegate

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (CLLocationManager *)clLocationManager
{
    if (!_clLocationManager) {
        _clLocationManager = [[CLLocationManager alloc] init];

    }
    return _clLocationManager;
}

- (HKHealthStore *)health
{
    if (!_health) {
        _health = [[HKHealthStore alloc] init];
    }
    return _health;
}

- (void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler
{

    JZTabBarController *tabBarController = [[JZTabBarController alloc] init];

    MZNavigationController *navi = [[MZNavigationController alloc] initWithRootViewController:tabBarController];
    navi.navigationBar.barStyle = UIBarStyleBlack;
    navi.navigationBar.barTintColor = barBackgroundColor;
    navi.navigationBar.tintColor = [UIColor whiteColor];
    navi.navigationBar.translucent = NO;

    [UIApplication sharedApplication].keyWindow.rootViewController = navi;

    // 3DTouch
    if ([shortcutItem.type isEqualToString:@"alarm"]) {

        //         detailVC.navTitle = @"one";
        tabBarController.navigationItem.title = @"测量提醒";
        tabBarController.selectedIndex = 3;
        [tabBarController.mineVC.mineView.tbView reloadData];

        JZMeasureRemindTableViewController *measureRemindTBVC = [[JZMeasureRemindTableViewController alloc] init];

        [navi pushViewController:measureRemindTBVC animated:YES];

    } else if ([shortcutItem.type isEqualToString:@"healthdata"]) {

        NSLog(@"didSelectTabBarController");
        tabBarController.navigationItem.title = @"健康指标";

    } else if ([shortcutItem.type isEqualToString:@"todayremind"]) {
        tabBarController.navigationItem.title = @"首页";
        tabBarController.selectedIndex = 0;
        [tabBarController.homePageVC.tbView reloadData];

        JZTodayRemindViewController *todayRemindVC = [[JZTodayRemindViewController alloc] init];

        [navi pushViewController:todayRemindVC animated:YES];
    }
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSSetUncaughtExceptionHandler(&UncaughtExceptionHandler);

    [SDImageCache sharedImageCache].maxCacheAge = 60 * 60 * 24;
    [SDImageCache sharedImageCache].maxCacheSize = 1024 * 1024 * 10;

    //打开调试日志
//    [[UMSocialManager defaultManager] openLog:YES];

    //设置友盟appkey
//    [[UMSocialManager defaultManager] setUmSocialAppkey:@"578362ba67e58e72f90003b2"];
//    [[UMSocialManager defaultManager] setUmSocialAppkey:@"57b432afe0f55a9832001a0a"];

    //获取友盟social版本号
//    NSLog(@"UMeng social version: %@", [UMSocialGlobal umSocialSDKVersion]);

    //设置微信的appKey和appSecret
//    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:@"wx35f47cb75f1ed907" appSecret:@"764a21d0b33df00a6cecd9a708ce3976" redirectURL:@"http://www.baidu.com"];
//    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:@"100424468"  appSecret:nil redirectURL:@"http://mobile.umeng.com/social"];
//    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Sina appKey:@"3921700954"  appSecret:@"04b48b094faeb16683c32669824ebdad" redirectURL:@"http://sns.whalecloud.com/sina2/callback"];
//    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Qzone appKey:@"100424468" appSecret:@"04b48b094faeb16683c32669824ebdad" redirectURL:@"http://mobile.umeng.com/social"];
//    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatTimeLine appKey:@"wx35f47cb75f1ed907" appSecret:@"764a21d0b33df00a6cecd9a708ce3976" redirectURL:@"http://www.baidu.com"];

    [@"autologin" storeValueByKey:kAutoLogin];

    JZLoginViewController *loginVC = [[JZLoginViewController alloc] init];
    self.window.rootViewController = loginVC;
    self.window.backgroundColor = [UIColor whiteColor];

//    [self healthInital];
    [SMSSDK registerApp:JZSMSAppKey withSecret:JZSMSAppSecret];
    
    // 注册推送
    [self registerPush:application options:launchOptions];

//    UIApplicationLaunchOptionsShortcutItemKey
    [self.clLocationManager requestWhenInUseAuthorization];

    JZRefreshInfo *refreshInfo = [[JZRefreshInfo alloc] init];
    [refreshInfo storeValueByKey:kRefreshInfo];
    return YES;
}


void UncaughtExceptionHandler(NSException *exception) {
    /**
     *  获取异常崩溃信息
     */
    NSArray *callStack = [exception callStackSymbols];
    NSString *reason = [exception reason];
    NSString *name = [exception name];
    NSString *content = [NSString stringWithFormat:@"========异常错误报告========\nname:%@\nreason:\n%@\ncallStackSymbols:\n%@",name,reason,[callStack componentsJoinedByString:@"\n"]];

    /**
     *  把异常崩溃信息发送至开发者邮件
     */
    NSMutableString *mailUrl = [NSMutableString string];
    [mailUrl appendString:@"1303610866@qq.com"];
    [mailUrl appendString:@"?subject=程序异常崩溃，请配合发送异常报告，谢谢合作！"];
    [mailUrl appendFormat:@"&body=%@", content];
    // 打开地址
    NSString *mailPath = [mailUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:mailPath]];
}
//- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
//{
//    BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url];
//    if (!result) {
//
//    }
//    return result;
//}
//
//- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
//{
//    BOOL result = [[UMSocialManager defaultManager] handleOpenURL:url];
//    if (!result) {
//
//    }
//    return result;
//}


- (void)registerPush:(UIApplication *)application options:(NSDictionary *)launchOptions
{
    // iOS10 下需要使用新的 API
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 10.0) {
#ifdef NSFoundationVersionNumber_iOS_9_x_Max
        UNUserNotificationCenter* center = [UNUserNotificationCenter currentNotificationCenter];
        
        [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert + UNAuthorizationOptionSound + UNAuthorizationOptionBadge)
                              completionHandler:^(BOOL granted, NSError * _Nullable error) {
                                  // 如果用户点里允许
                                  if (granted) {
                                      [application registerForRemoteNotifications];
                                  }
                              }];
#endif
    }
    else { // iOS 8 之后
        UIUserNotificationType myTypes = UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:myTypes categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    }
    /** 参数说明
     *
     launchOptions：App 启动时系统提供的参数。
     apiKey：通过apikey注册百度推送。
     pushMode：当前推送的环境。
     withFirstAction：第二个按钮名字默认会关闭应用 iOS 9 快捷回复需要先设置此参数
     withSecondAction：快捷回复通知的第一个按钮名字默认为打开应用
     withCategory 自定义参数 一组动作的唯一标示 需要与服务端ans的category匹配才能展现通知样式 iOS 9 快捷回复需要先设置此参数
     useBehaviorTextInput: 是否启用 iOS 9快捷回复
     isdebug：是否是debug模式。
     */
    [BPush registerChannel:launchOptions
                    apiKey:BaiduPush_ApiKey
                  pushMode:BPushModeDevelopment
           withFirstAction:@"打开"
          withSecondAction:@"恢复"
              withCategory:@"test"
      useBehaviorTextInput:YES
                   isDebug:YES];
    
    // 禁用地理位置推送 需要再绑定接口前调用。
    [BPush disableLbs];
    
    // MARK: 判断App是否是通过点击推送消息启动的
    NSDictionary *userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    if (userInfo) {
        // 反馈百度
        [BPush handleNotification:userInfo];
    }
    
    // 应用图标角标清零
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}

#pragma mark - (iOS8)用户点击了通知时，应用在前台 或者开启后台并且应用在后台 时调起
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    completionHandler(UIBackgroundFetchResultNewData);
    
    // 应用在前台，不跳转页面，让用户选择
    if (application.applicationState == UIApplicationStateActive) {
        [self showAlert:userInfo];
    }
    
    // 杀死状态下，直接跳转到跳转页面
    if (application.applicationState == UIApplicationStateInactive) {
        //TODO: 点击通知的跳转动作
    }
    
    // 应用在后台。后台设置aps字段里的 content-available 值为1 并开启远程通知激活应用的选项
    if (application.applicationState == UIApplicationStateBackground) {
        // 这里可以选择激活应用，提前下载图片等内容
        isBackGroundActivateApplication = YES;
        [self showAlert:userInfo];
    }
}

#pragma mark - 在iOS8 系统中，需要添加这个方法。通过新 API 注册推送服务
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    [application registerForRemoteNotifications];
}

#pragma mark - 接收到APNs返回的deviceToken时调用
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    // 注册百度推送deviceToken
    [BPush registerDeviceToken:deviceToken];
    // 绑定百度推送
    [BPush bindChannelWithCompleteHandler:^(id result, NSError *error) {
        // 需要在绑定成功后进行 settag、listtag、deletetag、unbind 否则操作会失败
        
        // 网络错误
        if (error) {
            return ;
        }

        if (result) {
            // 确认绑定成功
            if ([result[@"error_code"] integerValue] != 0) {
                return ;
            }
            
            // 获取tag
            [BPush listTagsWithCompleteHandler:^(id result, NSError *error) {
                if (result) {
                    NSLog(@"result === %@", result);
                }
            }];
            
            // 设置tag
            // [BPush setTag:<#(NSString *)#> withCompleteHandler:<#^(id result, NSError *error)handler#>];
            
        }
    }];
}

#pragma mark - 获取deviceToken失败时调用
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"deviceToken获取失败，原因：%@", error);
}

#pragma mark - show alert
- (void)showAlert:(NSDictionary *)userInfo
{
    UIAlertController *alertCtl = [UIAlertController alertControllerWithTitle:@"收到一条消息"
                                                                      message:userInfo[@"aps"][@"alert"]
                                                               preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //TODO: 跳转动作
    }];
    
    [alertCtl addAction:cancel];
    [alertCtl addAction:ok];
    
    [MZKeyWindow.rootViewController presentViewController:alertCtl animated:YES completion:nil];
}


- (void)healthInital
{

    BOOL available = [HKHealthStore isHealthDataAvailable];
    NSLog(@"avavilable: %d", available);

    HKQuantityType *diastolicType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodPressureDiastolic];
    HKQuantityType *systolicType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodPressureSystolic];
    HKQuantityType *heartRateType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeartRate];
    HKQuantityType *bloodOxygenType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierOxygenSaturation];
    HKQuantityType *bloodSugarType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodGlucose];
    HKQuantityType *bodyFatType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyFatPercentage];
    HKQuantityType *weightType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass];

    NSSet *set = [NSSet setWithArray: [NSArray arrayWithObjects: diastolicType, systolicType, heartRateType, bloodOxygenType, bloodSugarType, bodyFatType, weightType, nil]];
    [self.health requestAuthorizationToShareTypes:set readTypes:nil completion:^(BOOL success, NSError *error) {
        if (success) {
            NSLog(@"success");
            // 心率
            if ([self.health authorizationStatusForType:heartRateType] != HKAuthorizationStatusSharingAuthorized) {
                NSLog(@"cannot save heartRate");
            } else {
                [[NSNotificationCenter defaultCenter] addObserverForName:kSaveHeartRateData object:nil queue:nil usingBlock:^(NSNotification *note) {
                    NSDate *date =[NSDate dateWithTimeIntervalSince1970: [note.userInfo[@"meatime"] stringToTimeInteval]];
                    NSString *data = [NSString stringWithFormat:@"%@", note.userInfo[@"data"]];
                    [self saveData:data andDate:date type:kSaveHeartRateData];
                }];
            }
//            舒张压
            if ([self.health authorizationStatusForType:diastolicType] != HKAuthorizationStatusSharingAuthorized) {
                NSLog(@"cannot save diastolicData");
            } else {
                [[NSNotificationCenter defaultCenter] addObserverForName:kSaveDiastolicData object:nil queue:nil usingBlock:^(NSNotification *note) {
                    NSDate *date =[NSDate dateWithTimeIntervalSince1970: [note.userInfo[@"meatime"] stringToTimeInteval]];
                    NSString *data = [NSString stringWithFormat:@"%@", note.userInfo[@"data"]];

                    [self saveData:data andDate:date type:kSaveDiastolicData];
                }];
            }
//            收缩压
            if ([self.health authorizationStatusForType:systolicType] != HKAuthorizationStatusSharingAuthorized) {
                NSLog(@"cannot save systolicData");
            } else {
                [[NSNotificationCenter defaultCenter] addObserverForName:kSaveSystolicData object:nil queue:nil usingBlock:^(NSNotification *note) {
                    NSDate *date =[NSDate dateWithTimeIntervalSince1970: [note.userInfo[@"meatime"] stringToTimeInteval]];
                    NSString *data = [NSString stringWithFormat:@"%@", note.userInfo[@"data"]];
                    [self saveData:data andDate:date type:kSaveSystolicData];
                }];
            }
//            血糖
            if ([self.health authorizationStatusForType:bloodSugarType] != HKAuthorizationStatusSharingAuthorized) {
                NSLog(@"cannot save bloodSugarData");
            } else {
                [[NSNotificationCenter defaultCenter] addObserverForName:kSaveBloodSugarData object:nil queue:nil usingBlock:^(NSNotification *note) {
                    NSDate *date =[NSDate dateWithTimeIntervalSince1970: [note.userInfo[@"meatime"] stringToTimeInteval]];
                    NSString *data = [NSString stringWithFormat:@"%@", note.userInfo[@"data"]];
                    [self saveData:data andDate:date type:kSaveBloodSugarData];
                }];
            }
//            体脂
            if ([self.health authorizationStatusForType:bodyFatType] != HKAuthorizationStatusSharingAuthorized) {
                NSLog(@"cannot save bodyFatData");
            } else {
                [[NSNotificationCenter defaultCenter] addObserverForName:kSaveBodyFatData object:nil queue:nil usingBlock:^(NSNotification *note) {
                    NSDate *date =[NSDate dateWithTimeIntervalSince1970: [note.userInfo[@"meatime"] stringToTimeInteval]];
                    NSString *data = [NSString stringWithFormat:@"%@", note.userInfo[@"data"]];
                    [self saveData:data andDate:date type:kSaveBodyFatData];
                }];
            }
//            体重
            if ([self.health authorizationStatusForType:weightType] != HKAuthorizationStatusSharingAuthorized) {
                NSLog(@"cannot save weightData");
            } else {
                [[NSNotificationCenter defaultCenter] addObserverForName:kSaveWeightData object:nil queue:nil usingBlock:^(NSNotification *note) {
                    NSDate *date =[NSDate dateWithTimeIntervalSince1970: [note.userInfo[@"meatime"] stringToTimeInteval]];
                    NSString *data = [NSString stringWithFormat:@"%@", note.userInfo[@"data"]];
                    [self saveData:data andDate:date type:kSaveWeightData];
                }];
            }
//            血氧
            if ([self.health authorizationStatusForType:bloodOxygenType] != HKAuthorizationStatusSharingAuthorized) {
                NSLog(@"cannot save bloodOxygenData");
            } else {
                [[NSNotificationCenter defaultCenter] addObserverForName:kSaveBloodOxygenData object:nil queue:nil usingBlock:^(NSNotification *note) {
                    NSDate *date =[NSDate dateWithTimeIntervalSince1970: [note.userInfo[@"meatime"] stringToTimeInteval]];
                    NSString *data = [NSString stringWithFormat:@"%@", note.userInfo[@"data"]];
                    [self saveData:data andDate:date type:kSaveBloodOxygenData];
                }];
            }

        } else {
            NSLog(@"failed");
        }
    }];
    
}

- (void)saveData: (NSString *)data andDate: (NSDate *)date type: (NSString *)type {

    if (printShareToHealthLog) {
        NSLog(@"data = %@", data);
        NSLog(@"date = %@", date);
        NSLog(@"type = %@", type);
    }

    // 过滤条件
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond fromDate: date];

    // 开始日期
    NSDate *startDate = [calendar dateFromComponents: components];

    // 结束日期

    NSDate *endDate = [calendar dateByAddingUnit:NSCalendarUnitSecond value:1 toDate:startDate options:0];

    HKQuantityType *quantityType;
    HKQuantity *quantity;
    NSString *successLog;
    if ([type isEqualToString:kSaveDiastolicData]) {
        quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodPressureDiastolic];
        quantity = [HKQuantity quantityWithUnit:[HKUnit millimeterOfMercuryUnit] doubleValue:[data doubleValue]];
        successLog = @"save diastolicData success";
    } else if ([type isEqualToString:kSaveSystolicData]) {
        quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodPressureSystolic];
        quantity = [HKQuantity quantityWithUnit:[HKUnit millimeterOfMercuryUnit] doubleValue:[data doubleValue]];
        successLog = @"save systolicData success";

    } else if ([type isEqualToString:kSaveHeartRateData]) {
        quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierHeartRate];
        quantity = [HKQuantity quantityWithUnit:[HKUnit unitFromString:@"count/min"] doubleValue:[data doubleValue]];
        successLog = @"save heartRate success";

    } else if ([type isEqualToString:kSaveBloodSugarData]) {
        quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBloodGlucose];
        quantity = [HKQuantity quantityWithUnit:[[HKUnit moleUnitWithMolarMass:0.001] unitDividedByUnit: [HKUnit literUnit]] doubleValue:[data doubleValue]];
        successLog = @"save bloodSugarData success";

    } else if ([type isEqualToString:kSaveBodyFatData]) {
        quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyFatPercentage];
        quantity = [HKQuantity quantityWithUnit:[HKUnit percentUnit] doubleValue:[data doubleValue]];
        successLog = @"save bodyFatData success";

    } else if ([type isEqualToString:kSaveWeightData]) {
        quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass];
        quantity = [HKQuantity quantityWithUnit:[HKUnit gramUnitWithMetricPrefix:HKMetricPrefixKilo] doubleValue:[data doubleValue]];
        successLog = @"save weightData success";

    } else if ([type isEqualToString:kSaveBloodOxygenData]) {
        quantityType = [HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierOxygenSaturation];
        quantity = [HKQuantity quantityWithUnit:[HKUnit percentUnit] doubleValue:[data doubleValue]];
        successLog = @"save bloodOxygenData success";

    }
    HKQuantitySample *quantitySample = [HKQuantitySample quantitySampleWithType:quantityType quantity:quantity startDate:startDate endDate:endDate];
    NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:startDate endDate:endDate options:0];
    [self.health deleteObjectsOfType:quantityType predicate: predicate withCompletion:^(BOOL success, NSUInteger deletedObjectCount, NSError *error) {
        if (success) {
            if (printShareToHealthLog) {
                NSLog(@"delete success");
                NSLog(@"deletedObjectCount = %lu", (unsigned long)deletedObjectCount);
            }

        } else {
            NSLog(@"error: %@", error);

        }
    }];
    [self.health saveObject:quantitySample withCompletion:^(BOOL success, NSError *error) {
        if (success) {
            if (printShareToHealthLog) {
                NSLog(@"%@", successLog);

            }
        } else {
            NSLog(@"error: %@", error);
        }
    }];
}
- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
//    NSError *err;

//    [[EventManger shareInstance].store commit:&err];
//    if (err) {
//        NSLog(@"commit error = %@", err);
//    }
}

#pragma mark - App从后台即将进入前台
- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    NSArray *eventArray = [[EventManger shareInstance] getThisWeekEventFromMonday];
    NSLog(@"eventArray.count = %lu", (unsigned long)eventArray.count);
    for (EKEvent *event in eventArray) {
        NSLog(@"event.eventIdentifier = %@", event.eventIdentifier);

    }
    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];

    NSLog(@"remindEventArray = %lu", (unsigned long)remindEventArray.count);

    NSMutableArray *arr = [NSMutableArray array];
    if (remindEventArray) {
        if (remindEventArray.count) {
            for (JZRemindEvent *remindEvent in remindEventArray) {
                for (EKEvent *event in eventArray) {
                    NSLog(@"remindEvent.remindIdentifier = %@", remindEvent.remindIdentifier);
                    if ([remindEvent.remindIdentifier isEqualToString:event.eventIdentifier]) {
                        remindEvent.remind = YES;
                        break;
                    } else {
                        remindEvent.remind = NO;
                    }
                }
                [arr addObject:remindEvent];
                
            }
            
        }
    }

    [arr storeValueByKey:kremindEvent];

    [[NSNotificationCenter defaultCenter] postNotificationName:measureRemindNotification object:nil];
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
//    NSError *err;
//    [[EventManger shareInstance].store commit:&err];
//    if (err) {
//        NSLog(@"commit error = %@", err);
//    }
//    NSLog(@"%s", __FUNCTION__);
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
    [[SDImageCache sharedImageCache] clearMemory];
    [[SDWebImageManager sharedManager] cancelAll];
}
@end
