//
//  JZRefreshInfo.m
//  tf02
//
//  Created by F7686324 on 2017/1/18.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZRefreshInfo.h"

@implementation JZRefreshInfo

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.canHomeRefresh = YES;
        self.canHealthIndicatorRefresh = YES;
        self.canHealthDetailDataRefresh = YES;
        self.canTodayRemindRefresh = YES;
        self.canHistoryRemindMemberListRefresh = YES;
        self.canHistoryRemindRefresh = YES;
        self.canTodayRecommendRefresh = YES;
        self.canCollectionNewsRefresh = YES;
    }
    return self;
}

@end
