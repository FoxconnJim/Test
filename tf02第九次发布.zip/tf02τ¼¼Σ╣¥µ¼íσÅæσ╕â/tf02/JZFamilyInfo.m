//
//  JZFamilyInfo.m
//  tf02
//
//  Created by F7686324 on 8/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZFamilyInfo.h"

@implementation JZFamilyInfo

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.account = [NSString stringWithFormat:@"%@", dict[@"account"]];
        self.mail = [NSString stringWithFormat:@"%@", dict[@"mail"]];
        self.family = [NSString stringWithFormat:@"%@", dict[@"family"]];
        self.ID = [NSString stringWithFormat:@"%@", dict[@"ID"]];
        self.logintime = [NSString stringWithFormat:@"%@", dict[@"logintime"]];
        self.token = [NSString stringWithFormat:@"%@", dict[@"token"]];
        self.delflag = [NSString stringWithFormat:@"%@", dict[@"delflag"]];
        self.tel = [NSString stringWithFormat:@"%@", dict[@"tel"]];
        self.photo = [NSString stringWithFormat:@"%@", dict[@"photo"]];
//        self.pwd = dict[@"pwd"];
        self.createtime = [NSString stringWithFormat:@"%@", dict[@"createtime"]];
    }
    return self;
}

+ (instancetype)familyInfoWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

@end
