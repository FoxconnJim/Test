//
//  JZSelectLocalCityView.h
//  tf02
//
//  Created by F7686324 on 18/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZSelectLocalCityView : UIView

@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UILabel *lbl;
@property (nonatomic, strong) UIButton *btn;
@property (nonatomic, strong) NSString *localCityName;

@end
