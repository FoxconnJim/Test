//
//  JZGetCaptchaView.h
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZCustomField.h"
#import "JZGetCaptchaFrame.h"


@interface JZGetCaptchaView : UIView

@property (nonatomic, strong) JZGetCaptchaFrame *getCaptchaFrame;
@property (nonatomic, strong) UIImageView *backgroundImageView;

@property (nonatomic, strong) UIImageView *imgView;

@property (nonatomic, strong) UILabel *title;

@property (nonatomic, strong) UILabel *upLabel;
@property (nonatomic, strong) UILabel *upSublabel;
@property (nonatomic, strong) JZCustomField *upField;

@property (nonatomic, strong) UILabel *downLabel;
@property (nonatomic, strong) UILabel *downSublabel;
@property (nonatomic, strong) JZCustomField *downField;

@property (nonatomic, strong) UIButton *captchaBtn;

@property (nonatomic, strong) UIButton *foundBackBtn;

@property (nonatomic, strong) UIButton *backBtn;

@end
