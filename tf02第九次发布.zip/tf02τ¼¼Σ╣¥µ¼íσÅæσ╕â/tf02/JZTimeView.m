//
//  JZTimeView.m
//  tf02
//
//  Created by F7686324 on 02/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZTimeView.h"
#import "NSArray+JZRemoveByInteval.h"
#import "NSString+JZGetStringWidth.h"

@implementation JZTimeView

- (void)setPointArray:(NSMutableArray *)pointArray
{
    _pointArray = pointArray;
    if (![self.timeLengthString isEqualToString:jzYear]) {
        [self.textFrameArray removeAllObjects];

        CGFloat scaleWidth = 0;

        for (NSString *text in self.textArray) {
            if ([text getStringWidth] > scaleWidth) {
                scaleWidth = [text getStringWidth];
            }
        }
        scaleWidth += 10;
        CGFloat scaleHeight = self.bounds.size.height;

        for (JZPoint *point in pointArray) {
            CGRect rect = CGRectMake(point.x * self.bounds.size.width - scaleWidth / 2, 0, scaleWidth, scaleHeight);
            [self.textFrameArray addObject:NSStringFromCGRect(rect)];
        }

        [self setNeedsDisplay];
    }

}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;
}

- (void)setTextArray:(NSMutableArray *)textArray
{
    _textArray = textArray;
    [self.textFrameArray removeAllObjects];
    if ([self.timeLengthString isEqualToString:jzYear]) {
        CGFloat scaleWidth = self.bounds.size.width / (textArray.count + 1);
        CGFloat scaleHeight = self.bounds.size.height;
        for (int i = 0; i < textArray.count; i++) {
            CGRect rect = CGRectMake(scaleWidth / 2 + i * scaleWidth, 0, scaleWidth, scaleHeight);
            [self.textFrameArray addObject:NSStringFromCGRect(rect)];
        }

        [self setNeedsDisplay];
    }

}

- (NSMutableArray *)textFrameArray
{
    if (!_textFrameArray) {
        _textFrameArray = [NSMutableArray array];
    }
    return _textFrameArray;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];

    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];

//    CGContextRef context = UIGraphicsGetCurrentContext();
    UIFont *font = [UIFont systemFontOfSize:10.f];
    NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByCharWrapping;
    paragraphStyle.alignment = NSTextAlignmentCenter;
    NSDictionary *attribute = @{
                                NSForegroundColorAttributeName:[UIColor colorWithWhite:0.9 alpha:0.9],
                                NSFontAttributeName:font,
                                NSKernAttributeName:@0,
                                NSParagraphStyleAttributeName:paragraphStyle
                                };
    for (int i = 0; i < self.textArray.count; i++) {
        NSString *text = self.textArray[i];
        CGRect textRect = CGRectFromString(self.textFrameArray[i]);
        CGSize sizeText = [text boundingRectWithSize:textRect.size options:NSStringDrawingUsesLineFragmentOrigin attributes:attribute context:nil].size;
        CGRect timeRect = CGRectMake(textRect.origin.x + (textRect.size.width - sizeText.width) / 2, textRect.origin.y + (textRect.size.height - sizeText.height) / 2, sizeText.width, sizeText.height);

//        NSLog(@"text = %@", text);
//        NSLog(@"timeRect = %@", NSStringFromCGRect(timeRect));
//        NSLog(@"textRect = %@", NSStringFromCGRect(textRect));
        [text drawInRect:timeRect withAttributes:attribute];
    }
}

@end
