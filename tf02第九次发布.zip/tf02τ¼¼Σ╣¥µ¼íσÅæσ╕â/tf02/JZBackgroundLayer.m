//
//  JZBackgroundLayer.m
//  tf02
//
//  Created by AN PEN on 8/12/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZBackgroundLayer.h"

@implementation JZBackgroundLayer

- (void)setStartColor:(UIColor *)startColor
{
    _startColor = startColor;
    if (self.endColor) {
        [self setColorsAndLocations];
    }
}

- (void)setEndColor:(UIColor *)endColor
{
    _endColor = endColor;
    if (self.endColor) {
        [self setColorsAndLocations];
    }
}

- (void)setColorsAndLocations
{
    NSArray *colors = [NSArray arrayWithObjects:(id)self.startColor.CGColor, (id)self.endColor.CGColor, nil];
    NSNumber *stopOne = [NSNumber numberWithFloat: 0.0];
    NSNumber *stopTwo = [NSNumber numberWithFloat: 1.0];
    NSArray *locations = [NSArray arrayWithObjects:stopOne, stopTwo, nil];
    self.colors = colors;
    self.locations = locations;
    self.cornerRadius = 5;
    self.masksToBounds = YES;
    self.borderColor = [UIColor colorWithWhite:0 alpha:0.3].CGColor;
    self.borderWidth = 1;
}
@end
