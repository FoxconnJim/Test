//
//  JZModifyPasswordFrame.m
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZModifyPasswordFrame.h"

@implementation JZModifyPasswordFrame
- (instancetype)init
{
    self = [super init];
    if (self) {
        CGFloat margin = screenW / 15;

        CGFloat titleX = margin;
        CGFloat titleY = screenH / 6;
        CGFloat titleW = screenW -titleX;
        CGFloat titleH = 30;
        self.titleFrame = CGRectMake(titleX, titleY, titleW, titleH);

        CGFloat upLabelX = titleX;
        CGFloat upLabelY = titleY + titleH + margin;
        CGFloat upLabelW = screenW / 5;
        CGFloat upLabelH = titleH;
        self.upLabelFrame = CGRectMake(upLabelX, upLabelY, upLabelW, upLabelH);

        CGFloat upFieldX = upLabelX + upLabelW + 5;
        CGFloat upFieldY = upLabelY;
        CGFloat upFieldW = screenW - upFieldX - margin * 2;
        CGFloat upFieldH = upLabelH;
        self.upFieldFrame = CGRectMake(upFieldX, upFieldY, upFieldW, upFieldH);

        CGFloat upSubLabelX = upFieldX;
        CGFloat upSubLabelY = upFieldY + upFieldH + 5;
        CGFloat upSubLabelW = upFieldW;
        CGFloat upSubLabelH = upFieldH / 2;
        self.upSublabelFrame = CGRectMake(upSubLabelX, upSubLabelY, upSubLabelW, upSubLabelH);

        CGFloat upTipW = 30;
        CGFloat upTipH = 30;
        CGFloat upTipX = upFieldX + upFieldW + 5;
        CGFloat upTipY = upFieldY + (upFieldH - upTipH) / 2;

        self.upTipFrame = CGRectMake(upTipX, upTipY, upTipW, upTipH);

        CGFloat downLabelX = upLabelX;
        CGFloat downLabelY = upLabelY + upLabelH + margin * 2;
        CGFloat downLabelW = upLabelW;
        CGFloat downLabelH = upLabelH;
        self.downLabelFrame = CGRectMake(downLabelX, downLabelY, downLabelW, downLabelH);

        CGFloat downFieldX = upFieldX;
        CGFloat downFieldY = downLabelY;
        CGFloat downFieldW = upFieldW;
        CGFloat downFieldH = downLabelH;
        self.downFieldFrame = CGRectMake(downFieldX, downFieldY, downFieldW, downFieldH);

        CGFloat downSublabelX = upSubLabelX;
        CGFloat downSublabelY = downFieldY + downFieldH + 5;
        CGFloat downSublabelW = upSubLabelW;
        CGFloat downSublabelH = upSubLabelH;
        self.downSublabelFrame = CGRectMake(downSublabelX, downSublabelY, downSublabelW, downSublabelH);

        CGFloat downTipW = upTipW;
        CGFloat downTipH = upTipH;
        CGFloat downTipX = downFieldX + downFieldW + 5;
        CGFloat downTipY = downFieldY + (downFieldH - downTipH) / 2;

        self.downTipFrame = CGRectMake(downTipX, downTipY, downTipW, downTipH);

        CGFloat btnX = margin * 2;
        CGFloat btnY = downFieldY + downFieldH + margin * 3;
        CGFloat btnW = screenW - btnX * 2;
        CGFloat btnH = 35;
        self.modifyBtnFrame = CGRectMake(btnX, btnY, btnW, btnH);
        
        CGFloat backBtnW = btnW;
        CGFloat backBtnH = btnH;
        CGFloat backBtnX = btnX;
        CGFloat backBtnY = btnY + btnH + 5;
        self.backBtnFrame = CGRectMake(backBtnX, backBtnY, backBtnW, backBtnH);
    }
    return self;
}
@end
