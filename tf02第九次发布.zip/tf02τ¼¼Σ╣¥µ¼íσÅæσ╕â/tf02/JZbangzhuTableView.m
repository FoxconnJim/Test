//
//  JZbangzhuTableView.m
//  tf02
//
//  Created by AN PEN on 5/18/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZbangzhuTableView.h"
#import "Utility.h"
@interface JZbangzhuTableView ()
{
    CGFloat rowFont;
    CGFloat sectionFont;
    //        初始化section“文字与上下边界”的高度；
    CGFloat sectionMargin;
    //        初始化row“文字与上下边界”的高度；
    CGFloat rowMargin;
    //        初始化section“文字与左边界”的距离，**************row文字与左边界的距离为15且无法改变*****************；
    CGFloat margin;
}

@property (nonatomic, strong) NSMutableArray *rowHeightArray;
@property (nonatomic, strong) NSMutableArray *sectionHeightArray;
@property (nonatomic, strong) NSMutableArray *selectArray;
@property (nonatomic, strong) UIColor *sectionbackColor;
@property (nonatomic, strong) UIColor *sectiontextColor;
@property (nonatomic, strong) UIColor *rowbackColor;
@property (nonatomic, strong) UIColor *rowtextColor;

@end

@implementation JZbangzhuTableView
@synthesize rowHeightArray;
@synthesize sectionHeightArray;
@synthesize sectionbackColor;
@synthesize sectiontextColor;
@synthesize rowbackColor;
@synthesize rowtextColor;

- (void)setRowArray:(NSMutableArray *)rowArray
{
    _rowArray = rowArray;
    self.selectArray = [NSMutableArray array];
    for (int i = 0; i < rowArray.count; i++)
    {
        [self.selectArray addObject: @"open"];
    }

    //    计算“row的高度”；
    for (int arrayCount = 0; arrayCount < self.selectArray.count; arrayCount++)
    {
        //        获得row”文字大小的Size“，该Size的宽高均为CGFlot类型，该Size是将row中所有的文字写成一行时所获取的值，所以该尺寸的宽就为row中所有文字的总宽度；
        CGSize rowSize = [rowArray[arrayCount] sizeWithAttributes: @{NSFontAttributeName: [UIFont systemFontOfSize: rowFont]}];
        //        用row“文字大小Size的总宽度”除以“文字Label的宽”所得的CGFloat类型的值转化为整形的值存放到number变量中，number＋1 即为row中的”文字行数“；

        int rowCount = [NSNumber numberWithFloat: rowSize.width / (self.frame.size.width - margin * 2)].intValue + 1;
        //        用row中的文字行数计算出”row的高度”，并将row的高度存放到rowHeightArray数组中；
        [rowHeightArray addObject:@(rowCount * rowFont + rowMargin * 2)];
    }

}

- (void)setSectionArray:(NSMutableArray *)sectionArray
{
    _sectionArray = sectionArray;
    self.selectArray = [NSMutableArray array];
    for (int i = 0; i < sectionArray.count; i++)
    {
        [self.selectArray addObject: @"open"];
    }
    //    计算section的高度并存放到sectionHeightArray数组中，方法与计算row的高度值的方法一致；
    for (int arrayCount = 0; arrayCount < self.selectArray.count; arrayCount++)
    {
        CGSize sectionSize = [sectionArray[arrayCount] sizeWithAttributes: @{NSFontAttributeName: [UIFont systemFontOfSize: sectionFont]}];
        int sectionCount = [NSNumber numberWithFloat: sectionSize.width / (self.frame.size.width - margin * 2)].intValue + 1;
        [sectionHeightArray addObject:@(sectionCount * sectionFont + sectionMargin * 2)];
        //        因为section中右侧的图片大小宽高在后面均设为margin的值了，所以当section的高度小于margin的值时，令section的高度等于margin的值；
        if (sectionCount * sectionFont + sectionMargin < margin)
        {
            [sectionHeightArray addObject: @(margin)];
        }
    }
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.delegate = self;
        self.dataSource = self;
        self.separatorStyle = UITableViewCellSeparatorStyleNone;
        rowFont = 15;
        sectionFont = 17;

        self.selectArray = [[NSMutableArray alloc] init];

        sectionMargin = frame.size.width / 30;
        rowMargin = frame.size.width / 30;
        margin = 15;

        sectionbackColor = [UIColor whiteColor];
        sectiontextColor = barBackgroundColor;
        rowbackColor = [UIColor whiteColor];
        rowtextColor = [UIColor grayColor];

        sectionHeightArray = [NSMutableArray array];
        rowHeightArray = [NSMutableArray array];

    }
    return self;
}


#pragma mark *****************设置表视图每个section的row的数目**********************
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //    如果selectArray数组中第i个字符串的内容为@"open"，则显示第i个section的row，否则不显示；
    if ([self.selectArray[section] isEqualToString:@"open"])
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

#pragma mark ******************设置表视图每个row中的内容***********************
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"cellid";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    cell.backgroundColor = rowbackColor;
    cell.textLabel.textColor = rowtextColor;
    cell.textLabel.text = self.rowArray[indexPath.section];
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.font = [UIFont systemFontOfSize: rowFont];
    UIView *line = [[UIView alloc] initWithFrame: CGRectMake(0, rowHeightArray.count == 0 ? 0 : [NSString stringWithFormat:@"%@", [rowHeightArray objectAtIndex:indexPath.section]].floatValue - 2, self.frame.size.width, 2)];
    line.backgroundColor = appBackgroundColor;
    [cell addSubview: line];
    return cell;
}
#pragma mark *******************设置表视图中的row是否可点击**********************
- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath
{
    return NO;
}
#pragma mark ********************设置表视图中section的数目**********************
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.sectionArray.count;
}
#pragma mark *********************设置表视图中row的高度*************************
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return rowHeightArray.count == 0 ? 0 : [NSString stringWithFormat:@"%@", [rowHeightArray objectAtIndex:indexPath.section]].floatValue;
}
#pragma mark **********************设置表视图中section的高度************************
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return sectionHeightArray.count == 0 ? 0 : [NSString stringWithFormat:@"%@", [sectionHeightArray objectAtIndex:section]].floatValue;
}
#pragma mark ***********************设置表视图中每个section的内容*************************
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    //    设置section上的背景视图；
    UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, [NSString stringWithFormat:@"%@", [sectionHeightArray objectAtIndex:section]].floatValue)];
    headView.backgroundColor = sectionbackColor;
    //    设置显示文字的Label；
    UILabel *headLabel = [[UILabel alloc] initWithFrame:CGRectMake(margin, 0, self.frame.size.width - margin * 3, headView.bounds.size.height)];
    headLabel.text = self.sectionArray[section];
    headLabel.numberOfLines = 0;
    headLabel.font = [UIFont boldSystemFontOfSize:sectionFont];
    headLabel.textColor = sectiontextColor;
    [headView addSubview:headLabel];
    //    设置可点击的Button；
    UIButton *headButton = [[UIButton alloc] initWithFrame:headView.bounds];
    [headButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    headButton.tag = section;
    //    设置按钮上的imageView；
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(headLabel.bounds.size.width + margin * 1.5, (headView.bounds.size.height - margin) / 2, margin / 2, margin)];
    [imageView setImage:[UIImage imageNamed:@"arrow"]];
    //    如果imageView没有设置图片，则给imageView添加一个ArrowView子视图，子视图中画了一个自带的箭头
//    if ([imageName  isEqual: @""])
//    {
//        ArrowView *arrowView = [[ArrowView alloc] initWithFrame: imageView.bounds];
//        arrowView.backgroundColor = headView.backgroundColor;
//        [imageView addSubview:arrowView];
//    }
    //    如果selectArray中第section的字符串内容为@"open"，则使imageView顺时针旋转90度；
    if ([self.selectArray[section] isEqualToString:@"open"])
    {
        imageView.transform = CGAffineTransformMakeRotation(M_PI_2);
    }
    [headButton addSubview:imageView];
    [headView addSubview:headButton];
    return headView;
}
#pragma mark ***********************设置点击事件***********************
- (void)click: (UIButton *)button
{
    //    点击了哪个section上的按钮，就将这个section对应的selectArray中的字符串内容设置为相反的值，从而实现点击哪个按钮改变对应section的row的数目

    if ([self.selectArray[button.tag] isEqualToString: @"close"])
    {
        [self.selectArray replaceObjectAtIndex: button.tag withObject: @"open"];
    }
    else
    {
        [self.selectArray replaceObjectAtIndex: button.tag withObject: @"close"];
    }
    NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:button.tag];
    [self reloadSections:indexSet withRowAnimation: UITableViewRowAnimationFade];
}


































@end

