//
//  JZPadScaleView.m
//  tf02
//
//  Created by F7686324 on 03/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZPadScaleView.h"
#import "NSArray+JZRemoveByInteval.h"
#import "NSString+JZGetStringWidth.h"

@implementation JZPadScaleView


- (UISegmentedControl *)segment
{
    if (!_segment) {
        _segment = [[JZSegment alloc] init];
    }
    return _segment;
}

- (JZTimeView *)timeView
{
    if (!_timeView) {
        _timeView = [[JZTimeView alloc] initWithFrame:self.bounds];
    }
    return _timeView;
}

- (void)setTextArray:(NSMutableArray *)textArray
{
    _textArray = textArray;
}

- (void)setPointArray:(NSMutableArray *)pointArray
{
    _pointArray = pointArray;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.jzScale = 1.f;
        [self addSubview:self.timeView];
    }
    return self;
}

- (JZTime *)jzTime
{
    if (!_jzTime) {
        _jzTime = [[JZTime alloc] init];
    }
    return _jzTime;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;

    self.timeView.timeLengthString = timeLengthString;
    self.timeView.frame = CGRectZero;
    [self.segment removeFromSuperview];

    if ([timeLengthString isEqualToString:jzYear]) {

        self.segment = [[JZSegment alloc] initWithFrame:CGRectMake(self.frame.size.width / 12.f, 0, self.frame.size.width, self.frame.size.height)];
        NSArray *array = [self.jzTime.yearArray firstObject];
        for (int i = 0; i < array.count; i++) {
            [self.segment insertSegmentWithTitle:[array objectAtIndex:i] atIndex:i animated:YES];
        }
        [self addSubview: self.segment];

    } else {
        CGRect frame = self.frame;
        CGFloat margin = 5;
        CGFloat jzWidth = screenW - screenEdgeMargin * 2 - margin * 2;
        frame.size.width = jzWidth * self.jzScale;
        self.frame = frame;
        self.timeView.frame = self.bounds;
        if (self.textArray.count) {
            CGFloat scaleWidth = 0;
            for (NSString *text in self.textArray) {
                if ([text getStringWidth] > scaleWidth) {
                    scaleWidth = [text getStringWidth];
                }
            }
            scaleWidth += 10;
            for (int i = 0; i < self.textArray.count; i++) {
                NSMutableArray *textArr = [self.textArray removeByInteval:i];
                CGFloat width = self.bounds.size.width / textArr.count;

                if (width >= scaleWidth) {
                    self.timeView.textArray = textArr;
                    self.timeView.pointArray = [self.pointArray removeByInteval:i];
                    break;
                }
            }
        }

    }

}

- (void)setJzScale:(CGFloat)jzScale
{
    _jzScale = jzScale;

    [self jzSetNeedsDisplay];
}

- (void)jzSetNeedsDisplay
{
    CGRect frame = self.frame;
    CGFloat margin = 5;
    CGFloat jzWidth = screenW - screenEdgeMargin * 2 - margin * 2;
    frame.size.width = jzWidth * self.jzScale;
    self.frame = frame;
    self.timeView.frame = self.bounds;

    if ([self.timeLengthString isEqualToString:jzYear]) {
        if (self.jzScale >= 1.f & self.jzScale < 1.5f) {

            self.timeView.frame = CGRectMake(-frame.size.width / 24.f, 0, frame.size.width * 5.f / 4.f, frame.size.height);

            self.timeView.textArray = [self.jzTime.yearArray objectAtIndex:0];

        } else if (self.jzScale >= 1.5f & self.jzScale < 3.f) {

            self.timeView.frame = CGRectMake(-frame.size.width / 24.f, 0, frame.size.width * 7.f / 6.f, frame.size.height);

            self.timeView.textArray = [self.jzTime.yearArray objectAtIndex:1];

        } else if (self.jzScale >= 3.f) {

            self.timeView.frame = CGRectMake(-frame.size.width / 24.f, 0, frame.size.width * 13.f / 12.f, frame.size.height);

            self.timeView.textArray = [self.jzTime.yearArray objectAtIndex:2];
            
        }
    } else {
        if (self.textArray.count) {
            CGFloat scaleWidth = 0;
            for (NSString *text in self.textArray) {
                if ([text getStringWidth] > scaleWidth) {
                    scaleWidth = [text getStringWidth];
                }
            }
            scaleWidth += 10;
            for (int i = 0; i < self.textArray.count; i++) {
                NSMutableArray *textArr = [self.textArray removeByInteval:i];
                CGFloat width = self.bounds.size.width / textArr.count;

                if (width >= scaleWidth) {
                    self.timeView.textArray = textArr;
                    self.timeView.pointArray = [self.pointArray removeByInteval:i];
                    break;
                }
            }
        }

    }
}



@end
