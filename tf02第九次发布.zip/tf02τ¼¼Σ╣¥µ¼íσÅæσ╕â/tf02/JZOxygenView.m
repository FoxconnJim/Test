//
//  JZOxygenView.m
//  tf02
//
//  Created by AN PEN on 3/31/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZOxygenView.h"
#import "JZbloodOxygenData.h"
#import "JZOperation.h"
#import "NSString+Date.h"
#import "Utility.h"
#import "JZFmdbTool.h"

@interface JZOxygenView () <JZOperationDelegate>

@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, copy) NSString *memberId;

@end

@implementation JZOxygenView
- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        self.backgroundLayer.startColor = [UIColor colorWithRed:0.00 green:0.82 blue:0.67 alpha:1.00];
        self.backgroundLayer.endColor = [UIColor colorWithRed:0.00 green:0.60 blue:0.35 alpha:1.00];
        self.titleLabel.text = @"血氧";
        self.jzType = @"血氧";

        [self.imgView setImage:[UIImage imageNamed: @"oxygen"]];
        [self initUI];

    }
    return self;
}


- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;
    [self initTimeAndValueWithType:self.jzType];

    self.jzScale = 1.f;

    self.scrollView.contentSize = CGSizeMake(screenW - screenEdgeMargin * 2 - 5 * 2, self.dataView.frame.size.height);

//    [self initUI];

    NSMutableDictionary *param = [self paramWithTimeLengthString:timeLengthString];

    JZOperation *operation = [JZOperation operationWithURLString:oxygenURL andParam:param getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = bloodOxygenOpreation;

}

#pragma mark - JZOperation Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSArray *arr = responseObject[@"data"];

    NSArray *array = (NSArray *)arr;

    [self handleDataWithArray:array success:YES];

    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [self initUI];
        NSArray *array = [JZFmdbTool queryBloodOxygenDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];

        [self handleDataWithArray:array success:NO];
    }

    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)handleDataWithArray:(NSArray *)array success:(BOOL)success
{

    NSMutableArray *pointArray = [NSMutableArray array];

    if ([array isKindOfClass:[NSArray class]]) {

        [self.bigDataArray removeAllObjects];

        if (array.count) {
            [self.indicatorLabel removeFromSuperview];

            [JZFmdbTool beginTransaction];

            @try {
                [self.dataArray removeAllObjects];
                if (success) {
                    [JZFmdbTool deleteBloodOxygenDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];

                }
                for (int i = 0; i < array.count; i++) {
                    JZBloodOxygenData *oxygenData;
                    if (success) {
                        NSDictionary *dict = array[i];
                        oxygenData = [JZBloodOxygenData dataWithDictionary:dict];
                        [JZFmdbTool insertBloodOxygenData:oxygenData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    } else {
                        oxygenData = array[i];
                    }

                    [self.dataArray addObject: oxygenData];
                    JZDataPoint *dataPoint = [JZDataPoint dataPointWithMeatime:oxygenData.meatime data:oxygenData.data];
                    [pointArray addObject:dataPoint];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            JZPadHandleData2017 *padHandleData = [JZPadHandleData2017 dataWithArray:pointArray timeLengthString:self.timeLengthString];


            [self.bigDataArray addObject:padHandleData.totalArray];

            self.textArray = padHandleData.meatimeArray;

            //            JZHandleData *handleData = [JZHandleData dataWithArray:pointArray timeLengthString:self.timeLengthString];
            //            [self.bigDataArray addObject:handleData.dataArray];
            self.dataView.bigDataArray = self.bigDataArray;
            [self.scrollView addSubview:self.dataView];

            //            self.scaleView.timeLengthString = self.timeLengthString;
            //            [self.scrollView addSubview: self.scaleView];
            self.padScaleView.pointArray = padHandleData.totalArray;
            self.padScaleView.textArray = padHandleData.meatimeArray;
            self.padScaleView.timeLengthString = self.timeLengthString;

            [self.scrollView addSubview:self.padScaleView];
            // 细节显示
            self.maxValue.text = [NSString stringWithFormat:@"%0.0f", self.dataView.maxValue];
            self.minValue.text = [NSString stringWithFormat:@"%0.0f", self.dataView.minValue];


        } else {
            [self initUI];
        }
    } else {
        [self initUI];
    }
}
- (void)initUI
{

    self.maxValue.text = @"";
    self.minValue.text = @"";
//    [self.scaleView removeFromSuperview];
    [self.padScaleView removeFromSuperview];

    [self.dataView removeFromSuperview];
    [self addSubview:self.indicatorLabel];
}

@end
