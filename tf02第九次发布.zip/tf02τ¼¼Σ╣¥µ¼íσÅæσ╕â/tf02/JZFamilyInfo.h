//
//  JZFamilyInfo.h
//  tf02
//
//  Created by F7686324 on 8/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZFamilyInfo : NSObject

@property (nonatomic, copy) NSString *account;
@property (nonatomic, copy) NSString *mail;
@property (nonatomic, copy) NSString *family;
@property (nonatomic, copy) NSString *ID;
@property (nonatomic, copy) NSString *logintime;
@property (nonatomic, copy) NSString *token;
@property (nonatomic, copy) NSString *delflag;
@property (nonatomic, copy) NSString *tel;
@property (nonatomic, copy) NSString *photo;
@property (nonatomic, copy) NSString *pwd;
@property (nonatomic, copy) NSString *createtime;

- (instancetype)initWithDictionary: (NSDictionary *)dict;
+ (instancetype)familyInfoWithDictionary: (NSDictionary *)dict;

@end
