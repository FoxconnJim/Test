//
//  iRonIconImageViewController.m
//  tf02
//
//  Created by IDSBG-00 on 2016/9/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "iRonIconImageViewController.h"
#import "iRonIconImageView.h"
#import "JZOperation.h"
#import "JZIconViewController.h"

@interface iRonIconImageViewController ()<iRoniconImageViewDelegate, JZOperationDelegate>

@property (nonatomic, strong) NSOperationQueue *queue;

@end

@implementation iRonIconImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    iRonIconImageView *iconView = [[iRonIconImageView alloc] initWithFrame:self.view.bounds];
    iconView.delegate = self;
    self.view = iconView;
    self.title = @"我的家庭";
}


- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
//        JZIconViewController *iconVC = [[JZIconViewController alloc] init];
//        iconVC.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
//        [self presentViewController:iconVC animated:YES completion:nil];
    } else if (indexPath.section == 1 ) {
        if (indexPath.row == 3) {
//            [self modifyPassword];
//            [self forgetPassword];
        }
    }
    
    
}

- (void)modifyPassword
{
    UITextField *passwordTF = [[UITextField alloc] init];
    passwordTF.secureTextEntry = YES;
    UITextField *passwordConfirmTF = [[UITextField alloc] init];
    passwordConfirmTF.secureTextEntry = YES;
    
    UIAlertController *alterController = [UIAlertController alertControllerWithTitle:@"修改密码" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alterController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField = passwordTF;
    }];
    [alterController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField = passwordConfirmTF;
    }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
//    __weak typeof(self) weakSelf = self;
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"修改" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        // TODO: 修改密码
//        NSMutableDictionary *param = [NSMutableDictionary dictionary];
//
//        
//        JZOperation *operation = [JZOperation operationWithURLString:usersRegisterURL andParam:param getOrPost:JZ_POST];
//        operation.delegate = weakSelf;
//        [self.queue addOperation: operation];
    }];
    
    [alterController addAction:ok];
    [alterController addAction:cancel];
    
    [self presentViewController:alterController animated:YES completion:nil];
}



- (void)didFinishDownLoadWithOperation: (JZOperation *)operation andResponseObject: (id) responseObject
{
    
}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{

}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}


@end
