//
//  JZHealthIndicatorFrame.h
//  tf02
//
//  Created by Jim on 16/3/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIkit.h>

@interface JZHealthIndicatorFrame : NSObject

@property (nonatomic, assign) CGRect segmentFrame;
@property (nonatomic, assign) CGRect cellFrame;

@end
