//
//  JZHeartRateData.h
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZData.h"

@interface JZHeartRateData : JZData

@property (nonatomic, strong) NSString *eegdata;
@property (nonatomic, strong) NSString *numberturns;

@end
