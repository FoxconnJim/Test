//
//  NSDate+local.m
//  tf02
//
//  Created by AN PEN on 7/15/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "NSDate+local.h"

@implementation NSDate (local)

- (NSDate *)localDate
{
    NSTimeZone *zone = [NSTimeZone systemTimeZone];
    NSInteger interval = [zone secondsFromGMTForDate: self];
    NSDate *localDate = [self dateByAddingTimeInterval: interval];
    return localDate;
}

@end
