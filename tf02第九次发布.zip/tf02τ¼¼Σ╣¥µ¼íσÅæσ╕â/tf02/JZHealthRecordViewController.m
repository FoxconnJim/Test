//
//  JZHealthRecordViewController.m
//  tf02
//
//  Created by F7686324 on 20/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHealthRecordViewController.h"
#import "JZHealthRecordView.h"
#import "Utility.h"
#import "JZHealthDetailECGViewController.h"

@interface JZHealthRecordViewController () <JZHealthRecordViewDelegate>

@property (nonatomic, strong) JZHealthRecordView *healthRecordView;

@end

@implementation JZHealthRecordViewController

- (JZHealthRecordView *)healthRecordView
{
    if (!_healthRecordView) {
        _healthRecordView = [[JZHealthRecordView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - statusBarHeight - naviHeight)];
        _healthRecordView.delegate = self;
    }
    return _healthRecordView;
}

- (void)setBpData:(JZBloodPressureData *)bpData
{
    _bpData = bpData;

    self.healthRecordView.bpData = bpData;
    [self.view addSubview:self.healthRecordView];
}

- (void)setJzdata:(JZData *)jzdata
{
    _jzdata = jzdata;
    self.healthRecordView.jzdata = jzdata;
    [self.view addSubview:self.healthRecordView];
}

- (void)setHrData:(JZHeartRateData *)hrData
{
    _hrData = hrData;
    self.healthRecordView.hrData = hrData;
    [self.view addSubview:self.healthRecordView];

}

- (void)setJzType:(NSString *)jzType
{
    _jzType = jzType;
    self.healthRecordView.jzType = jzType;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"测量详情";
}

- (void)showECGGainWithECGDataView:(JZECGDataView *)ECGDataView
{
    JZHealthDetailECGViewController *healthDetailECGVC = [[JZHealthDetailECGViewController alloc] init];
    healthDetailECGVC.array = ECGDataView.dataArray;
    healthDetailECGVC.lblTurns.text = ECGDataView.lblText;
    [self.navigationController pushViewController:healthDetailECGVC animated:YES];
}

@end
