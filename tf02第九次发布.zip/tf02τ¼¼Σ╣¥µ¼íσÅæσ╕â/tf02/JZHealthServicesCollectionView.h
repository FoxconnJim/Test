//
//  JZHealthServicesCollectionView.h
//  tf02
//
//  Created by F7686324 on 2016/12/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZPageControlView.h"
#import "JZHealthServicesOptView.h"

@class JZHealthServicesCollectionView;
@protocol JZHealthServicesCollectionViewDelegate <NSObject>

@optional
- (void)healthServicesCollectionView:(JZHealthServicesCollectionView *)healthServicesCollectionView didSelectItemsAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface JZHealthServicesCollectionView : UIView <UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) JZPageControlView *pageView;
@property (nonatomic, strong) JZHealthServicesOptView *hlzxView;
@property (nonatomic, strong) JZHealthServicesOptView *jyzxView;
//@property (nonatomic, strong) JZHealthServicesOptView *xsghView;
//@property (nonatomic, strong) JZHealthServicesOptView *xsyjView;
@property (nonatomic, strong) JZHealthServicesOptView *jtysView;


@property (nonatomic, weak) id <JZHealthServicesCollectionViewDelegate> delegate;

@end
