//
//  JZIndicatorView.m
//  tf02
//
//  Created by F7686324 on 02/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZIndicatorView.h"

@implementation JZIndicatorView

- (void)setPointArray:(NSMutableArray *)pointArray
{
    _pointArray = pointArray;
    for (NSMutableArray *pointArr in pointArray) {
        for (int i = 0; i < pointArr.count; i++) {
            JZPoint *point = pointArr[i];
            [self.pointFrameArray addObject:NSStringFromCGRect(CGRectMake(point.x, point.y, 100, 20))];
        }
    }

    [self setNeedsDisplay];
}

- (void)setDataArray:(NSMutableArray *)dataArray
{
    _dataArray = dataArray;
    for (NSMutableArray *dataArr in dataArray) {
        for (int i = 0; i < dataArr.count; i++) {

        }
    }
}

- (NSMutableArray *)pointFrameArray
{
    if (!_pointFrameArray) {
        _pointFrameArray = [NSMutableArray array];
    }
    return _pointFrameArray;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        radius = 1.5f;
        lineWidth = 1.5f;
    }
    return self;
}


- (void)drawRect:(CGRect)rect
{
//    CGContextRef context = UIGraphicsGetCurrentContext();

    UIFont *font = [UIFont systemFontOfSize:10.f];
    NSMutableParagraphStyle *paragraphStyle = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    paragraphStyle.lineBreakMode = NSLineBreakByCharWrapping;
    paragraphStyle.alignment = NSTextAlignmentCenter;
    NSDictionary *attribute = @{
                                NSForegroundColorAttributeName:[UIColor colorWithWhite:0.9 alpha:0.9],
                                NSFontAttributeName:font,
                                NSKernAttributeName:@0,
                                NSParagraphStyleAttributeName:paragraphStyle
                                };
    for (int i = 0; i < self.pointArray.count; i++) {
        NSString *text = self.pointArray[i];
        CGRect textRect = CGRectFromString(self.pointFrameArray[i]);
        CGSize sizeText = [text boundingRectWithSize:textRect.size options:NSStringDrawingUsesLineFragmentOrigin attributes:attribute context:nil].size;
        CGRect timeRect = CGRectMake(textRect.origin.x + (textRect.size.width - sizeText.width) / 2, textRect.origin.y + (textRect.size.height - sizeText.height) / 2, sizeText.width, sizeText.height);

        NSLog(@"text = %@", text);
        NSLog(@"timeRect = %@", NSStringFromCGRect(timeRect));
        NSLog(@"textRect = %@", NSStringFromCGRect(textRect));
        [text drawInRect:timeRect withAttributes:attribute];

    }
}
@end
