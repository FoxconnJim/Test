//
//  JZContactUsViewController.m
//  tf02
//
//  Created by F7686324 on 03/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZContactUsViewController.h"
#import "JZContactUsView.h"

@interface JZContactUsViewController () <JZContactUsViewDelegate>

@property (nonatomic, strong) JZContactUsView *contactUsView;

@end

@implementation JZContactUsViewController

- (JZContactUsView *)contactUsView
{
    if (!_contactUsView) {
        _contactUsView = [[JZContactUsView alloc] initWithFrame:self.view.bounds];
        _contactUsView.delegate = self;

    }
    return _contactUsView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.contactUsView];
}

#pragma mark JZContactUsView Methods
- (void)contactUsView:(JZContactUsView *)contactUsView didSelectRowAtIndex:(NSIndexPath *)indexPath
{
    NSLog(@"indexPath.row = %ld", (long)indexPath.row);
    [contactUsView.tbView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
