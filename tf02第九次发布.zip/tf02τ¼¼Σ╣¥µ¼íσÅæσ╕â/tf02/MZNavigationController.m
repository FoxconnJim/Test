//
//  MZNavigationController.m
//  tf02
//
//  Created by Mokyz on 16/9/21.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "MZNavigationController.h"
#import "Utility.h"

@interface MZNavigationController () <UIGestureRecognizerDelegate>

@end

@implementation MZNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationBar.barStyle = UIBarStyleBlack;
    self.navigationBar.translucent = NO;
    self.navigationBar.barTintColor = barBackgroundColor;
    self.navigationBar.tintColor = [UIColor whiteColor];
//    UIImage *barBGImage = [self cutImage:[UIImage imageNamed:@"barBGImage"]];
//    [self.navigationBar setBackgroundImage:barBGImage forBarMetrics:UIBarMetricsDefault];

    self.interactivePopGestureRecognizer.delegate = self;

    [self.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationBar setShadowImage:[UIImage new]];
}

#pragma mark 裁剪图片
- (UIImage *)cutImage:(UIImage *)image
{
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], CGRectMake(0, 0, screenW, 64));
    return [UIImage imageWithCGImage:imageRef];
}

@end






























 
