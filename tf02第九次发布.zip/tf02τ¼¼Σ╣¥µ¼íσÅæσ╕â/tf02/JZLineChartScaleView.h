//
//  JZLineChartScaleView.h
//  tf02
//
//  Created by AN PEN on 4/7/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZSegment.h"
#import "JZTime.h"
#import "JZTimeView.h"

@interface JZLineChartScaleView : UIView

@property (nonatomic, strong) JZSegment *segment;
@property (nonatomic, copy) NSString *timeLengthString;

@property (nonatomic, strong) NSMutableArray *textArray;

@property (nonatomic, assign) CGFloat jzScale;
@property (nonatomic, strong) JZTimeView *timeView;
@property (nonatomic, strong) JZTime *jzTime;

- (void)jzSetNeedsDisplay;

@end
