//
//  JZHomePageIconView.h
//  tf02
//
//  Created by F7686324 on 15/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZHomePageIconView : UIView

@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *lbl;
@property (nonatomic, strong) UIButton *btn;
@property (nonatomic, strong) UIImageView *tickView;
@property (nonatomic) BOOL isSelected;

@end
