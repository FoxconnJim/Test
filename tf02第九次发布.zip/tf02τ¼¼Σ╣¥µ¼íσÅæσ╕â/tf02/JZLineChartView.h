//
//  JZLineChartView.h
//  tf02
//
//  Created by Jim on 16/3/18.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZLineChartFrame.h"
#import "JZLineChartDataView.h"
//#import "JZLineChartScaleView.h"
//#import "JZPadScaleView.h"
#import "JZPadScaleView2017.h"
#import "JZBackgroundLayer.h"
#import "JZData.h"
#import "JZIndicatorView.h"
#import "NSString+JZGetStringWidth.h"
#import "JZFmdbTool.h"

@class JZLineChartView;
@protocol JZLineChartViewDelegate <NSObject>

@optional
- (void)handleSingleTapGesture:(UITapGestureRecognizer *)tap lineChartView:(JZLineChartView *)lineChartView;

@required
- (void)endMJRefreshWithLineChartView:(JZLineChartView *)lineChartView;

@end

@interface JZLineChartView : UIView

@property (nonatomic, strong) JZLineChartFrame *lineChartFrame;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *valueLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIView *topLine;
@property (nonatomic, strong) UIView *bottomLine;
@property (nonatomic, strong) UILabel *maxValue;
@property (nonatomic, strong) UILabel *minValue;
@property (nonatomic, strong) UILabel *indicatorLabel;

@property (nonatomic, strong) JZBackgroundLayer *backgroundLayer;
@property (nonatomic, strong) JZLineChartDataView *dataView;
@property (nonatomic, strong) UIScrollView *scrollView;
//@property (nonatomic, strong) JZLineChartScaleView *scaleView;
//@property (nonatomic, strong) JZPadScaleView *padScaleView;
@property (nonatomic, strong) JZPadScaleView2017 *padScaleView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *bigDataArray;
@property (nonatomic, strong) NSMutableArray *textArray;

@property (nonatomic, strong) UIView *lineView;

@property (nonatomic, strong) UIColor *colorOne;
@property (nonatomic, strong) UIColor *colorTwo;

@property (nonatomic, assign) CGFloat previousDistance;
@property (nonatomic, assign) CGFloat jzScale;
@property (nonatomic, copy) NSString *jzType;

@property (nonatomic, strong) UIPinchGestureRecognizer *pinchGesture;
@property (nonatomic, strong) UIPanGestureRecognizer *panGesture;
@property (nonatomic, strong) UITapGestureRecognizer *singleTapGesture;
@property (nonatomic, strong) UITapGestureRecognizer *doubleTapGesture;

@property (nonatomic, strong) JZIndicatorView *indicatorView;
@property (nonatomic, weak) id <JZLineChartViewDelegate> delegate;

- (void)initTimeAndValueWithType:(NSString *)jzType;
- (NSMutableDictionary *)paramWithTimeLengthString:(NSString *)timeLengthString;

@end
