//
//  JZLoginView.h
//  tf02
//
//  Created by Jim on 16/3/9.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZCustomField.h"
#import "JZLoginFrame.h"
#import "JZpromptLabel.h"
#import "JZrememberPasswordView.h"

@interface JZLoginView : UIView

@property (nonatomic, strong) JZLoginFrame *loginFrame;
@property (nonatomic, strong) UIImageView *backgroundImageView;
@property (nonatomic, strong) UIImageView *logoImageView;
@property (nonatomic, strong) UILabel *userLabel;
@property (nonatomic, strong) JZCustomField *userTF;
@property (nonatomic, strong) UILabel *passwordLabel;
@property (nonatomic, strong) JZCustomField *passwordTF;
@property (nonatomic, strong) UIButton *loginBtn;
@property (nonatomic, strong) UIButton *forgetPasswordBtn;
@property (nonatomic, strong) JZpromptLabel *promptLabel;
@property (nonatomic, strong) UIView *leftLineView;
@property (nonatomic, strong) UIView *rightLineView;
@property (nonatomic, strong) UILabel *otherLoginWayLabel;
@property (nonatomic, strong) UIButton *visitorsBtn;
@property (nonatomic, strong) UILabel *visitorLabel;
@property (nonatomic, strong) JZrememberPasswordView *rememberPasswordView;
@end
