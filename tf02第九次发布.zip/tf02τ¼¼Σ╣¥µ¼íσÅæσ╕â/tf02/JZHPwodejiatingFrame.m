//
//  JZHPwodejiatingFrame.m
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHPwodejiatingFrame.h"

@implementation JZHPwodejiatingFrame

- (instancetype)init
{
    self = [super init];
    if (self) {
        CGFloat margin = 10;
        CGFloat imgLength = 60;
        CGFloat labelHeight = imgLength / 2;

        CGFloat bgViewX = screenEdgeMargin;
        CGFloat bgViewY = 0;
        CGFloat bgViewW = screenW - bgViewX * 2;
        CGFloat bgViewH = margin * 2 + imgLength;
        self.bgViewFrame = CGRectMake(bgViewX, bgViewY, bgViewW, bgViewH);

        CGFloat imgX = margin;
        CGFloat imgY = margin;
        CGFloat imgW = imgLength;
        CGFloat imgH = imgLength;
        self.imgViewFrame = CGRectMake(imgX, imgY, imgW, imgH);

        CGFloat upLabelX = imgX + imgW + margin;
        CGFloat upLabelY = imgY;
        CGFloat upLabelW = bgViewW - upLabelX;
        CGFloat upLabelH = labelHeight;
        self.upLabelFrame = CGRectMake(upLabelX, upLabelY, upLabelW, upLabelH);

        CGFloat downLabelX = upLabelX;
        CGFloat downLabelY = upLabelY + upLabelH;
        CGFloat downLabelW = upLabelW;
        CGFloat downLabelH = labelHeight;
        self.downLabelFrame = CGRectMake(downLabelX, downLabelY, downLabelW, downLabelH);

        CGFloat arrowW = 10;
        CGFloat arrowH = 15;
        CGFloat arrowX = bgViewW - arrowW - 10;
        CGFloat arrowY = (bgViewH - arrowH) / 2;

        self.arrowFrame = CGRectMake(arrowX, arrowY, arrowW, arrowH);

        self.cellHeight = bgViewY * 2 + bgViewH;
        
    }
    return self;
}

@end
