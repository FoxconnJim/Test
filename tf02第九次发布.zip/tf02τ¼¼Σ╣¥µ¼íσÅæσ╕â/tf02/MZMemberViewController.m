//
//  MZMemberViewController.m
//  tf02
//
//  Created by Mokyz on 16/10/5.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "MZMemberViewController.h"
#import "UIView+MZAdd.h"
#import "Utility.h"
#import "UIButton+WebCache.h"

#define MZMemberInfoCount 16
static NSString *const cellId = @"MZMemberCell";

@interface MZMemberViewController ()
{
    NSDictionary *_items;
    UIButton *_headIcon;
}

@end

@implementation MZMemberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //     self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"成员信息";
    
    _items = @{@"Title" : @[@"昵称",
                            @"身份证号",
                            @"姓名",
                            @"电话号码",
                            @"性别",
                            @"身高",
                            @"血型",
                            @"出生年月",
                            @"婚姻",
                            @"职业",
                            @"社保卡",
                            @"居住地",
                            @"详细地址",
                            @"过敏史",
                            @"家族史",
                            @"过往史"],
               @"Property" : @[@"nickname",
                               @"idCard",
                               @"membersname",
                               @"tel",
                               @"sex",
                               @"height",
                               @"bloodType",
                               @"birthday",
                               @"marryStatus",
                               @"job",
                               @"socialCard",
                               @"home",
                               @"address",
                               @"allergic",
                               @"family",
                               @"history"
                               ]
               };
    
    [self setUpHeaderAndFooterView];
}

- (void)setUpHeaderAndFooterView
{
    // header
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.mz_width, 100)];
    
    UIButton *headIcon = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 70, 70)];
    [headIcon sd_setImageWithURL:[NSURL URLWithString:self.personInfo.picture] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"默认"]];
    headIcon.layer.cornerRadius = 70 * 0.5;
    headIcon.layer.masksToBounds = YES;
    headIcon.center = headerView.center;
    [headerView addSubview:headIcon];
    _headIcon = headIcon;

    headerView.backgroundColor = appBackgroundColor;
    self.tableView.tableHeaderView = headerView;
    
    // footer
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.mz_width, 60)];
    footerView.backgroundColor = appBackgroundColor;
    
    UIButton *deletBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, self.view.mz_width * 0.75, 35)];
    deletBtn.backgroundColor = [UIColor colorWithRed:246/255.f green:108/255.f blue:125/255.f alpha:1];
    [deletBtn setTitle:@"删除成员" forState:UIControlStateNormal];
    deletBtn.layer.cornerRadius = 35 * 0.5;
    deletBtn.center = footerView.center;
    [footerView addSubview:deletBtn];
    
//    self.tableView.tableFooterView = footerView;
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return MZMemberInfoCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellId];
    }
    
    cell.textLabel.text = _items[@"Title"][indexPath.row];
    cell.detailTextLabel.text = [self.personInfo valueForKey:_items[@"Property"][indexPath.row]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
