//
//  JZLineChartDataView.m
//  tf02
//
//  Created by F7686324 on 10/13/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZLineChartDataView.h"

@implementation JZLineChartDataView
@synthesize maxValue;
@synthesize minValue;

- (NSMutableArray *)bigPointArray
{
    if (!_bigPointArray) {
        _bigPointArray = [NSMutableArray array];
    }
    return _bigPointArray;
}


- (NSMutableArray *)minArray
{
    if (!_minArray) {
        _minArray = [NSMutableArray array];
    }
    return _minArray;
}

- (NSMutableArray *)maxArray
{
    if (!_maxArray) {
        _maxArray = [NSMutableArray array];
    }
    return _maxArray;
}

- (JZLineChartDataLayer *)dataLayer1
{
    if (!_dataLayer1) {
        _dataLayer1 = [[JZLineChartDataLayer alloc] initWithFrame:self.bounds];
    }
    return _dataLayer1;
}

- (JZLineChartDataLayer *)dataLayer2
{
    if (!_dataLayer2) {
        _dataLayer2 = [[JZLineChartDataLayer alloc] initWithFrame:self.bounds];
    }
    return _dataLayer2;
}

- (void)setColorArray:(NSArray *)colorArray
{
    _colorArray = colorArray;
}

- (void)setBigDataArray:(NSArray *)bigDataArray
{
    _bigDataArray = bigDataArray;
    maxValue = -MAXFLOAT;
    minValue = MAXFLOAT;
    [self.minArray removeAllObjects];
    [self.maxArray removeAllObjects];
    for (NSMutableArray *dataArray in bigDataArray) {
        for (JZPoint *point in dataArray) {
            if (point.y > maxValue) {
                maxValue = point.y;
            }
            if (point.y < minValue) {
                minValue = point.y;
            }
        }
        [self.minArray addObject:[NSNumber numberWithFloat:minValue]];
        [self.maxArray addObject:[NSNumber numberWithFloat:maxValue]];
    }
    [self.bigPointArray removeAllObjects];
    if (maxValue == minValue) {
        for (NSMutableArray *dataArray in bigDataArray) {
            NSMutableArray *pointArray = [NSMutableArray array];
            for (JZPoint *point in dataArray) {
                CGFloat x = point.x;
                CGFloat y = 0.5f;
                JZPoint *jzpoint = [JZPoint pointWithX:x y:y];
                [pointArray addObject:jzpoint];
            }
            [self.bigPointArray addObject:pointArray];
        }
    } else {
        for (int i = 0; i < bigDataArray.count; i++) {
            NSMutableArray *pointArray = [NSMutableArray array];
            NSMutableArray *dataArray = bigDataArray[i];
            for (JZPoint *point in dataArray) {
                CGFloat x = point.x;
                CGFloat y = 1 - (point.y - minValue) / (maxValue - minValue);
                JZPoint *jzpoint = [JZPoint pointWithX:x y:y];
                [pointArray addObject:jzpoint];
            }
            [self.bigPointArray addObject:pointArray];
        }
    }


    //Animate path
    CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    pathAnimation.duration = 0.3f;
    pathAnimation.fromValue = [NSNumber numberWithFloat: 0.0f];
    pathAnimation.toValue = [NSNumber numberWithFloat: 1.0f];
    [self.dataLayer1 removeFromSuperlayer];
    [self.dataLayer2 removeFromSuperlayer];
    for (int i = 0; i < self.bigPointArray.count; i++) {
        if (i == 0) {
            self.dataLayer1.pointArray = [self.bigPointArray firstObject];
            [self.dataLayer1 addAnimation:pathAnimation forKey:nil];
            [self.layer addSublayer:self.dataLayer1];
        } else if (i == 1) {
            self.dataLayer2.pointArray = [self.bigPointArray lastObject];
            self.dataLayer2.strokeColor = [UIColor greenColor].CGColor;
            [self.dataLayer2 addAnimation:pathAnimation forKey:nil];
            [self.layer addSublayer:self.dataLayer2];
        }
    }
}

- (void)setJzScale:(CGFloat)jzScale
{
    _jzScale = jzScale;
    [self jzSetNeedsDisplay];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.jzScale = 1.f;
//        CAGradientLayer *gradient = [CAGradientLayer layer];
//        gradient.frame = self.bounds;
//        gradient.colors = [NSArray arrayWithObjects:(id)[UIColor colorWithWhite:1 alpha:0.8].CGColor, (id)[UIColor colorWithWhite:1 alpha:0.5], nil];
//        [self.layer insertSublayer:gradient atIndex:0];
    }
    return self;
}

- (void)jzSetNeedsDisplay
{

    [self.dataLayer1 removeFromSuperlayer];
    [self.dataLayer2 removeFromSuperlayer];
    for (int i = 0; i < self.bigPointArray.count; i++) {
        if (i == 0) {
            self.dataLayer1.jzLayerScale = self.jzScale;
            self.dataLayer1.pointArray = self.bigPointArray[i];
            [self.layer addSublayer:self.dataLayer1];
        } else if (i == 1) {
            self.dataLayer2.jzLayerScale = self.jzScale;
            self.dataLayer2.pointArray = self.bigPointArray[i];
            self.dataLayer2.strokeColor = [UIColor greenColor].CGColor;
            [self.layer addSublayer:self.dataLayer2];
        }

    }
    CGRect frame = self.frame;
    CGFloat margin = 5;
    frame.size.width = (screenW - screenEdgeMargin * 2 - margin * 2) * self.jzScale;
    self.frame = frame;
}


@end
