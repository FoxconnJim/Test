//
//  JZGetCaptchaViewController.h
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZGetCaptchaViewController : UIViewController

@end
