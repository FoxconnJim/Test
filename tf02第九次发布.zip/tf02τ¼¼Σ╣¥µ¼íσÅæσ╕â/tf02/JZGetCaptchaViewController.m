//
//  JZGetCaptchaViewController.m
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZGetCaptchaViewController.h"
#import "JZGetCaptchaView.h"
#import "JZOperation.h"
#import <MessageUI/MessageUI.h>
#import "JZLoginViewController.h"
#import "JZModifyPasswordViewController.h"

#import <SMS_SDK/SMSSDK.h>
#import "LCProgressHUD.h"


@interface JZGetCaptchaViewController () <JZOperationDelegate>
{
    NSInteger number;
}

@property (nonatomic, strong) JZGetCaptchaView *getCaptchaView;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) JZModifyPasswordViewController *modifyPasswordVC;

@end

@implementation JZGetCaptchaViewController

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (JZGetCaptchaView *)getCaptchaView
{
    if (!_getCaptchaView) {
        _getCaptchaView = [[JZGetCaptchaView alloc] initWithFrame:self.view.bounds];
        _getCaptchaView.title.text = @"别担心，马上找回";
        _getCaptchaView.upLabel.text = @"手机号码:";
        _getCaptchaView.upSublabel.text = @"请输入绑定手机号码";
        _getCaptchaView.upField.text = @"";

        _getCaptchaView.downLabel.text = @"验证码:";
        _getCaptchaView.downSublabel.text = @"请输入验证码";
        _getCaptchaView.downField.text = @"";
        _getCaptchaView.downField.enabled = NO;

        [_getCaptchaView.captchaBtn addTarget:self action:@selector(getCaptcha) forControlEvents:UIControlEventTouchUpInside];
        [_getCaptchaView.foundBackBtn setTitle:@"找回" forState:UIControlStateNormal];
        [_getCaptchaView.foundBackBtn addTarget:self action:@selector(clickToFoundbackPassword) forControlEvents:UIControlEventTouchUpInside];
        [_getCaptchaView.upField addTarget:self action:@selector(inputAction:) forControlEvents:UIControlEventEditingChanged];
        [_getCaptchaView.backBtn addTarget:self action:@selector(clickBackToHome) forControlEvents:UIControlEventTouchUpInside];
    }
    return _getCaptchaView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.getCaptchaView];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
    NSLog(@"viewWillDisappear");
}



- (void)clickToFoundbackPassword
{
    NSLog(@"clickToFoundBackPassword");

    [self.getCaptchaView.upField resignFirstResponder];
    [self.getCaptchaView.downField resignFirstResponder];
    [SMSSDK commitVerificationCode:self.getCaptchaView.downField.text phoneNumber:self.getCaptchaView.upField.text zone:@"86" result:^(SMSSDKUserInfo *userInfo, NSError *error) {
        {
            NSLog(@"userInfo.phone = %@", userInfo.phone);
            NSLog(@"userInfo.avatar = %@", userInfo.avatar);
            NSLog(@"userInfo.nickname = %@", userInfo.nickname);
            NSLog(@"userInfo.zone = %@", userInfo.zone);
            NSLog(@"userInfo.uid = %@", userInfo.uid);
            if (!error)
            {
                NSLog(@"验证成功");
                _modifyPasswordVC = [[JZModifyPasswordViewController alloc] init];
                _modifyPasswordVC.account = self.getCaptchaView.upField.text;
                [self presentViewController:_modifyPasswordVC animated:YES completion:nil];
            } else {
                NSLog(@"错误信息:%@",error);
                NSLog(@"error.userInfo = %@", error.userInfo[@"commitVerificationCode"]);
                [LCProgressHUD showInfoMsg:error.userInfo[@"commitVerificationCode"]];
                if (error.code == 467) {
                    [self endTimer];
                }
            }
        }
    }];
}

- (void)inputAction:(JZCustomField *)textField
{
    NSLog(@"%s", __FUNCTION__);
    if ([self.getCaptchaView.captchaBtn.titleLabel.text isEqualToString:@"点击获取"]) {
        NSLog(@"%s", __FUNCTION__);
        if (textField.text.length == 11) {
            NSLog(@"号码长度正确");
            NSMutableDictionary *param = [NSMutableDictionary dictionary];
            param[@"tel"] = self.getCaptchaView.upField.text;
            JZOperation *operation = [JZOperation operationWithURLString:familyaccountbytelURL andParam:param getOrPost:JZ_GET];
            operation.name = familyaccountbytelOperation;
            operation.delegate = self;

        } else {
            NSLog(@"号码长度不正确");

            self.getCaptchaView.captchaBtn.enabled = NO;
            [self.getCaptchaView.captchaBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        }
    }

}

- (void)clickBackToHome
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"确认返回上一级?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

#pragma mark JZOperationDelegate Methods

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [LCProgressHUD showFailure:@"网络有点卡..."];

    }
}

- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    if ([responseObject[@"code"] integerValue] == 1) { //已注册
        self.getCaptchaView.captchaBtn.enabled = YES;
        [self.getCaptchaView.captchaBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

    } else if ([responseObject[@"code"] integerValue] == 2) {
        [LCProgressHUD showInfoMsg:@"抱歉，该手机号未注册"];
    } else if ([responseObject[@"code"] integerValue] == 3) {
        [LCProgressHUD showInfoMsg:@"抱歉，服务器异常"];
    }
}

- (void)getCaptcha
{
    NSLog(@"getCaptcha");

    [self startTimer];
    NSLog(@"tel:%@", self.getCaptchaView.upField.text);
    [SMSSDK getVerificationCodeByMethod:SMSGetCodeMethodSMS phoneNumber: self.getCaptchaView.upField.text
                                   zone:@"86"
                       customIdentifier:nil
                                 result:^(NSError *error){
                                     if (!error) {
                                         NSLog(@"获取验证码成功");
                                         [LCProgressHUD showSuccess:@"获取验证码成功"];
                                         self.getCaptchaView.downField.enabled = YES;

                                     } else {
                                         NSLog(@"获取验证码错误信息：%@",error);
                                         NSLog(@"error.code = %ld", (long)error.code);
                                         NSLog(@"error.userInfo = %@", error.userInfo[@"getVerificationCode"]);
                                         [LCProgressHUD showInfoMsg:error.userInfo[@"getVerificationCode"]];
                                         [self endTimer];
                                         self.getCaptchaView.upField.enabled = YES;

                                     }
                                 }];

}

- (void)startTimer
{
    [self.getCaptchaView.upField resignFirstResponder];
    [self.getCaptchaView.downField resignFirstResponder];

    self.getCaptchaView.upField.textColor = [UIColor colorWithWhite:1 alpha:0.7];
    self.getCaptchaView.upField.enabled = NO;

    self.getCaptchaView.captchaBtn.titleLabel.adjustsFontSizeToFitWidth = YES;
    [self.getCaptchaView.captchaBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

    number = 60;
    [self repeatAction];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(repeatAction) userInfo:nil repeats:YES];
}

- (void)repeatAction
{
    NSLog(@"number = %ld", (long)number);
    if (number >= 0) {
        [self.getCaptchaView.captchaBtn.titleLabel setAdjustsFontSizeToFitWidth:YES];

        [self.getCaptchaView.captchaBtn setTitle:[NSString stringWithFormat:@"剩余(%ld)秒", (long)number] forState:UIControlStateNormal];
        self.getCaptchaView.captchaBtn.enabled = NO;
    } else {
        [self endTimer];
    }
    number--;
}

- (void)endTimer
{
    [self.timer invalidate];
    [self.getCaptchaView.captchaBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.getCaptchaView.captchaBtn setTitle:@"点击获取" forState:UIControlStateNormal];
    self.getCaptchaView.captchaBtn.enabled = YES;
    self.getCaptchaView.upField.textColor = [UIColor whiteColor];
}

@end
