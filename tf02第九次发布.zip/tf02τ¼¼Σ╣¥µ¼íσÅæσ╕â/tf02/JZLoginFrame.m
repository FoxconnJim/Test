//
//  JZLoginFrame.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZLoginFrame.h"
#import "Utility.h"

@implementation JZLoginFrame


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        CGFloat margin = 15;
        CGFloat imageViewW = screenW / 4;
        CGFloat imageViewH = imageViewW;
        CGFloat imageViewX = (screenW - imageViewW) / 2;
        CGFloat imageViewY = screenH / 8;
        self.imageViewFrame = CGRectMake(imageViewX, imageViewY, imageViewW, imageViewH);

        CGFloat userLabelX = screenW / 7;
        CGFloat userLabelY = imageViewY + imageViewH + margin * 2;
        CGFloat userLabelW = screenW / 7;
        CGFloat userLabelH = 30;
        
        self.userLabelFrame = CGRectMake(userLabelX, userLabelY, userLabelW, userLabelH);
        
        CGFloat userTFX = userLabelX + userLabelW;
        CGFloat userTFY = userLabelY;
        CGFloat userTFW = screenW * 4 / 7;
        CGFloat userTFH = userLabelH;
        
        self.userTFFrame = CGRectMake(userTFX, userTFY, userTFW, userTFH);
        
        CGFloat passwordLabelX = userLabelX;
        CGFloat passwordLabelY = userLabelY + userLabelH + margin;
        CGFloat passwordLabelW = userLabelW;
        CGFloat passwordLabelH = userLabelH;
        
        self.passwordLabelFrame = CGRectMake(passwordLabelX, passwordLabelY, passwordLabelW, passwordLabelH);
        
        CGFloat passwordTFX = passwordLabelX + passwordLabelW;
        CGFloat passwordTFY = passwordLabelY;
        CGFloat passwordTFW = userTFW;
        CGFloat passwordTFH = userLabelH;
        
        self.passwordTFFrame = CGRectMake(passwordTFX, passwordTFY, passwordTFW, passwordTFH);
        
        CGFloat loginBtnX = userLabelX;
        CGFloat loginBtnY = passwordLabelY + passwordLabelH + margin * 2;
        CGFloat loginBtnW = screenW * 2 / 7;
        CGFloat loginBtnH = 40;
        
        self.loginBtnFrame = CGRectMake(loginBtnX, loginBtnY, loginBtnW, loginBtnH);
        
        CGFloat forgetPasswordBtnX = userLabelX;
        CGFloat forgetPasswordBtnY = loginBtnY + loginBtnH + margin;
        CGFloat forgetPasswordBtnW = 60;
        CGFloat forgetPasswordBtnH = 30;
        
        self.forgetPasswordBtnFrame = CGRectMake(forgetPasswordBtnX, forgetPasswordBtnY, forgetPasswordBtnW, forgetPasswordBtnH);

        CGFloat registerBtnW = forgetPasswordBtnW;
        CGFloat registerBtnH = forgetPasswordBtnH;
        CGFloat registerBtnY = forgetPasswordBtnY;
        CGFloat registerBtnX = passwordTFX + passwordTFW - registerBtnW;
        self.registerFrame = CGRectMake(registerBtnX, registerBtnY, registerBtnW, registerBtnH);

        self.marginFrame = CGRectMake(0, 0, 5, 0);

        CGFloat promptW = screenW / 2;
        CGFloat promptH = 30;
        CGFloat promptX = (screenW - promptW) / 2;
        CGFloat promptY = forgetPasswordBtnY + forgetPasswordBtnH + margin;
        self.promptFrame = CGRectMake(promptX, promptY, promptW, promptH);

        CGFloat otherLoginWayW = 100;
        CGFloat otherLoginWayH = 20;
        CGFloat otherLoginWayX = (screenW - otherLoginWayW) / 2;
        CGFloat otherLoginWayY = screenH - 120;
        self.otherLoginWayFrame = CGRectMake(otherLoginWayX, otherLoginWayY, otherLoginWayW, otherLoginWayH);

        CGFloat leftLineX = 20;
        CGFloat leftLineW = (screenW - leftLineX * 2 - otherLoginWayW) / 2;
        CGFloat leftLineH = 1;
        CGFloat leftLineY = otherLoginWayY + otherLoginWayH / 2 - leftLineH / 2;
        self.leftLineFrame = CGRectMake(leftLineX, leftLineY, leftLineW, leftLineH);

        CGFloat rightLineX = otherLoginWayX + otherLoginWayW;
        CGFloat rightLineY = leftLineY;
        CGFloat rightLineW = leftLineW;
        CGFloat rightLineH = leftLineH;
        self.rightLineFrame = CGRectMake(rightLineX, rightLineY, rightLineW, rightLineH);

        CGFloat visitorsImageW = 50;
        CGFloat visitorsImageH = 50;
        CGFloat visitorsImageX = (screenW - visitorsImageW) / 2;
        CGFloat visitorsImageY = otherLoginWayY + otherLoginWayH + 10;
        self.visitorsImageFrame = CGRectMake(visitorsImageX, visitorsImageY, visitorsImageW, visitorsImageH);

        CGFloat visitorsX = visitorsImageX;
        CGFloat visitorsY = visitorsImageY + visitorsImageH + 10;
        CGFloat visitorsW = visitorsImageW;
        CGFloat visitorsH = otherLoginWayH;
        self.visitorFrame = CGRectMake(visitorsX, visitorsY, visitorsW, visitorsH);

        CGFloat rememberPasswordW = 80;
        CGFloat rememberPasswordH = 17;
        CGFloat rememberPasswordX = passwordTFX + passwordTFW - rememberPasswordW;
        CGFloat rememberPasswordY = loginBtnY;
        self.rememberPasswordFrame = CGRectMake(rememberPasswordX, rememberPasswordY, rememberPasswordW, rememberPasswordH);
        
    }
    return self;
}

@end
