//
//  JZguanggaoViewController.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZguanggaoViewController.h"
#import "JZh5View.h"

@interface JZguanggaoViewController ()

@property (nonatomic, strong) JZh5View *h5View;

@end

@implementation JZguanggaoViewController

- (JZh5View *)h5View
{
    if (!_h5View) {
        _h5View = [[JZh5View alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight)];
    }
    return _h5View;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.h5View.urlString = self.urlString;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"广告";
    [self.view addSubview: self.h5View];

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.h5View.urlString = self.urlString;

}

- (void)setUrlString:(NSString *)urlString
{
    _urlString = urlString;

}

@end
