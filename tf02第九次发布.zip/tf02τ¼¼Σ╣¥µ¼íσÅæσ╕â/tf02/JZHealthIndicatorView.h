//
//  JZHealthIndicatorView.h
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZHealthIndicatorFrame.h"
#import "JZBloodPressureView.h"
#import "JZHeartRateView.h"
#import "JZBloodSugarView.h"
#import "JZBodyFatView.h"
#import "JZOxygenView.h"
#import "JZWeightView.h"

@interface JZHealthIndicatorView : UIView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) JZHealthIndicatorFrame *healthIndicatorFrame;
@property (nonatomic, strong) UISegmentedControl *segmentControl;
@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) JZBloodPressureView *bloodPressureView;
@property (nonatomic, strong) JZHeartRateView *heartRateView;
@property (nonatomic, strong) JZBloodSugarView *bloodSugarView;
@property (nonatomic, strong) JZBodyFatView *bloodFatView;
@property (nonatomic, strong) JZOxygenView *oxygenView;
@property (nonatomic, strong) JZWeightView *weightView;
@property (nonatomic, strong) NSMutableArray *items;
@property (nonatomic, strong) NSMutableArray *viewItems;
@property (nonatomic, copy) NSString *timeLengthString;
@property (nonatomic, strong) UILongPressGestureRecognizer *longPressGesture;


@end












