//
//  JZSelectWeekDayView.m
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZSelectWeekDayView.h"
#import "Utility.h"

@implementation JZSelectWeekDayView

- (NSMutableArray *)btnArray
{
    if (!_btnArray) {
        _btnArray = [NSMutableArray array];
    }
    return _btnArray;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CGFloat jzWidth = 35;
        CGFloat jzMargin = (screenW - jzWidth * 7) / 8;

        NSArray *dataArray = @[@"一", @"二", @"三", @"四", @"五", @"六", @"日"];

        for (int i = 0; i < 7; i++) {
            NSString *str = dataArray[i];
            UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(jzMargin + i * (jzWidth + jzMargin), 3.5, jzWidth, jzWidth)];
            [btn setTitle:str forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            btn.backgroundColor = [UIColor whiteColor];
            btn.layer.cornerRadius = jzWidth / 2;
            btn.layer.masksToBounds = YES;
            btn.backgroundColor = appBackgroundColor;
            btn.tag = i;
            [self addSubview:btn];
            [self.btnArray addObject:btn];
        }
        return self;
    }
    return self;
}

@end
