//
//  JZTime.h
//  tf02
//
//  Created by F7686324 on 15/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utility.h"

@interface JZTime : NSObject

@property (nonatomic, strong) NSMutableArray *dayArray;
@property (nonatomic, strong) NSMutableArray *weekArray;
@property (nonatomic, strong) NSMutableArray *monthArray;
@property (nonatomic, strong) NSMutableArray *yearArray;

@end
