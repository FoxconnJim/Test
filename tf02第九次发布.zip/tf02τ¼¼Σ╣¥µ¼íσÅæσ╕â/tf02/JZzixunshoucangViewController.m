//
//  JZzixunshoucangViewController.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZzixunshoucangViewController.h"
#import "Utility.h"
#import "JZOperation.h"
#import "JZHotNews.h"
#import "JZNewsCell.h"
#import "JZyishoucangViewController.h"
#import "MJRefresh.h"

@interface JZzixunshoucangViewController () <UITableViewDelegate, UITableViewDataSource, JZOperationDelegate, UIViewControllerPreviewingDelegate>

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) NSMutableArray *hotNewsArray;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) JZyishoucangViewController *yscVC;
@property (nonatomic, strong) UILabel *lbl;

@end

@implementation JZzixunshoucangViewController

- (NSOperationQueue *)queue {
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (UILabel *)lbl
{
    if (!_lbl) {
        _lbl = [[UILabel alloc] initWithFrame: CGRectMake(0, 0, screenW, screenH - statusBarHeight - naviHeight)];
        _lbl.text = @"暂无资讯~";
        _lbl.textColor = [UIColor grayColor];
        _lbl.textAlignment = NSTextAlignmentCenter;
        _lbl.backgroundColor = [UIColor whiteColor];
    }
    return _lbl;
}

- (NSMutableArray *)hotNewsArray
{
    if (!_hotNewsArray) {
        _hotNewsArray = [NSMutableArray array];
    }
    return _hotNewsArray;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame: CGRectMake(0, 0, screenW, screenH - statusBarHeight - naviHeight)];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tbView.showsVerticalScrollIndicator = NO;
        _tbView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tbView addSubview:self.lbl];
    }
    return _tbView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"资讯收藏";
    self.view.backgroundColor = appBackgroundColor;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCollectedNews) name:cancelshoucangNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCollectedNews) name:shoucangNotification object:nil];

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.view addSubview: self.tbView];
    self.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock: ^{
        [self getCollectedNews];
    }];

    JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];

    if (refreshInfo.canCollectionNewsRefresh) {
        [self.tbView.mj_header beginRefreshing];
        refreshInfo.canCollectionNewsRefresh = NO;
        [refreshInfo storeValueByKey:kRefreshInfo];
    } else {
        [self getCollectedNews];
    }

}

- (void)getCollectedNews
{
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"tel"] = [[JZFamilyInfo valueByKey: kFamilyInfo] tel];
    JZOperation *operation = [JZOperation operationWithURLString:loadshoucangURL andParam:param getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = loadshoucangOperation;
}

#pragma mark -UITableViewDataSource Methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.hotNewsArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
    JZNewsCell *cell = [JZNewsCell cellWithTableView:tableView];
    cell.hotNews = hotNews;
    [cell.imgView sd_setImageWithURL:[NSURL URLWithString:[hotNews newsFront]] placeholderImage:[UIImage imageNamed:@"资讯"]];
    if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
        [self registerForPreviewingWithDelegate:self sourceView:cell];
    }
    return cell;
}

#pragma mark UITableViewDelegate mehtods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView reloadRowsAtIndexPaths: [NSArray arrayWithObject: indexPath] withRowAnimation:UITableViewRowAnimationNone];
    JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
    _yscVC = [[JZyishoucangViewController alloc] init];
    _yscVC.hotNews = hotNews;
    [self.navigationController pushViewController: _yscVC animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return newsRowHeight;
}

#pragma mark -JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject {

    NSArray *arr = (NSArray *)responseObject[@"data"];
    [self.hotNewsArray removeAllObjects];

    if ([arr isKindOfClass:[NSArray class]]) {

        for (NSDictionary *dict in arr) {

            JZHotNews *hotNews = [JZHotNews hotNewsWithDictionary: dict];
            [self.hotNewsArray addObject: hotNews];
        }
        [self.tbView reloadData];
        [self.lbl removeFromSuperview];
        self.tbView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    } else {

        [self.tbView addSubview: self.lbl];
    }


    [self.tbView.mj_header endRefreshing];

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error {
    [self.tbView.mj_header endRefreshing];

}

#pragma mark UIViewControllerPreviewingDelegate Methods
//peek(预览)
- (nullable UIViewController *)previewingContext:(id<UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location
{
    //获取按压的cell所在行， [previewingContext sourceView]就是按压的那个视图
    NSIndexPath *indexPath = [self.tbView indexPathForCell:(UITableViewCell *)[previewingContext sourceView]];

    //设定预览的界面
    JZyishoucangViewController *childVC = [[JZyishoucangViewController alloc] init];
    childVC.preferredContentSize = CGSizeMake(0.f, 500.f);
    childVC.title = @"今日推荐";
    JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
    childVC.hotNews = hotNews;

    //调整不被虚化的范围，按压的那个cell不被虚化（轻轻按压时周边会被虚化，再稍用力展示预览，再加力跳页至设定界面)
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, newsRowHeight);
    previewingContext.sourceRect = rect;

    //返回预览界面
    return childVC;
}

//pop (再加力进入)
- (void)previewingContext:(id<UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit
{
    [self showViewController:viewControllerToCommit sender:self];
}
@end
