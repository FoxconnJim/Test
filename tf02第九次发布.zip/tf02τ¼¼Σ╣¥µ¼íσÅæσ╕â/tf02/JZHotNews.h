//
//  JZHotNews.h
//  tf02
//
//  Created by AN PEN on 8/3/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZHotNews : NSObject

@property (nonatomic, copy) NSString *newsFront;
@property (nonatomic, copy) NSString *newsHead;
@property (nonatomic, copy) NSString *newsContent;
@property (nonatomic, copy) NSString *urlString;
@property (nonatomic, copy) NSString *ID;
@property (nonatomic, assign) NSInteger tag;
@property (nonatomic, copy) NSString *delflag;


- (instancetype)initWithDictionary: (NSDictionary *)dict;
+ (instancetype)hotNewsWithDictionary: (NSDictionary *)dict;

@end
