//
//  JZHPwodejiatingCell.m
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHPwodejiatingCell.h"

@implementation JZHPwodejiatingCell

- (JZHPwodejiatingFrame *)wdjtFrame
{
    if (!_wdjtFrame) {
        _wdjtFrame = [[JZHPwodejiatingFrame alloc] init];
    }
    return _wdjtFrame;
}

- (UIView *)bgView
{
    if (!_bgView) {
        _bgView = [[UIView alloc] initWithFrame: self.wdjtFrame.bgViewFrame];
        _bgView.backgroundColor = [UIColor whiteColor];
        _bgView.layer.cornerRadius = 5;
        _bgView.layer.masksToBounds = YES;
        [_bgView addSubview:self.imgView];
        [_bgView addSubview:self.upLabel];
        [_bgView addSubview:self.downLabel];
        [_bgView addSubview:self.arrowImgView];
    }
    return _bgView;
}

- (UILabel *)upLabel
{
    if (!_upLabel) {
        
        _upLabel = [[UILabel alloc] initWithFrame: self.wdjtFrame.upLabelFrame];

    }
    return _upLabel;
}

- (UILabel *)downLabel
{
    if (!_downLabel) {
        
        _downLabel = [[UILabel alloc] initWithFrame: self.wdjtFrame.downLabelFrame];
        _downLabel.textColor = [UIColor grayColor];
        
    }
    return _downLabel;
}

- (UIImageView *)imgView
{
    if (!_imgView) {
        
        _imgView = [[UIImageView alloc] initWithFrame: self.wdjtFrame.imgViewFrame];
        _imgView.layer.cornerRadius = self.wdjtFrame.imgViewFrame.size.height / 2;
        _imgView.layer.masksToBounds = YES;
        
    }
    return _imgView;
}

- (UIImageView *)arrowImgView
{
    if (!_arrowImgView) {
        _arrowImgView = [[UIImageView alloc] initWithFrame:self.wdjtFrame.arrowFrame];
        _arrowImgView.image = [UIImage imageNamed:@"arrow"];
    }
    return _arrowImgView;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle: style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self addSubview: self.bgView];

        self.backgroundColor = appBackgroundColor;
    }
    return self;
}

+ (instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString *cellid = @"wodeID";
    JZHPwodejiatingCell *cell = [tableView dequeueReusableCellWithIdentifier: cellid];
    if (!cell) {
        cell = [[JZHPwodejiatingCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    return cell;
}

- (void)setPersonInfo:(JZPersonInfo *)personInfo
{
    _personInfo = personInfo;
    // 获取当前时间
    NSDate *currentDate = [[NSDate date] localDate];

    NSString *locationString = [[[currentDate dateToString] componentsSeparatedByString:@" "] firstObject];

    NSArray *currentArray = [locationString componentsSeparatedByString: @"-"];
    NSInteger currentYear = [currentArray[0] integerValue];
    NSInteger currentMonth = [currentArray[1] integerValue];
    NSInteger currentDay = [currentArray[2] integerValue];
    
    NSArray *birthArray = [personInfo.birthday componentsSeparatedByString:@"-"];
    NSInteger birthYear = [birthArray[0] integerValue];
    NSInteger birthMonth = [birthArray[1] integerValue];
    NSInteger birthDay = [birthArray[2] integerValue];

    NSInteger age = 0;
    if (currentMonth < birthMonth) {
        age = currentYear - birthYear - 1;
    } else if (currentMonth > birthMonth) {
        age = currentYear - birthYear;
    } else if (currentMonth == birthMonth) {
        if (currentDay < birthDay) {
            age = currentYear - birthYear - 1;
        } else {
            age = currentYear - birthYear;
        }
    }

    self.upLabel.text = [NSString stringWithFormat:@"%@  %@  %ld岁", personInfo.nickname, personInfo.sex, (long)age];
    self.downLabel.text = [NSString stringWithFormat:@"电话: %@", personInfo.tel];
}


@end
