//
//  JZHealthDataView.h
//  tf02
//
//  Created by AN PEN on 4/6/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol JZHealthDataViewDelegate <NSObject>

@optional
- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@end


@interface JZHealthDataView : UIView <UITableViewDelegate, UITableViewDataSource>
{
    CGFloat margin;
}
@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, weak) id <JZHealthDataViewDelegate> delegate;

@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *monthArray;
@property (nonatomic, strong) NSMutableArray *detailDataArray;
@property (nonatomic, strong) NSMutableArray *selectArray;
@property (nonatomic, copy) NSString *jzType;

@end
