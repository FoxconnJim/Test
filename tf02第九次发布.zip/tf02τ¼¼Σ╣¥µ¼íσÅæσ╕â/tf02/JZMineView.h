//
//  JZMineView.h
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZMineFrame.h"
#import "JZMineTBCellView.h"

@protocol JZMineViewDelegate <NSObject>

@required
- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)didSelectIconImage;
@end

@interface JZMineView : UIView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, weak) id <JZMineViewDelegate> delegate;
@property (nonatomic, strong) JZMineFrame *mineFrame;
@property (nonatomic, strong) UIImageView *iconImg;
@property (nonatomic, strong) UILabel *iconName;
@property (nonatomic, strong) UITableView *tbView;

@end
