//
//  JZModifyPasswordView.m
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZModifyPasswordView.h"

@implementation JZModifyPasswordView


- (JZModifyPasswordFrame *)modifyPasswordFrame
{
    if (!_modifyPasswordFrame) {
        _modifyPasswordFrame = [[JZModifyPasswordFrame alloc] init];
    }
    return _modifyPasswordFrame;
}

- (UIImageView *)backgroundImageView
{
    if (!_backgroundImageView) {
        _backgroundImageView = [[UIImageView alloc] initWithFrame:self.bounds];
        _backgroundImageView.image = [UIImage imageNamed:@"loginBackgroundImage"];
    }
    return _backgroundImageView;
}


- (UILabel *)title
{
    if (!_title) {
        _title = [[UILabel alloc] initWithFrame: self.modifyPasswordFrame.titleFrame];
        _title.textColor = [UIColor whiteColor];
        _title.font = [UIFont systemFontOfSize: 25];
    }
    return _title;
}

- (UILabel *)upLabel
{
    if (!_upLabel) {
        _upLabel = [[UILabel alloc] initWithFrame: self.modifyPasswordFrame.upLabelFrame];
        _upLabel.textColor = [UIColor whiteColor];
        _upLabel.textAlignment = NSTextAlignmentRight;
    }
    return _upLabel;
}

- (JZCustomField *)upField
{
    if (!_upField) {
        _upField = [[JZCustomField alloc] initWithFrame: self.modifyPasswordFrame.upFieldFrame];
        _upField.textColor = [UIColor whiteColor];
        _upField.clearButtonMode = UITextFieldViewModeWhileEditing;
    }
    return _upField;
}

- (UILabel *)upSublabel
{
    if (!_upSublabel) {
        _upSublabel = [[UILabel alloc] initWithFrame: self.modifyPasswordFrame.upSublabelFrame];
        _upSublabel.textColor = [UIColor whiteColor];
        _upSublabel.font = [UIFont systemFontOfSize: 15];
    }
    return _upSublabel;
}

- (JZTipView *)upTipView;
{
    if (!_upTipView) {
        _upTipView = [[JZTipView alloc] initWithFrame:self.modifyPasswordFrame.upTipFrame];
//        _upTipView.layer.cornerRadius = self.modifyPasswordFrame.upTipFrame.size.height / 2;
//        _upTipView.layer.masksToBounds = YES;
    }
    return _upTipView;
}

- (UILabel *)downLabel
{
    if (!_downLabel) {
        _downLabel = [[UILabel alloc] initWithFrame: self.modifyPasswordFrame.downLabelFrame];
        _downLabel.textColor = [UIColor whiteColor];
        _downLabel.textAlignment = NSTextAlignmentRight;
    }
    return _downLabel;
}

- (JZCustomField *)downField
{
    if (!_downField) {
        _downField = [[JZCustomField alloc] initWithFrame: self.modifyPasswordFrame.downFieldFrame];
        _downField.textColor = [UIColor whiteColor];

    }
    return _downField;
}

- (UILabel *)downSublabel
{
    if (!_downSublabel) {
        _downSublabel = [[UILabel alloc] initWithFrame: self.modifyPasswordFrame.downSublabelFrame];
        _downSublabel.textColor = [UIColor whiteColor];
        _downSublabel.font = [UIFont systemFontOfSize: 15];
    }
    return _downSublabel;
}

- (JZTipView *)downTipView
{
    if (!_downTipView) {
        _downTipView = [[JZTipView alloc] initWithFrame:self.modifyPasswordFrame.downTipFrame];
//        _downTipView.layer.cornerRadius = self.modifyPasswordFrame.downTipFrame.size.height / 2;
//        _downTipView.layer.masksToBounds = YES;
    }
    return _downTipView;
}

- (UIButton *)modifyBtn
{
    if (!_modifyBtn) {
        _modifyBtn = [[UIButton alloc] initWithFrame: self.modifyPasswordFrame.modifyBtnFrame];
        _modifyBtn.layer.cornerRadius = self.modifyPasswordFrame.modifyBtnFrame.size.height / 2;
        _modifyBtn.layer.masksToBounds = YES;
        _modifyBtn.backgroundColor = [UIColor colorWithRed:0.00 green:0.57 blue:0.91 alpha:1.00];
    }
    return _modifyBtn;
}

- (UIButton *)backBtn
{
    if (!_backBtn) {
        _backBtn = [[UIButton alloc] initWithFrame: self.modifyPasswordFrame.backBtnFrame];
        [_backBtn setTitle:@"返回到上一级" forState:UIControlStateNormal];
        _backBtn.titleLabel.font = [UIFont systemFontOfSize: 15];
        [_backBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_backBtn setTitleColor:[UIColor colorWithWhite:0.8 alpha:1] forState:UIControlStateHighlighted];
    }
    return _backBtn;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.backgroundImageView];
        [self addSubview:self.title];
        [self addSubview:self.upLabel];
        [self addSubview:self.upField];
        [self addSubview:self.upSublabel];
//        [self addSubview:self.upTipView];
        [self addSubview:self.downLabel];
        [self addSubview:self.downSublabel];
        [self addSubview:self.downField];
//        [self addSubview:self.downTipView];
        [self addSubview:self.modifyBtn];
        [self addSubview:self.backBtn];
    }
    return self;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.upField resignFirstResponder];
    [self.downField resignFirstResponder];
}


@end
