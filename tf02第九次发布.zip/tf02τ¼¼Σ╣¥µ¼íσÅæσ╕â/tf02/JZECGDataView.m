//
//  JZECGDataView.m
//  tf02
//
//  Created by F7686324 on 27/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZECGDataView.h"

@implementation JZECGDataView

- (CAShapeLayer *)shapeLayer
{
    if (!_shapeLayer) {
        _shapeLayer = [CAShapeLayer layer];
    }
    return _shapeLayer;
}

- (void)setJzHeight:(CGFloat)jzHeight
{
    _jzHeight = jzHeight;
}

- (void)setDataArray:(NSMutableArray *)dataArray
{
    _dataArray = dataArray;
    self.frame = CGRectMake(0, 0, dataArray.count * space, self.jzHeight);
    [self.shapeLayer removeFromSuperlayer];
    self.shapeLayer = [self creatLayerWithArray:dataArray];
    [self.layer addSublayer:self.shapeLayer];

}

- (void)setType:(NSString *)type
{
    _type = type;
    if ([type isEqualToString:@"20mm/mV,50mm/s"]) {
        proportion = 500;
        space = ratio / 60 * 2;

    } else if ([type isEqualToString:@"10mm/mV,25mm/s"]) {
        proportion = 1000;
        space = ratio / 60;

    } else if ([type isEqualToString:@"5mm/mV,12.5mm/s"]) {
        proportion = 2000;
        space = ratio / 60 / 2;

    }

}

- (CAShapeLayer*)creatLayerWithArray: (NSMutableArray *)array
{
    CGMutablePathRef dataPath = CGPathCreateMutable();

    CGPathMoveToPoint(dataPath, NULL, 0, self.frame.size.height / 2 - [array[0] intValue] / proportion * ratio);
    for (int i = 1; i < array.count; i++) {
        CGPathAddLineToPoint(dataPath, NULL, i * space, self.frame.size.height / 2 - [array[i] intValue] / proportion * ratio);
        CGPathMoveToPoint(dataPath, NULL, i * space, self.frame.size.height / 2 - [array[i] intValue] / proportion * ratio);
    }

    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.frame = self.bounds;
    [shapeLayer setFillColor: [UIColor clearColor].CGColor];
    [shapeLayer setStrokeColor: [UIColor blackColor].CGColor];

    shapeLayer.lineWidth = 1;
    [shapeLayer setPath: dataPath];
    shapeLayer.lineCap = kCALineCapRound;
    shapeLayer.lineJoin = kCALineJoinRound;
    shapeLayer.masksToBounds = YES;
    CGPathRelease(dataPath);

    //Animate path
    CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    pathAnimation.duration = 1;
    pathAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    pathAnimation.toValue = [NSNumber numberWithFloat:1.0f];
    [shapeLayer addAnimation:pathAnimation forKey: nil];
    return shapeLayer;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        ratio = 64;
        smallSpace = ratio / 10;
        bigSpace = ratio / 2;
        space = ratio / 60 / 2;
        proportion = 2000;

    }
    return self;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.delegate showECGGainWithECGDataView:self];
}

@end
