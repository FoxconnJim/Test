//
//  JZContactUsView.h
//  tf02
//
//  Created by F7686324 on 03/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JZContactUsView;
@protocol JZContactUsViewDelegate <NSObject>

- (void)contactUsView:(JZContactUsView *)contactUsView didSelectRowAtIndex:(NSIndexPath *)indexPath;

@end

@interface JZContactUsView : UIView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, weak) id <JZContactUsViewDelegate> delegate;

@end
