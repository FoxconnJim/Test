//
//  JZSegment.m
//  tf02
//
//  Created by F7686324 on 14/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZSegment.h"

@implementation JZSegment

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self jzSetNeedsDisplay];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        [self jzSetNeedsDisplay];
    }
    return self;
}

- (instancetype)initWithItems:(NSArray *)items
{
    self = [super initWithItems:items];
    if (self) {

        [self jzSetNeedsDisplay];
        
    }
    return self;
}

- (void)jzSetNeedsDisplay
{
    self.tintColor = [UIColor clearColor];//去掉颜色,现在整个segment都看不见
    NSDictionary *textAttributes = @{NSFontAttributeName:[UIFont systemFontOfSize:10], NSForegroundColorAttributeName: [UIColor colorWithWhite:0.9 alpha:0.9]};
    [self setTitleTextAttributes:textAttributes forState:UIControlStateNormal];//设置文字属性
//    NSDictionary *selectedAttributes = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:10], NSForegroundColorAttributeName: [UIColor whiteColor]};
//    [self setTitleTextAttributes: selectedAttributes forState: UIControlStateSelected];
    
}

@end
