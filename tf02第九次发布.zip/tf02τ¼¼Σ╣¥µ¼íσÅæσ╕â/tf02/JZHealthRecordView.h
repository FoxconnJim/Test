//
//  JZHealthRecordView.h
//  tf02
//
//  Created by F7686324 on 20/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h" 
#import "JZData.h"
#import "JZBloodPressureData.h"
#import "JZHeartRateData.h"

#import <SystemConfiguration/SystemConfiguration.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "AFNetworking.h"

#import "JZECGCell.h"
#import "JZpromptLabel.h"

@protocol JZHealthRecordViewDelegate <NSObject>

- (void)showECGGainWithECGDataView:(JZECGDataView *)ECGDataView;

@end

@interface JZHealthRecordView : UIView <UITableViewDelegate, UITableViewDataSource, JZECGDataViewDelegate>

@property (nonatomic, weak) id <JZHealthRecordViewDelegate> delegate;

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) JZData *jzdata;
@property (nonatomic, strong) JZBloodPressureData *bpData;
@property (nonatomic, strong) JZHeartRateData *hrData;
@property (nonatomic, copy) NSString *jzType;
@property (nonatomic, copy) NSString *filePath;
@property (nonatomic, strong) NSMutableArray *firstArray;
@property (nonatomic, strong) NSMutableArray *secondArray;
@property (nonatomic, strong) NSMutableArray *thirdArray;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) UILabel *topLabel;
@property (nonatomic, strong) JZpromptLabel *promptLabel;

@end
