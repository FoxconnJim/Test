//
//  JZRemindEvent.h
//  tf02
//
//  Created by F7686324 on 12/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZRemindEvent : NSObject

@property (nonatomic, copy) NSString *remindInfo;
@property (nonatomic, strong) NSDate *remindDate;
@property (nonatomic, strong) NSMutableArray *remindRepeatArray;
@property (nonatomic, copy) NSString *remindIdentifier;
@property (nonatomic) BOOL remind;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)remindEventWithDict:(NSDictionary *)dict;

@end
