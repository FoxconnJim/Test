//
//  JZHealthIndicatorFrame.m
//  tf02
//
//  Created by Jim on 16/3/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZHealthIndicatorFrame.h"
#import "Utility.h"

@implementation JZHealthIndicatorFrame

- (instancetype)init
{
    self = [super init];
    if (self) {
        CGFloat margin = 10;

        CGFloat segmentX = screenEdgeMargin;
        CGFloat segmentY = margin;
        CGFloat segmentW = screenW - screenEdgeMargin * 2;
        CGFloat segmentH = 30;
        
        self.segmentFrame = CGRectMake(segmentX, segmentY, segmentW, segmentH);
        
        CGFloat cellX = screenEdgeMargin;
        CGFloat cellY = 2;
        CGFloat cellW = segmentW;
        CGFloat cellH = cellW / 2;
        self.cellFrame = CGRectMake(cellX, cellY, cellW, cellH);
     }
    return self;
}

@end
