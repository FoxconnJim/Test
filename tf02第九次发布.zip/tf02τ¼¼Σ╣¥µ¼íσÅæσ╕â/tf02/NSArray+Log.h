//
//  NSArray+Log.h
//  tf02
//
//  Created by AN PEN on 4/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Log)

@end
