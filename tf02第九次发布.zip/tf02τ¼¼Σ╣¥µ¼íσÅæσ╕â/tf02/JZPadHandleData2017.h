//
//  JZPadHandleData2017.h
//  tf02
//
//  Created by F7686324 on 2017/1/13.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utility.h"

@interface JZPadHandleData2017 : NSObject

{
    CGFloat value;
    CGFloat startValue;
}

@property (nonatomic, strong) NSMutableArray *totalArray;
@property (nonatomic, strong) NSMutableArray *meatimeArray;

- (instancetype)initWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString;
+ (instancetype)dataWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString;


@end
