//
//  JZMeasureRemindTableViewController.m
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZMeasureRemindTableViewController.h"
#import "JZRemindEventViewController.h"
#import "JZMeasureRemindCell.h"
#import <EventKit/EventKit.h>
#import "EventManger.h"
#import "JZRemindEvent.h"
#import "NSDate+JZRemindEvent.h"
#import "NSMutableArray+JZArrayToRemindRepeat.h"
#import "NSObject+JZEKEvent.h"

@interface JZMeasureRemindTableViewController ()

@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) UILabel *lbl;
@property (nonatomic) BOOL turnOn;

@end

@implementation JZMeasureRemindTableViewController

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
    }
    return _queue;
}

- (UILabel *)lbl
{
    if (!_lbl) {
        _lbl = [[UILabel alloc] initWithFrame: CGRectMake(0, 0, screenW, screenH - statusBarHeight - naviHeight)];
        _lbl.text = @"您还未设置提醒事项~";
        _lbl.numberOfLines = 0;
        _lbl.textColor = [UIColor grayColor];
        _lbl.textAlignment = NSTextAlignmentCenter;
        _lbl.backgroundColor = [UIColor whiteColor];
    }
    return _lbl;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"测量提醒";
    NSString *colorType = @"灰";
    [colorType storeValueByKey:JZRefreshColor];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addNaozhong)];
    self.navigationItem.rightBarButtonItem = rightItem;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUI) name:measureRemindNotification object:nil];

    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];
    if (!remindEventArray) {
        remindEventArray = [NSMutableArray array];
    }
    if (!remindEventArray.count) {
        [self.view addSubview:self.lbl];
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    } else {
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;

        [self.lbl removeFromSuperview];
    }
}

//- (void)viewWillDisappear:(BOOL)animated
//{
//    [super viewWillDisappear:animated];
//    NSError *err;
//    [[EventManger shareInstance].store commit:&err];
//    if (err) {
//        NSLog(@"commit error = %@", err);
//    }
//}

- (void)updateUI
{
    [self.tableView reloadData];
    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];
    if (!remindEventArray) {
        remindEventArray = [NSMutableArray array];
    }
    if (!remindEventArray.count) {
        [self.view addSubview:self.lbl];
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    } else {
        self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;

        [self.lbl removeFromSuperview];
    }
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];

    return remindEventArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZMeasureRemindCell *cell = [JZMeasureRemindCell cellWithTableView:tableView];
    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];

    if ([remindEventArray isKindOfClass:[NSMutableArray class]]) {
        if (remindEventArray.count) {
            JZRemindEvent *remindEvent = remindEventArray[indexPath.row];
            if (remindEvent.remind) {
                cell.jzSwitch.on = YES;
                cell.leftLabel.textColor = [UIColor blackColor];
                cell.rightLabel.textColor = [UIColor blackColor];
                cell.downLabel.textColor = [UIColor grayColor];
            } else {
                cell.jzSwitch.on = NO;
                cell.leftLabel.textColor = [UIColor lightGrayColor];
                cell.rightLabel.textColor = [UIColor lightGrayColor];
                cell.downLabel.textColor = [UIColor lightGrayColor];
            }

            cell.jzSwitch.tag = indexPath.row;
            [cell.jzSwitch addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];

            NSString *jzRemindTime = [remindEvent.remindDate dateToRemindTime];
            cell.leftLabel.text = [[jzRemindTime componentsSeparatedByString:@" "] firstObject];
            cell.rightLabel.text = [[jzRemindTime componentsSeparatedByString:@" "] lastObject];

            NSString *jzRemindInfo = remindEvent.remindInfo;
            NSString *jzRemindRepeat = [remindEvent.remindRepeatArray arrayToRemindRepeat];
            if (!jzRemindInfo.length) {
                cell.downLabel.text = jzRemindRepeat;

            } else if (!jzRemindRepeat.length) {
                cell.downLabel.text = jzRemindInfo;

            } else {
                cell.downLabel.text = [NSString stringWithFormat:@"%@, %@", jzRemindInfo, jzRemindRepeat];
                
            }
        }
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];

    NSArray *eventArray = [[EventManger shareInstance] getThisWeekEventFromMonday];

    JZRemindEvent *remindEvent = remindEventArray[indexPath.row];
    if (editingStyle == UITableViewCellEditingStyleDelete) {

        for (EKEvent *event in eventArray) {
            if ([event.eventIdentifier isEqualToString:remindEvent.remindIdentifier]) {

                [[EventManger shareInstance] deleteEvent:event];

            }

        }

        [remindEventArray removeObjectAtIndex:indexPath.row];
        [remindEventArray storeValueByKey:kremindEvent];

        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self updateUI];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

- (void)switchAction:(UISwitch *)sender
{
    NSLog(@"%s", __FUNCTION__);
    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];
    JZRemindEvent *remindEvent = remindEventArray[sender.tag];


    if (remindEvent.remind) {
        remindEvent.remind = NO; //开关为开是，点击立即关闭

        if (self.turnOn) {
            NSArray *eventArray = [[EventManger shareInstance] getThisWeekEventFromMonday];

            for (EKEvent *event in eventArray) {
                if ([event.eventIdentifier isEqualToString:remindEvent.remindIdentifier]) {
                    [[EventManger shareInstance] deleteEvent:event];
                }
            }


            

        } else {
            [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(turnOffAndOn:) object:sender];

        }


    } else {
        if ([remindEvent.remindDate timeIntervalSince1970] < [[NSDate date] timeIntervalSince1970] && [[remindEvent.remindRepeatArray arrayToRemindRepeat] isEqualToString:@"今天"]) {

            remindEvent.remind = NO;
            [LCProgressHUD showInfoMsg:@"您要设置的提醒时间已过"];
        } else {
            self.turnOn = NO;
            remindEvent.remind = YES;

            [self performSelector:@selector(turnOffAndOn:) withObject:sender afterDelay:1];

        }

    }

    [remindEventArray storeValueByKey:kremindEvent];
    [self.tableView reloadData];

}

- (void)turnOffAndOn:(UISwitch *)sender
{
    self.turnOn = YES;


    NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];
    JZRemindEvent *remindEvent = remindEventArray[sender.tag];

    remindEvent.remind = YES;

    EKEvent *newEvent = [NSObject eventWithRemindInfo:remindEvent.remindInfo remindDate:remindEvent.remindDate remindRepeatArray:remindEvent.remindRepeatArray];


    [[EventManger shareInstance] createEvent:newEvent];

    remindEvent.remindIdentifier = newEvent.eventIdentifier;

    [remindEventArray storeValueByKey:kremindEvent];
    [self.tableView reloadData];
}

- (void)addNaozhong
{
    NSLog(@"%s", __FUNCTION__);
    [EventManger shareInstance];
    JZRemindEventViewController *remindEventVC = [[JZRemindEventViewController alloc] init];

    UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:remindEventVC];
    navi.navigationBar.barStyle = UIBarStyleBlack;
    navi.navigationBar.barTintColor = barBackgroundColor;
    navi.navigationBar.tintColor = [UIColor whiteColor];
    navi.navigationBar.translucent = NO;
    [self presentViewController:navi animated:YES completion:nil];
}



@end
