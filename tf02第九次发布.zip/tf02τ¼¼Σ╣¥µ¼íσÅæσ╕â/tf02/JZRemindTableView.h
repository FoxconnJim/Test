//
//  JZRemindTableView.h
//  tf02
//
//  Created by F7686324 on 10/12/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZTodayRemindData.h"
#import "JZTodayRemindCell.h"

@class JZRemindTableView;
@protocol JZRemindTableViewDelegate <NSObject>

@optional
- (void)remindTableView:(JZRemindTableView *)remindTableView didSelectRowsAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface JZRemindTableView : UITableView <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UILabel *tips;

@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, strong) NSArray *cellHeightArray;

@property (nonatomic, copy) NSString *cellID;

@property (nonatomic) BOOL showIndicator;

@property (nonatomic, weak) id <JZRemindTableViewDelegate> remindDelegate;

@end
