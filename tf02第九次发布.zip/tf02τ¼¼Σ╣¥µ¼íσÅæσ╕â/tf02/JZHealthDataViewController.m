//
//  JZHealthDataViewController.m
//  tf02
//
//  Created by AN PEN on 5/16/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHealthDataViewController.h"
#import "JZHealthDataView.h"
#import "JZOperation.h"
#import "JZBloodPressureData.h"
#import "JZHeartRateData.h"
#import "JZBloodSugarData.h"
#import "JZBodyFatData.h"
#import "JZWeightData.h"
#import "JZBloodOxygenData.h"
#import "MJRefresh.h"
#import "JZHealthRecordViewController.h"

#import "JZFmdbTool.h"

@interface JZHealthDataViewController () <JZHealthDataViewDelegate, JZOperationDelegate>

@property (nonatomic, strong) JZHealthDataView *healthDataView;
@property (nonatomic, strong) JZHealthRecordViewController *healthRecordVC;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, copy) NSString *memberId;

@end

@implementation JZHealthDataViewController

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (JZHealthDataView *)healthDataView
{
    if (!_healthDataView) {
        _healthDataView = [[JZHealthDataView alloc] initWithFrame:self.view.bounds];
        _healthDataView.delegate = self;
        _healthDataView.jzType = self.jzType;
    }
    return _healthDataView;
}

- (void)setJzType:(NSString *)jzType
{
    _jzType = jzType;
}

- (void)setDetailDataArray:(NSMutableArray *)detailDataArray
{
    _detailDataArray = detailDataArray;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview: self.healthDataView];
    self.title = @"健康日志";

    self.healthDataView.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock: ^{
        [self getDataByInterface];
    }];

    JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];
    if (refreshInfo.canHealthDetailDataRefresh) {
        [self.healthDataView.tbView.mj_header beginRefreshing];
        refreshInfo.canHealthDetailDataRefresh = NO;
        [refreshInfo storeValueByKey:kRefreshInfo];
    } else {
        [self getDataByInterface];

    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    

}

- (void)getDataByInterface
{

    NSString *endTimeString = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [[dateFormatter dateFromString: endTimeString] localDate];
    NSInteger endTimeInt = [date timeIntervalSince1970] + 24 * 60 * 60;
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:endTimeInt];
    NSDate *staDate;

    if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 0) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600];

    } else if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 1) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600 * 7];

    } else if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 2) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600 * 30];

    } else if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 3) {
        staDate = [NSDate dateWithTimeIntervalSince1970: endTimeInt - 24 * 3600 * 365];
        
    }
    NSString *endtime = [endDate dateToString];
    NSString *statime = [staDate dateToString];

    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"memberId"] = [[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] memberId];
    param[@"endtime"] = endtime;
    param[@"count"] = @"10000";
    param[@"statime"] = statime;

    if ([self.jzType isEqualToString:@"血压"]) {
        JZOperation *operation = [JZOperation operationWithURLString:bloodPressureURL andParam:param getOrPost:JZ_GET];
        operation.delegate = self;
        operation.name = bloodPressureOperation;
    } else if ([self.jzType isEqualToString:@"心率"]) {
        JZOperation *operation = [JZOperation operationWithURLString:heartRateURL andParam:param getOrPost:JZ_GET];
        operation.delegate = self;
        operation.name = heartRateOpreation;
    } else if ([self.jzType isEqualToString:@"血糖"]) {
        JZOperation *operation = [JZOperation operationWithURLString:bloodSugarURL andParam:param getOrPost:JZ_GET];
        operation.delegate = self;
        operation.name = bloodSugarOpreation;
    } else if ([self.jzType isEqualToString:@"体脂"]) {
        JZOperation *operation = [JZOperation operationWithURLString:bodyFatURL andParam:param getOrPost:JZ_GET];
        operation.delegate = self;
        operation.name = bodyFatOperation;
    } else if ([self.jzType isEqualToString:@"体重"]) {
        JZOperation *operation = [JZOperation operationWithURLString:bodyFatURL andParam:param getOrPost:JZ_GET];
        operation.delegate = self;
        operation.name = weightOpreation;
    } else if ([self.jzType isEqualToString:@"血氧"]) {
        JZOperation *operation = [JZOperation operationWithURLString:oxygenURL andParam:param getOrPost:JZ_GET];
        operation.delegate = self;
        operation.name = bloodOxygenOpreation;
    }
}

- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"didSelectRowAtIndexPath");
    _healthRecordVC = [[JZHealthRecordViewController alloc] init];
    _healthRecordVC.jzType = self.jzType;
    NSMutableArray *arr = [[[self.detailDataArray changeOrder] sortByMonth] changeOrder];
    NSMutableArray *dataArray = [NSMutableArray array];
    for (int i = 0; i < arr.count; i++) {
        NSMutableArray *array = arr[i];
        if (array.count) {
            [dataArray addObject: array];
        }
    }
    if ([self.jzType isEqualToString:@"血压"]) {
        JZBloodPressureData *bpData = dataArray[indexPath.section][indexPath.row];
        _healthRecordVC.bpData = bpData;
    } else if ([self.jzType isEqualToString:@"心率"]) {
        JZHeartRateData *hrData = dataArray[indexPath.section][indexPath.row];
        _healthRecordVC.hrData = hrData;
    } else {
        JZData *jzdata = dataArray[indexPath.section][indexPath.row];
        _healthRecordVC.jzdata = jzdata;
    }
    [self.navigationController pushViewController: _healthRecordVC animated:YES];

    
}

#pragma mark JZOpreationDelegate Methods

- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    if ([operation.name isEqualToString:bloodPressureOperation]) {
        NSArray *array = responseObject[@"data"];
        if (array.count != 0) {
            [JZFmdbTool beginTransaction];
            @try {
                [self.detailDataArray removeAllObjects];
                [JZFmdbTool deleteBloodPressureDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                for (int i = 0; i < array.count; i++) {
                    NSDictionary *dict = array[i];
                    JZBloodPressureData *bloodPressureData = [JZBloodPressureData dataWithDictionary: dict];
                    [JZFmdbTool insertBloodPressureData:bloodPressureData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    [self.detailDataArray addObject: bloodPressureData];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            self.healthDataView.dataArray = self.detailDataArray;
            
            //saveToHealth
//            for (JZBloodPressureData *data in self.detailDataArray) {
//                NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//                userInfo[@"data"] = [data bpDp];
//                userInfo[@"meatime"] = [data meatime];
//                [[NSNotificationCenter defaultCenter] postNotificationName:kSaveDiastolicData object:nil userInfo: userInfo];
//            }
//            for (JZBloodPressureData *data in self.detailDataArray) {
//                NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//                userInfo[@"data"] = [data bpSp];
//                userInfo[@"meatime"] = [data meatime];
//                [[NSNotificationCenter defaultCenter] postNotificationName:kSaveSystolicData object:nil userInfo: userInfo];
//            }
        }

    } else if ([operation.name isEqualToString: heartRateOpreation]) {
        NSArray *array = responseObject[@"data"];
        if (array.count != 0) {
            [JZFmdbTool beginTransaction];
            @try {
                [self.detailDataArray removeAllObjects];
                [JZFmdbTool deleteHeartRateDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                for (int i = 0; i < array.count; i++) {
                    NSDictionary *dict = array[i];
                    JZHeartRateData *heartRateData = [JZHeartRateData dataWithDictionary: dict];
                    [JZFmdbTool insertHeartRateData:heartRateData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    [self.detailDataArray addObject: heartRateData];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            self.healthDataView.dataArray = self.detailDataArray;
            //saveToHealth
//            for (JZHeartRateData *data in self.detailDataArray) {
//                NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//                userInfo[@"data"] = [data data];
//                userInfo[@"meatime"] = [data meatime];
//                [[NSNotificationCenter defaultCenter] postNotificationName:kSaveHeartRateData object:nil userInfo: userInfo];
//            }
        }

    } else if ([operation.name isEqualToString: bloodSugarOpreation]) {
        NSArray *array = responseObject[@"data"];
        if (array.count != 0) {
            [JZFmdbTool beginTransaction];
            @try {
                [self.detailDataArray removeAllObjects];
                [JZFmdbTool deleteBloodSugarDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                for (int i = 0; i < array.count; i++) {
                    NSDictionary *dict = array[i];
                    JZBloodSugarData *bloodSugarData = [JZBloodSugarData dataWithDictionary: dict];
                    [JZFmdbTool insertBloodSugarData:bloodSugarData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    [self.detailDataArray addObject: bloodSugarData];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            self.healthDataView.dataArray = self.detailDataArray;
            //saveToHealth
//            for (JZBloodSugarData *data in self.detailDataArray) {
//                NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//                userInfo[@"data"] = data.data;
//                userInfo[@"meatime"] = data.meatime;
//                [[NSNotificationCenter defaultCenter] postNotificationName:kSaveBloodSugarData object:nil userInfo: userInfo];
//            }

        }
    } else if ([operation.name isEqualToString: bodyFatOperation]) {
        NSArray *array = responseObject[@"data"];
        if (array.count != 0) {
            [JZFmdbTool beginTransaction];
            @try {
                [self.detailDataArray removeAllObjects];
                [JZFmdbTool deleteBodyFatDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                for (int i = 0; i < array.count; i++) {
                    NSDictionary *dict = array[i];
                    JZBodyFatData *bodyFatData = [JZBodyFatData dataWithDictionary: dict];
                    [JZFmdbTool insertBodyFatData:bodyFatData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    [self.detailDataArray addObject: bodyFatData];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            self.healthDataView.dataArray = self.detailDataArray;

            //saveToHealth
//            for (JZBodyFatData *data in self.detailDataArray) {
//                NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//                userInfo[@"data"] = [NSString stringWithFormat:@"%0.1f", [[data data] floatValue] / 100.0f];
//                userInfo[@"meatime"] = data.meatime;
//                [[NSNotificationCenter defaultCenter] postNotificationName:kSaveBodyFatData object:nil userInfo: userInfo];
//            }
        }
    } else if ([operation.name isEqualToString: weightOpreation]) {
        NSArray *array = responseObject[@"data"];
        if (array.count != 0) {
            [JZFmdbTool beginTransaction];
            @try {
                [self.detailDataArray removeAllObjects];
                [JZFmdbTool deleteWeightDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                for (int i = 0; i < array.count; i++) {
                    NSDictionary *dict = array[i];
                    JZWeightData *weightData = [JZWeightData dataWithDictionary: dict];
                    [JZFmdbTool insertWeightData:weightData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    [self.detailDataArray addObject: weightData];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            self.healthDataView.dataArray = self.detailDataArray;

            //saveToHealth
//            for (JZWeightData *data in self.detailDataArray) {
//                NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//                userInfo[@"data"] = data.data;
//                userInfo[@"meatime"] = data.meatime;
//                [[NSNotificationCenter defaultCenter] postNotificationName:kSaveWeightData object:nil userInfo: userInfo];
//            }

        }
    } else if ([operation.name isEqualToString: bloodOxygenOpreation]) {
        NSArray *array = responseObject[@"data"];
        if (array.count != 0) {
            [JZFmdbTool beginTransaction];
            @try {
                [self.detailDataArray removeAllObjects];
                [JZFmdbTool deleteBloodOxygenDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                for (int i = 0; i < array.count; i++) {
                    NSDictionary *dict = array[i];
                    JZBloodOxygenData *bloodOxygenData = [JZBloodOxygenData dataWithDictionary: dict];
                    [JZFmdbTool insertBloodOxygenData:bloodOxygenData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    [self.detailDataArray addObject: bloodOxygenData];
                }
            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }

            self.healthDataView.dataArray = self.detailDataArray;

            //saveToHealth
//            for (JZBloodOxygenData *data in self.detailDataArray) {
//                NSMutableDictionary *userInfo = [NSMutableDictionary dictionary];
//                userInfo[@"data"] = [NSString stringWithFormat:@"%0.1f", [[data data] floatValue] / 100.0f];
//                userInfo[@"meatime"] = data.meatime;
//                [[NSNotificationCenter defaultCenter] postNotificationName:kSaveBloodOxygenData object:nil userInfo: userInfo];
//            }
        }
    }
    [self.healthDataView.tbView.mj_header endRefreshing];
}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [self.healthDataView.tbView.mj_header endRefreshing];
        self.healthDataView.dataArray = self.detailDataArray;
    } else {
        [self.healthDataView.tbView.mj_header endRefreshing];
    }
}

@end
