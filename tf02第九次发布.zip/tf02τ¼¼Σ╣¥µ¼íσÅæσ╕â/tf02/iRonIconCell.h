//
//  iRonIconCell.h
//  tf02
//
//  Created by IDSBG-00 on 2016/9/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iRonIconCell : UITableViewCell

//@property (nonatomic,strong) UIImage *iconImage;
//@property (nonatomic,strong) NSString *familyNameStr;

@property (nonatomic,strong) UIImageView *iconImageView;
@property (nonatomic,strong) UILabel *familyNameLabel;
@end
