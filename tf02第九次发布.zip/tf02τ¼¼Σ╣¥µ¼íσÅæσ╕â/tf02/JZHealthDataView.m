//
//  JZHealthDataView.m
//  tf02
//
//  Created by AN PEN on 4/6/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHealthDataView.h"
#import "Utility.h"
#import "JZData.h"
#import "JZBloodPressureData.h"

@implementation JZHealthDataView

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, screenH - statusBarHeight - naviHeight)];
        _tbView.delegate = self;
        _tbView.dataSource = self;

    }
    return _tbView;
}
- (NSMutableArray *)monthArray
{
    if (!_monthArray) {
        _monthArray = [NSMutableArray array];
    }
    return _monthArray;
}

- (NSMutableArray *)detailDataArray
{
    if (!_detailDataArray) {
        _detailDataArray = [NSMutableArray array];
    }
    return _detailDataArray;
}

- (NSMutableArray *)selectArray
{
    if (!_selectArray) {
        _selectArray = [NSMutableArray array];
    }
    return _selectArray;
}

- (void)setDataArray:(NSMutableArray *)dataArray
{
    _dataArray = dataArray;
    dataArray = [[[dataArray changeOrder] sortByMonth] changeOrder];
    [self.detailDataArray removeAllObjects];
    [self.monthArray removeAllObjects];
    [self.selectArray removeAllObjects];
    for (int i = 0; i < dataArray.count; i++) {
        NSMutableArray *array = dataArray[i];
        if (array.count) {
            [self.detailDataArray addObject: array];
            JZDataPoint *dataPoint = array[0];
            [self.monthArray addObject:dataPoint];
        }
    }

    for (int i = 0; i < self.monthArray.count; i++)
    {
        [self.selectArray addObject: @"open"];
    }
    [self.tbView reloadData];
}

- (void)setJzType:(NSString *)jzType
{
    _jzType = jzType;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        margin = 10;
        [self addSubview: self.tbView];
    }
    return self;
}

#pragma mark UITableViewDelegate Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.monthArray.count;

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.selectArray[section] isEqualToString:@"open"]) {
        return [[self.detailDataArray objectAtIndex: section] count];
    } else {
        return 0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"cellid";
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellid];
    if (cell == nil) {
        cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    if ([self.jzType isEqualToString:@"血压"]) {
        
        JZBloodPressureData *BPData = self.detailDataArray[indexPath.section][indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@/%@", BPData.bpSp, BPData.bpDp];
        cell.detailTextLabel.text = [[NSString stringWithFormat:@"%@", BPData.meatime] substringToIndex:16];
    } else {

        JZData *data = self.detailDataArray[indexPath.section][indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@", data.data];
        cell.detailTextLabel.text = [[NSString stringWithFormat:@"%@", data.meatime] substringToIndex:16];
    }

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.delegate didSelectRowAtIndexPath: indexPath];
    [tableView deselectRowAtIndexPath: indexPath animated:YES];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc] initWithFrame: CGRectMake(0, 0, self.frame.size.width, 44)];
    headerView.backgroundColor = appBackgroundColor;
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(margin, 0, self.frame.size.width / 2 - margin, 44)];
    if ([self.jzType isEqual:@"血压"]) {
        label.text = @" 血压(mmHg)";
    } else if ([self.jzType isEqual: @"心率"]) {
        label.text = @" 心率(BPM)";
    } else if ([self.jzType isEqual: @"血糖"]) {
        label.text = @" 血糖(mmol/L)";
    } else if ([self.jzType isEqual: @"体脂"]) {
        label.text = @" 体脂(%)";
    } else if ([self.jzType isEqual: @"血氧"]) {
        label.text = @" 血氧(%)";
    } else if ([self.jzType isEqual: @"体重"]) {
        label.text = @" 体重(kg)";
    }
    label.textColor = barBackgroundColor;
    [headerView addSubview: label];

    UILabel *monthLabel = [[UILabel alloc] initWithFrame: CGRectMake(self.frame.size.width / 2, 0, self.frame.size.width / 2 - margin * 2, 44)];
    monthLabel.textAlignment = NSTextAlignmentRight;
    JZDataPoint *dataPoint = self.monthArray[section];
    NSArray *timeArray = [[[dataPoint.meatime componentsSeparatedByString:@" "] firstObject] componentsSeparatedByString:@"-"];
    NSString *yearStr = timeArray[0];
    NSString *monthStr = timeArray[1];

    monthLabel.text = [NSString stringWithFormat:@"%@ 年%@ 月▾", yearStr, monthStr];
    monthLabel.textColor = barBackgroundColor;
    [headerView addSubview: monthLabel];

    UIButton *btn = [[UIButton alloc] initWithFrame: CGRectMake(0, 0, self.frame.size.width, 44)];
    btn.tag = section;
    [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    [headerView addSubview: btn];
    return headerView;
}

- (void)click: (UIButton *)button
{
    if ([self.selectArray[button.tag] isEqualToString: @"close"])
    {
        [self.selectArray replaceObjectAtIndex: button.tag withObject: @"open"];
    } else {
        [self.selectArray replaceObjectAtIndex: button.tag withObject: @"close"];
    }
    NSIndexSet *indexSet = [NSIndexSet indexSetWithIndex:button.tag];
    [self.tbView reloadSections:indexSet withRowAnimation: UITableViewRowAnimationFade];
}





































@end
