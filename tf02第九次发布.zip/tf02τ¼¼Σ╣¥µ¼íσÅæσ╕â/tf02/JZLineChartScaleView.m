//
//  JZLineChartScaleView.m
//  tf02
//
//  Created by AN PEN on 4/7/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZLineChartScaleView.h"

@implementation JZLineChartScaleView

- (UISegmentedControl *)segment
{
    if (!_segment) {
        _segment = [[JZSegment alloc] init];
    }
    return _segment;
}

- (JZTimeView *)timeView
{
    if (!_timeView) {
        _timeView = [[JZTimeView alloc] initWithFrame:self.bounds];
    }
    return _timeView;
}

- (void)setTextArray:(NSMutableArray *)textArray
{
    _textArray = textArray;

}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.jzScale = 1.f;
        [self addSubview:self.timeView];
    }
    return self;
}

- (JZTime *)jzTime
{
    if (!_jzTime) {
        _jzTime = [[JZTime alloc] init];
    }
    return _jzTime;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;
    self.timeView.timeLengthString = timeLengthString;
    self.timeView.frame = CGRectZero;
    [self.segment removeFromSuperview];
    if ([timeLengthString isEqualToString:jzDay]) {
        self.segment = [[JZSegment alloc] initWithFrame:CGRectMake(self.frame.size.width / 12, 0, self.frame.size.width * 5 / 6, self.frame.size.height)];
        NSArray *array = [self.jzTime.dayArray firstObject];
        for (int i = 0; i < array.count; i++) {
            [self.segment insertSegmentWithTitle:[array objectAtIndex:i] atIndex:i animated:YES];
        }
    } else if ([timeLengthString isEqualToString:jzWeek]) {
        self.segment = [[JZSegment alloc] initWithFrame:CGRectMake(self.frame.size.width / 14.f, 0, self.frame.size.width * 6.f / 7.f, self.frame.size.height)];
        NSArray *array = [self.jzTime.weekArray firstObject];
        for (int i = 0; i < array.count; i++) {
            [self.segment insertSegmentWithTitle:[array objectAtIndex:i] atIndex:i animated:YES];
        }
    } else if ([timeLengthString isEqualToString:jzMonth]) {
        self.segment = [[JZSegment alloc] initWithFrame:CGRectMake(self.frame.size.width / 10.f, 0, self.frame.size.width * 4.f / 5.f, self.frame.size.height)];
        NSArray *array = [self.jzTime.monthArray firstObject];
        for (int i = 0; i < array.count; i++) {
            [self.segment insertSegmentWithTitle:[array objectAtIndex:i] atIndex:i animated:YES];
        }
    } else if ([timeLengthString isEqualToString:jzYear]) {
        self.segment = [[JZSegment alloc] initWithFrame:CGRectMake(self.frame.size.width / 12.f, 0, self.frame.size.width, self.frame.size.height)];
        NSArray *array = [self.jzTime.yearArray firstObject];
        for (int i = 0; i < array.count; i++) {
            [self.segment insertSegmentWithTitle:[array objectAtIndex:i] atIndex:i animated:YES];
        }
    }
    [self addSubview: self.segment];
}

- (void)setJzScale:(CGFloat)jzScale
{
    _jzScale = jzScale;

    [self jzSetNeedsDisplay];
}

- (void)jzSetNeedsDisplay
{
    CGRect frame = self.frame;
    CGFloat margin = 5;
    CGFloat jzWidth = screenW - screenEdgeMargin * 2 - margin * 2;
    frame.size.width = jzWidth * self.jzScale;
    self.frame = frame;
    self.timeView.frame = self.bounds;

    if ([self.timeLengthString isEqualToString:jzDay]) {
        if (self.jzScale >= 1.f & self.jzScale < 4.f / 3.f) {

            self.timeView.textArray = [self.jzTime.dayArray objectAtIndex:0];

        } else if (self.jzScale >= 4.f / 3.f & self.jzScale < 2.f) {

            self.timeView.textArray = [self.jzTime.dayArray objectAtIndex:1];

        } else if (self.jzScale >= 2.f && self.jzScale < 3.f) {

            self.timeView.textArray = [self.jzTime.dayArray objectAtIndex:2];

        } else if (self.jzScale >= 3.f) {

            self.timeView.textArray = [self.jzTime.dayArray objectAtIndex:3];

        }
    } else if ([self.timeLengthString isEqualToString:jzWeek]) {
        if (self.jzScale >= 1.f & self.jzScale < 3.f) {

            self.timeView.textArray = [self.jzTime.weekArray objectAtIndex:0];

        } else if (self.jzScale >= 3.f & self.jzScale < 4.5f) {

            self.timeView.textArray = [self.jzTime.weekArray objectAtIndex:1];

        } else if (self.jzScale >= 4.5f & self.jzScale < 6.f) {

            self.timeView.textArray = [self.jzTime.weekArray objectAtIndex:2];

        } else if (self.jzScale >= 6.f & self.jzScale < 9.f) {

            self.timeView.textArray = [self.jzTime.weekArray objectAtIndex:3];

        } else if (self.jzScale >= 9.f) {

            self.timeView.textArray = [self.jzTime.weekArray objectAtIndex:4];
        }
    } else if ([self.timeLengthString isEqualToString:jzMonth]) {
        if (self.jzScale >= 1.f & self.jzScale < 5.f / 4.f) {

            self.timeView.textArray = [self.jzTime.monthArray objectAtIndex:0];

        } else if (self.jzScale >= 5.f / 4.f & self.jzScale < 9.f / 4.f) {

            self.timeView.textArray = [self.jzTime.monthArray objectAtIndex:1];

        } else if (self.jzScale >= 9.f / 4.f & self.jzScale < 14.f / 4.f) {

            self.timeView.textArray = [self.jzTime.monthArray objectAtIndex:2];

        } else if (self.jzScale >= 14.f / 4.f & self.jzScale < 21.f / 4.f) {

            self.timeView.textArray = [self.jzTime.monthArray objectAtIndex:3];

        } else if (self.jzScale >= 21.f / 4.f) {

            self.timeView.textArray = [self.jzTime.monthArray objectAtIndex:4];

        }
    } else if ([self.timeLengthString isEqualToString:jzYear]) {
        
        if (self.jzScale >= 1.f & self.jzScale < 1.5f) {

            self.timeView.frame = CGRectMake(-frame.size.width / 24.f, 0, frame.size.width * 5.f / 4.f, frame.size.height);

            self.timeView.textArray = [self.jzTime.yearArray objectAtIndex:0];

        } else if (self.jzScale >= 1.5f & self.jzScale < 3.f) {

            self.timeView.frame = CGRectMake(-frame.size.width / 24.f, 0, frame.size.width * 7.f / 6.f, frame.size.height);

            self.timeView.textArray = [self.jzTime.yearArray objectAtIndex:1];

        } else if (self.jzScale >= 3.f) {

            self.timeView.frame = CGRectMake(-frame.size.width / 24.f, 0, frame.size.width * 13.f / 12.f, frame.size.height);

            self.timeView.textArray = [self.jzTime.yearArray objectAtIndex:2];

        }

    }
    
}

@end
