//
//  JZHealthServicesViewController.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZHealthServicesViewController.h"
#import "JZguanggaoViewController.h"
#import "JZhulizixunViewController.h"
#import "JZjiayizixunViewController.h"
#import "JZxianshangyaojuViewController.h"
#import "MZJTYSViewController.h"
#import "JZOperation.h"
#import "JZADModel.h"
#import "JZHealthServicesCollectionView.h"

#import "Utility.h"
#import "NSString+Hash.h"
#import <SafariServices/SafariServices.h>

@interface JZHealthServicesViewController () <JZPageControlViewDelegate, JZOperationDelegate, JZHealthServicesCollectionViewDelegate>

@property (nonatomic, strong) JZhulizixunViewController *hlzxVC;
@property (nonatomic, strong) JZjiayizixunViewController *jyzxVC;
@property (nonatomic, strong) MZJTYSViewController *jtysVC;
@property (nonatomic, strong) JZguanggaoViewController *ggVC;
@property (nonatomic, strong) JZxianshangyaojuViewController *xsyjVC;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) NSMutableArray *ADModelArray;
@property (nonatomic, strong) JZHealthServicesCollectionView *healthServicesCollectionView;

@end

@implementation JZHealthServicesViewController

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (NSMutableArray *)ADModelArray
{
    if (!_ADModelArray) {
        _ADModelArray = [NSMutableArray array];
    }
    return _ADModelArray;
}

- (JZHealthServicesCollectionView *)healthServicesCollectionView
{
    if (!_healthServicesCollectionView) {
        _healthServicesCollectionView = [[JZHealthServicesCollectionView alloc] initWithFrame:self.view.bounds];
        _healthServicesCollectionView.delegate = self;
        _healthServicesCollectionView.pageView.delegate = self;
    }
    return _healthServicesCollectionView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.healthServicesCollectionView];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"numbers"] = @"5";
    JZOperation *operation = [JZOperation operationWithURLString:healthServiceADURL andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
}

#pragma mark - JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSArray *resultArray = (NSArray *)responseObject[@"data"];
    if ([resultArray isKindOfClass:[NSArray class]]) {
        [self.ADModelArray removeAllObjects];
        for (NSDictionary *dict in resultArray) {
            JZADModel *ADModel = [JZADModel ADModelWithDict: dict];
            [self.ADModelArray addObject: ADModel];
        }
    }

    self.healthServicesCollectionView.pageView.ADModelArray = self.ADModelArray;
    [self.ADModelArray storeValueByKey:kADModelArray];
}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [LCProgressHUD showInfoMsg:@"广告加载失败"];
    }
}

#pragma mark - JZPageControlViewDelegate Methods
- (void)clickToguanggaoWithCurrentPage:(NSInteger)currentPage
{
    _ggVC = [[JZguanggaoViewController alloc] init];

    if (self.ADModelArray.count) {
        JZADModel *ADModel = self.ADModelArray[currentPage];
        _ggVC.urlString = [ADModel netUrl];
        NSLog(@"netUrl = %@", [ADModel netUrl]);
    }
    [self.tabBarController.navigationController pushViewController:_ggVC animated:YES];
}

#pragma mark - JZHealthServicesCollectionViewDelegate Method
- (void)healthServicesCollectionView:(JZHealthServicesCollectionView *)healthServicesCollectionView didSelectItemsAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.item == 0) {
        NSLog(@"jiayizixunAction");
        _jyzxVC = [[JZjiayizixunViewController alloc] init];
        [self.tabBarController.navigationController pushViewController:_jyzxVC animated:YES];

//        NSString *user_id = [[JZFamilyInfo valueByKey:kFamilyInfo] account];
//        NSDate *date = [NSDate date];
//        NSString *atime = [NSString stringWithFormat:@"%ld", (long)[date timeIntervalSince1970]];
//        NSString *partner = @"fushikang_h5";
//        NSString *partner_key = @"alsdj8da2x90sopn";
//        NSString *sign = [[NSString stringWithFormat:@"%@%@%@", partner_key, atime, user_id] md5String];
//        NSString *urlStr = [NSString stringWithFormat:@"%@?user_id=%@&partner=%@&atime=%@&sign=%@", chunyuyishengJYZXURL, user_id, partner, atime, sign];
//        SFSafariViewController *sfVC = [[SFSafariViewController alloc] initWithURL:[NSURL URLWithString:urlStr]];
//        sfVC.preferredBarTintColor = barBackgroundColor;
//        sfVC.preferredControlTintColor = [UIColor whiteColor];
//        self.tabBarController.navigationController.navigationBarHidden = YES;
//        [self.tabBarController.navigationController pushViewController:sfVC animated:YES];

    } else if (indexPath.item == 1) {
        NSLog(@"hulizixunAction");
        _hlzxVC = [[JZhulizixunViewController alloc] init];
        [self.tabBarController.navigationController pushViewController:_hlzxVC animated:YES];

    } else if (indexPath.item == 2) {
        NSLog(@"jiatingyaoshiAction");
        _jtysVC = [[MZJTYSViewController alloc] init];

        
        [self.tabBarController.navigationController pushViewController:_jtysVC animated:YES];
//        NSLog(@"xianshangguahaoAction");
//        [LCProgressHUD showInfoMsg:@"暂未开启，敬请期待"];
//    } else if (indexPath.item == 3) {
//        NSLog(@"xianshangyaojuAction");
//        [self.tabBarController.navigationController pushViewController: self.xsyjVC animated:YES];
//    } else if (indexPath.item == 4) {
//        NSLog(@"jiatingyaoshiAction");
//        [self.tabBarController.navigationController pushViewController: self.jtysVC animated:YES];
    }
}




























@end
