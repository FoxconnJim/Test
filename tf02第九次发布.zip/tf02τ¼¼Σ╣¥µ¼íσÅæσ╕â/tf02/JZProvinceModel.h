//
//  JZProvinceModel.h
//  tf02
//
//  Created by Jim on 2016/11/28.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZProvinceModel : NSObject
@property (nonatomic, copy) NSString *province;
@property (nonatomic, copy) NSArray *city;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)provinceModelWithDict:(NSDictionary *)dict;
@end
