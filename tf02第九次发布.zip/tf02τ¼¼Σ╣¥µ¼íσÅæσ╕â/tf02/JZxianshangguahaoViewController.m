//
//  JZxianshangguahaoViewController.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZxianshangguahaoViewController.h"
#import "Utility.h"

@interface JZxianshangguahaoViewController ()

@end

@implementation JZxianshangguahaoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"线上挂号";
}

@end
