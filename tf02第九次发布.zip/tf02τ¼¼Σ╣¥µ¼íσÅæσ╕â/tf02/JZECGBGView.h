//
//  JZECGBGView.h
//  tf02
//
//  Created by Jim on 2016/11/30.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZECGBGView : UIView
{
    CGFloat ratio;
    CGFloat smallSpace;
    CGFloat bigSpace;
    CGFloat space;
}

@end
