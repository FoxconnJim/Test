//
//  JZWeightView.h
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZLineChartView.h"

@interface JZWeightView : JZLineChartView
@property (nonatomic, copy) NSString *timeLengthString;

@end
