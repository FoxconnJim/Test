//
//  JZBodyFatView.m
//  tf02
//
//  Created by AN PEN on 4/8/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZBodyFatView.h"
#import "JZOperation.h"
#import "JZbodyFatData.h"
#import "NSString+Date.h"
#import "Utility.h"
#import "JZFmdbTool.h"

@interface JZBodyFatView () <JZOperationDelegate>

@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, copy) NSString *memberId;

@end
@implementation JZBodyFatView
- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundLayer.startColor = [UIColor colorWithRed:0.89 green:0.54 blue:0.24 alpha:1.00];
        self.backgroundLayer.endColor = [UIColor colorWithRed:0.76 green:0.25 blue:0.13 alpha:1.00];

        self.imgView.frame = CGRectMake(5, (frame.size.height / 24 + 10) / 2, frame.size.height / 6, frame.size.height / 8);

        self.titleLabel.text = @"体脂";
        self.jzType = @"体脂";

        [self.imgView setImage:[UIImage imageNamed: @"bodyFat"]];
        [self initUI];


    }
    return self;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;
    [self initTimeAndValueWithType:self.jzType];

    [self.queue cancelAllOperations];

    self.jzScale = 1.f;

    self.scrollView.contentSize = CGSizeMake(screenW - screenEdgeMargin * 2 - 5 * 2, self.dataView.frame.size.height);

//    [self initUI];
    
    NSMutableDictionary *param = [self paramWithTimeLengthString:timeLengthString];

    JZOperation *operation = [JZOperation operationWithURLString:bodyFatURL andParam:param getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = bodyFatOperation;

}

#pragma mark - JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSArray *arr = responseObject[@"data"];

    NSArray *array = (NSArray *)arr;

    [self handleDataWithArray:array success:YES];

    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [self initUI];

        NSArray *array = [JZFmdbTool queryBodyFatDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];

        [self handleDataWithArray:array success:NO];
    }

    [self.delegate endMJRefreshWithLineChartView:self];

}

- (void)handleDataWithArray:(NSArray *)array success:(BOOL)success
{

    NSMutableArray *pointArray = [NSMutableArray array];

    if ([array isKindOfClass: [NSArray class]]) {
        [self.bigDataArray removeAllObjects];

        if (array.count) {
            [self.indicatorLabel removeFromSuperview];

            [JZFmdbTool beginTransaction];
            @try {
                [self.dataArray removeAllObjects];
                if (success) {
                    [JZFmdbTool deleteBodyFatDataWithID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard] timeType:self.timeLengthString];
                }
                for (int i = 0; i < array.count; i++) {
                    JZBodyFatData *bodyFatData;
                    if (success) {
                        NSDictionary *dict = array[i];
                        bodyFatData = [JZBodyFatData dataWithDictionary: dict];
                        [JZFmdbTool insertBodyFatData:bodyFatData cardID:[[JZPersonInfo valueByKey:kCurrentFamilyMemberInfo] idCard]];
                    } else {
                        bodyFatData = array[i];
                    }

                    [self.dataArray addObject: bodyFatData];

                    JZDataPoint *dataPoint = [JZDataPoint dataPointWithMeatime:bodyFatData.meatime data:bodyFatData.data];
                    [pointArray addObject:dataPoint];
                }

            } @catch (NSException *exception) {
                [JZFmdbTool rollBack];
            } @finally {
                [JZFmdbTool commit];

            }


            JZPadHandleData2017 *padHandleData = [JZPadHandleData2017 dataWithArray:pointArray timeLengthString:self.timeLengthString];


            [self.bigDataArray addObject:padHandleData.totalArray];

            self.textArray = padHandleData.meatimeArray;

            //            JZHandleData *handleData = [JZHandleData dataWithArray:pointArray timeLengthString:self.timeLengthString];
            //            [self.bigDataArray addObject:handleData.dataArray];
            self.dataView.bigDataArray = self.bigDataArray;
            [self.scrollView addSubview:self.dataView];

            //            self.scaleView.timeLengthString = self.timeLengthString;
            //            [self.scrollView addSubview: self.scaleView];
            self.padScaleView.pointArray = padHandleData.totalArray;
            self.padScaleView.textArray = padHandleData.meatimeArray;
            self.padScaleView.timeLengthString = self.timeLengthString;

            [self.scrollView addSubview:self.padScaleView];
            // 细节显示
            self.maxValue.text = [NSString stringWithFormat:@"%0.1f", self.dataView.maxValue];
            self.minValue.text = [NSString stringWithFormat:@"%0.1f", self.dataView.minValue];
            if ([[[self.maxValue.text componentsSeparatedByString:@"."] lastObject] integerValue] == 0) {
                self.maxValue.text = [[self.maxValue.text componentsSeparatedByString:@"."] firstObject];
            }
            if ([[[self.minValue.text componentsSeparatedByString:@"."] lastObject] integerValue] == 0) {
                self.minValue.text = [[self.minValue.text componentsSeparatedByString:@"."] firstObject];
            }

        } else {
            [self initUI];
        }
    } else {
        [self initUI];
    }
}

- (void)initUI
{

    self.maxValue.text = @"";
    self.minValue.text = @"";
//    [self.scaleView removeFromSuperview];
    [self.padScaleView removeFromSuperview];

    [self.dataView removeFromSuperview];

    [self addSubview: self.indicatorLabel];
}

@end
