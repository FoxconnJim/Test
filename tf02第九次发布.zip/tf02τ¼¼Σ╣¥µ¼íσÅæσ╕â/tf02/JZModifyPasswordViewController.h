//
//  JZModifyPasswordViewController.h
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZModifyPasswordViewController : UIViewController

@property (nonatomic, copy) NSString *account;

@end
