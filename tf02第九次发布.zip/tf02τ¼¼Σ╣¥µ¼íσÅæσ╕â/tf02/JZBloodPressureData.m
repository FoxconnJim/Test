//
//  JZBloodPressureData.m
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZBloodPressureData.h"

@implementation JZBloodPressureData
- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super initWithDictionary:dict]) {
        self.bpDp = [NSString stringWithFormat:@"%@", dict[@"bpDp"]];
        self.bpSp = [NSString stringWithFormat:@"%@", dict[@"bpSp"]];
        self.bpHr = [NSString stringWithFormat:@"%@", dict[@"bpHr"]];
        self.physicalstate = [NSString stringWithFormat:@"%@", dict[@"physicalstate"]];
        if (self.physicalstate.integerValue == 0) {
            self.physicalstate = @"起床 (起床1小时内)";
        } else if (self.physicalstate.integerValue == 1) {
            self.physicalstate = @"睡前 (睡觉前半小时内)";
        } else if (self.physicalstate.integerValue == 2) {
            self.physicalstate = @"坐起 (平躺后坐起立即测血压)";
        } else if (self.physicalstate.integerValue == 3) {
            self.physicalstate = @"服药 (服降压药2小时内)";
        } else {
            self.physicalstate = @"其他 (除上述情况外正常测量)";
        }
    }
    return self;
}

@end
