//
//  JZProvinceModel.m
//  tf02
//
//  Created by Jim on 2016/11/28.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZProvinceModel.h"

@implementation JZProvinceModel
- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)provinceModelWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}
@end
