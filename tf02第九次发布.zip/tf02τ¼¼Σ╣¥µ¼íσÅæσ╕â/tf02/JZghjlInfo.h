//
//  JZghjlInfo.h
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZghjlInfo : NSObject

@property (nonatomic, copy) NSString *formNumber;
@property (nonatomic, copy) NSString *patientName;
@property (nonatomic, copy) NSString *hospital;
@property (nonatomic, copy) NSString *time;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *doctorName;
@property (nonatomic, copy) NSString *cost;
@property (nonatomic, copy) NSString *payWay;
@property (nonatomic, copy) NSString *info;
@property (nonatomic, copy) NSString *status;

- (instancetype)initWithDict: (NSDictionary *)dict;
+ (instancetype)ghjlInfoWithDict: (NSDictionary *)dict;

@end
