//
//  NSArray+JZRemoveByInteval.m
//  tf02
//
//  Created by F7686324 on 2017/1/4.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "NSArray+JZRemoveByInteval.h"

@implementation NSArray (JZRemoveByInteval)
- (NSMutableArray *)removeByInteval:(NSInteger)inteval
{
    NSMutableArray *array = [NSMutableArray array];
    if (self.count > inteval) {
        for (NSInteger i = inteval; i < self.count - inteval; i = i + inteval + 1) {
            NSString *str = [self objectAtIndex:i];
            [array addObject:str];
        }
    }
    return array;
}

@end
