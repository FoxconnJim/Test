//
//  JZBloodPressureData.h
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZData.h"

@interface JZBloodPressureData : JZData

@property (nonatomic, copy) NSString *bpSp;
@property (nonatomic, copy) NSString *bpDp;
@property (nonatomic, copy) NSString *bpHr;

@end
