//
//  NSDate+local.h
//  tf02
//
//  Created by AN PEN on 7/15/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (local)

- (NSDate *)localDate;

@end
