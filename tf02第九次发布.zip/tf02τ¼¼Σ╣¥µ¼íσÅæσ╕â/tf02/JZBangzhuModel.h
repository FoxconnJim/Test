//
//  JZBangzhuModel.h
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZBangzhuModel : NSObject

@property (nonatomic, copy) NSString *helpTitle;
@property (nonatomic, copy) NSString *helpContent;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)bangzhuModelWithDict:(NSDictionary *)dict;


@end
