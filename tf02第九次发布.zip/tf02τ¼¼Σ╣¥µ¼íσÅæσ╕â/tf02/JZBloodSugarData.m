//
//  JZBloodSugarData.m
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZBloodSugarData.h"

@implementation JZBloodSugarData

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super initWithDictionary:dict]) {
        self.data = [NSString stringWithFormat:@"%0.1f", [dict[@"gludata"] floatValue]];
        if ([[[self.data componentsSeparatedByString:@"."] lastObject] integerValue] == 0) {
            self.data = [[self.data componentsSeparatedByString:@"."] firstObject];
        }

        self.physicalstate = [NSString stringWithFormat:@"%@", dict[@"physicalstate"]];
        if (self.physicalstate.integerValue == 0) {
            self.physicalstate = @"空腹 (隔夜空腹8-10小时未进食)";
        } else if (self.physicalstate.integerValue == 1) {
            self.physicalstate = @"餐后 (进食第一口开始餐后半小时)";
        } else {
            self.physicalstate = @"其他 (除上述情况外正常测量)";
        }
    }
    return self;
}
@end
