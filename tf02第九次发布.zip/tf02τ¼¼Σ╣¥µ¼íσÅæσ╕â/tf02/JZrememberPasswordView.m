//
//  JZrememberPasswordView.m
//  tf02
//
//  Created by F7686324 on 02/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZrememberPasswordView.h"

@implementation JZrememberPasswordView

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.height, self.frame.size.height)];
        _imgView.layer.borderColor = [UIColor whiteColor].CGColor;
        _imgView.layer.cornerRadius = 5;
        _imgView.layer.borderWidth = 2;
    }
    return _imgView;
}

- (UILabel *)lbl
{
    if (!_lbl) {
        _lbl = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.height, 0, self.frame.size.width - self.frame.size.height, self.frame.size.height)];
        _lbl.text = @"记住密码";
        _lbl.textAlignment = NSTextAlignmentCenter;
        _lbl.textColor = [UIColor whiteColor];
        _lbl.font = [UIFont systemFontOfSize:14];
    }
    return _lbl;
}

- (UIButton *)btn
{
    if (!_btn) {
        _btn = [[UIButton alloc] initWithFrame:self.bounds];
    }
    return _btn;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.imgView];
        [self addSubview:self.lbl];
        [self addSubview:self.btn];
    }
    return self;
}

@end
