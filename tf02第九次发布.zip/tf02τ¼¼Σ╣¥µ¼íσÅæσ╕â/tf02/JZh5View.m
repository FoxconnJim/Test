//
//  JZh5View.m
//  tf02
//
//  Created by Jim on 16/8/18.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZh5View.h"
#import <JavaScriptCore/JavaScriptCore.h>


@interface JZh5View () <WKScriptMessageHandler, WKUIDelegate, WKNavigationDelegate, UIScrollViewDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate>

@property (nonatomic, strong) UIProgressView *progressView;
@property (nonatomic, strong) UIButton *noNetView;
//@property (nonatomic, strong) UIImagePickerController *imagePickerController;

@end

@implementation JZh5View
{
    BOOL _isFirstLoad;
}

//- (UIImagePickerController *)imagePickerController
//{
//    if (!_imagePickerController) {
//        _imagePickerController = [[UIImagePickerController alloc] init];
//        _imagePickerController.delegate = self;
//        _imagePickerController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
//        _imagePickerController.allowsEditing = YES;
//    }
//    return _imagePickerController;
//}

- (void)setIsCamera:(BOOL)isCamera
{
    _isCamera = isCamera;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
        
    }
    return _queue;
}

- (UIButton *)noNetView
{
    if (!_noNetView) {
        UIButton *noNetView = [[UIButton alloc] initWithFrame:self.bounds];
        noNetView.backgroundColor = [UIColor whiteColor];
        noNetView.contentMode = UIViewContentModeCenter;
        [noNetView setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [noNetView setTitle:@"网络故障，点击刷新" forState:UIControlStateNormal];
        noNetView.titleLabel.font = [UIFont systemFontOfSize:15];
        [noNetView addTarget:self action:@selector(reload) forControlEvents:UIControlEventTouchUpInside];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Failure"]];
        imageView.center = CGPointMake(noNetView.center.x, noNetView.center.y - 30);
        [noNetView addSubview:imageView];
        noNetView.hidden = YES;
        _noNetView = noNetView;
    }
    return _noNetView;
}

- (WKWebView *)webView
{
    if (!_webView) {
//        CGFloat width = [[UIScreen mainScreen]bounds].size.width;
////        NSString *jsPath = [[NSBundle mainBundle] pathForResource:@"h5View" ofType:@"js"];
////        NSString *jsstr = [NSString stringWithContentsOfFile:jsPath encoding:NSUTF8StringEncoding error:nil];
//        NSString *jsStr = [NSString stringWithFormat:@"var script = document.createElement('script');"
//                           "script.type = 'text/javascript';"
//                           "script.text = \"function ResizeImages() { "
//                           "var myimg,oldwidth,i;"
//                           "var maxwidth = '%f;" //自定义宽度
//                           "for(i=0;i <document.images.length;i++){"
//                           "myimg = document.images[i];"
//                           "if(myimg.width > maxwidth){"
//                           "oldwidth = myimg.width;"
//                           "myimg.width = maxwidth;"
//                           "}"
//                           "}"
//                           "}\";"
//                           "document.getElementsByTagName('head')[0].appendChild(script);"
//                           "ResizeImages();",width * 0.5];
//        WKUserScript *script = [[WKUserScript alloc] initWithSource:jsStr injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
//
//        // 根据生成的WKUserScript对象，初始化WKWebViewConfiguration
//        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
//        [config.userContentController addUserScript:script];

        // js配置
        WKUserContentController *userContentController = [[WKUserContentController alloc] init];
        [userContentController addScriptMessageHandler:self name:@"jsCallOC"];

        // WKWebView的配置
        WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
        config.userContentController = userContentController;
        _webView = [[WKWebView alloc] initWithFrame:self.bounds configuration:config];
        _webView.UIDelegate = self;
        _webView.contentMode = UIViewContentModeRedraw;
        _webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        _webView.navigationDelegate = self;

        _webView.allowsBackForwardNavigationGestures = YES;
        [_webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew| NSKeyValueObservingOptionOld context:nil];
        _webView.scrollView.bounces = NO;
//        _webView.scrollView.bouncesZoom = NO;
        _webView.scrollView.delegate = self;
        _webView.multipleTouchEnabled = NO;

    }
    return _webView;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return nil;
}

- (UIProgressView *)progressView
{
    if (!_progressView) {
        _progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, 0, screenW, 3.f)];
        _progressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    }
    return _progressView;
}
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
//    NSLog(@" %s,change = %@",__FUNCTION__,change);
    if ([keyPath isEqual: @"estimatedProgress"] && object == self.webView) {
        [self.progressView setAlpha:1.0f];
        [self.progressView setProgress:self.webView.estimatedProgress animated:YES];
        if(self.webView.estimatedProgress >= 1.0f)
        {
            [UIView animateWithDuration:0.3 delay:0.3 options:UIViewAnimationOptionCurveEaseOut animations:^{
                [self.progressView setAlpha:0.0f];
            } completion:^(BOOL finished) {
                [self.progressView setProgress:0.0f animated:NO];
            }];
        }
    }
    else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

/*
#pragma mark WKScriptMessageHandler
//- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
//{
//
//}

#pragma mark WKUIDelegate Methods
/// 创建一个新的WebView
//- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures
//{
//    return self.webView;
//}
///// 输入框
//- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * __nullable result))completionHandler
//{
//
//}
///// 确认框
//- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL result))completionHandler
//{
//
//}
///// 警告框
//- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler
//{
//
//}
*/

#pragma mark 图片保存完毕的回调
- (void)image:(UIImage *) image didFinishSavingWithError:(NSError *) error contextInfo:(void *)contextInf {
    NSLog(@"%s", __FUNCTION__);
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(nullable NSDictionary<NSString *,id> *)editingInfo
{
    NSLog(@"%s", __FUNCTION__);

}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    NSLog(@"%s", __FUNCTION__);

}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    NSLog(@"%s", __FUNCTION__);

}

#pragma mark WKNavigationDelegate Methods
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation
{
    self.noNetView.hidden = YES;
    NSLog(@"webView.URL = %@", webView.URL);

}
// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation
{
    [self.progressView setProgress:webView.estimatedProgress animated:YES];

}
// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    _isFirstLoad = NO;
    [self.progressView setProgress:webView.estimatedProgress animated:YES];

}
// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation
{
    self.noNetView.hidden = NO;
    [LCProgressHUD showInfoMsg:@"网络有点卡..."];
}

// 接收到服务器跳转请求之后调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation
{
    NSLog(@"接收到服务器跳转请求之后调用webView.URL = %@", webView.URL);

}

// 在收到响应后，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler
{
//    
//    NSString *url = [[webView.URL.absoluteString componentsSeparatedByString:@"?"] firstObject];
////    NSLog(@"收到响应webView.URL = %@", url);
//    NSLog(@"收到响应webView.URL = %@", webView.URL.absoluteString);
//    if ([url isEqualToString:@"https://www.chunyuyisheng.com/cooperation/wap/create_free_problem_page/"]) {
//        NSLog(@"isCamera = YES");
//        self.isCamera = YES;
//    } else {
//        NSLog(@"isCamera = NO");
//
////        isCamera = NO;
//    }
//
//
//    if (self.isCamera) {
//        NSLog(@"isCamera");
//        if ([url isEqualToString:@"https://www.chunyuyisheng.com/cooperation/wap/login/"]) {
//            decisionHandler(WKNavigationResponsePolicyCancel);
//        } else {
//            decisionHandler(WKNavigationResponsePolicyAllow);
//
//        }
//    } else {
//        NSLog(@"isNotCamera");
//
//        decisionHandler(WKNavigationResponsePolicyAllow);
//
//    }

    decisionHandler(WKNavigationResponsePolicyAllow);

}


// 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    NSLog(@"发送请求webView.URL = %@", [[webView.URL.absoluteString componentsSeparatedByString:@"?"] firstObject]);
    NSString *urlString = [[navigationAction.request URL] absoluteString];

    urlString = [urlString stringByRemovingPercentEncoding];
    //    NSLog(@"urlString=%@",urlString);
    // 用://截取字符串
    NSArray *urlComps = [urlString componentsSeparatedByString:@"://"];
    if ([urlComps count]) {
        // 获取协议头
        NSString *protocolHead = [urlComps objectAtIndex:0];
        NSLog(@"protocolHead=%@",protocolHead);
    }
    decisionHandler(WKNavigationActionPolicyAllow);
}

- (UIActivityIndicatorView *)aiView
{
    if (!_aiView) {
        _aiView = [[UIActivityIndicatorView alloc] initWithFrame:self.bounds];
        _aiView.activityIndicatorViewStyle = UIActivityIndicatorViewStyleGray;
    }
    return _aiView;
    
}

- (void)setUrlString:(NSString *)urlString
{
    _urlString = urlString;
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL: url];
    [self.webView loadRequest: request];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _isFirstLoad = YES;
        self.isCamera = NO;

        [self addSubview:self.webView];

        [self addSubview:self.progressView];

        [self addSubview:self.noNetView];


//        if (_bridge) {
//            return 0;
//        }
//
//        [WebViewJavascriptBridge enableLogging];
//
//        _bridge = [WebViewJavascriptBridge bridgeForWebView:self.webView];
//
//        [_bridge setWebViewDelegate:self];
//
//        [_bridge registerHandler:@"testObjcCallback" handler:^(id data, WVJBResponseCallback responseCallback) {
//            NSLog(@"testObjcCallback called: %@", data);
//            responseCallback(@"Response from testObjcCallback");
//        }];
//
//        [_bridge callHandler:@"testJavascriptHandler" data:@{ @"foo":@"before ready" }];
//
//        [self renderButtons:self.webView];

    }
    return self;
}


- (void)dealloc
{
    [self.webView removeObserver:self forKeyPath:@"estimatedProgress"];

    // if you have set either WKWebView delegate also set these to nil here
    [self.webView setNavigationDelegate:nil];
    [self.webView setUIDelegate:nil];
    self.webView.scrollView.delegate = nil;
}


- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
{
    NSLog(@"方法名:%@", message.name);
    NSLog(@"参数:%@", message.body);
    // 方法名
    NSString *methods = [NSString stringWithFormat:@"%@:", message.name];
    SEL selector = NSSelectorFromString(methods);
    // 调用方法
    if ([self respondsToSelector:selector]) {
        [self performSelector:selector withObject:message.body];
    } else {
        NSLog(@"未实行方法：%@", methods);
    }
}


@end
