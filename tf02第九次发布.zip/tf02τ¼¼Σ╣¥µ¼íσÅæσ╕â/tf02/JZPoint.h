//
//  JZPoint.h
//  tf02
//
//  Created by F7686324 on 01/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JZPoint : NSObject

@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;

- (instancetype)initWithX:(CGFloat)x y:(CGFloat)y;
+ (instancetype)pointWithX:(CGFloat)x y:(CGFloat)y;

@end
