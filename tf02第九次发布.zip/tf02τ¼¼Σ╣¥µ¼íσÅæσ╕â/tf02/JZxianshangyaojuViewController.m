//
//  JZxianshangyaojuViewController.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZxianshangyaojuViewController.h"
#import "Utility.h"
#import "JZh5View.h"
#import "JZGoBackView.h"

#import "NSString+Hash.h"
#import "NSString+Date.h"


@interface JZxianshangyaojuViewController ()

@property (nonatomic, strong) JZh5View *h5View;
@property (nonatomic, strong) JZGoBackView *goBackView;

@end

@implementation JZxianshangyaojuViewController

- (JZh5View *)h5View
{
    if (!_h5View) {
        _h5View = [[JZh5View alloc] initWithFrame: CGRectMake(0, 0, screenW, screenH - statusBarHeight - naviHeight)];

//        NSString *user_id = @"test";
//        NSDate *date = [NSDate date];
//        NSString *atime = [NSString stringWithFormat:@"%ld", (long)[date timeIntervalSince1970]];
//
//        NSString *partner = @"fushikang_h5";
//        NSString *partner_key = @"alsdj8da2x90sopn";
//        NSString *sign = [[NSString stringWithFormat:@"%@%@%@", partner_key, atime, user_id] md5String];
//        NSString *urlStr = [NSString stringWithFormat:@"%@?user_id=%@&partner=%@&atime=%@&sign=%@", chunyuyishengJYZXURL, user_id, partner, atime, sign];
//        _h5View.urlString = xianshangyaojuURL;
    }
    return _h5View;
}

- (JZGoBackView *)goBackView
{
    if (!_goBackView) {
        _goBackView = [[JZGoBackView alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
        [_goBackView.backBtn addTarget: self action:@selector(clickGoBack) forControlEvents:UIControlEventTouchUpInside];
        [_goBackView.closeBtn addTarget: self action:@selector(clickClose) forControlEvents:UIControlEventTouchUpInside];
    }
    return _goBackView;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear: animated];
    JZGoBackView *backView = [[JZGoBackView alloc] initWithFrame:CGRectMake(0, 0, 100, 44)];
    [backView.closeBtn removeFromSuperview];
    [backView.backBtn addTarget:self action:@selector(clickToBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backView];
    self.navigationItem.leftBarButtonItem = backBarButtonItem;
//    NSString *user_id = @"test";
//    NSDate *date = [NSDate date];
//    NSString *atime = [NSString stringWithFormat:@"%ld", (long)[date timeIntervalSince1970]];
//    NSString *partner = @"fushikang_h5";
//    NSString *partner_key = @"alsdj8da2x90sopn";
//    NSString *sign = [[NSString stringWithFormat:@"%@%@%@", partner_key, atime, user_id] md5String];
//    NSString *urlStr = [NSString stringWithFormat:@"%@?user_id=%@&partner=%@&atime=%@&sign=%@", chunyuyishengJYZXURL, user_id, partner, atime, sign];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"线上药局";
    [self.view addSubview: self.h5View];

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.h5View.urlString = xianshangyaojuURL;

}

- (void)clickToBack
{
    NSLog(@"clickToBack");
    if (self.h5View.webView.canGoBack) {
        [self.h5View.webView goBack];
        UIBarButtonItem *backBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.goBackView];
        self.navigationItem.leftBarButtonItem = backBarButtonItem;
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)clickGoBack
{
    NSLog(@"clickGoBack");
    if (self.h5View.webView.canGoBack) {
        [self.h5View.webView goBack];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)clickClose
{
    NSLog(@"clickClose");
    [self.navigationController popViewControllerAnimated:YES];
}
@end
