//
//  JZWeatherFrame.h
//  tf02
//
//  Created by Jim on 16/3/12.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JZWeatherFrame : NSObject

@property (nonatomic, assign) CGRect frame;
@property (nonatomic, assign) CGRect weatherImageFrame;
@property (nonatomic, assign) CGRect leftImageFrame;
@property (nonatomic, assign) CGRect midFrame;
@property (nonatomic, assign) CGRect rightImageFrame;
@property (nonatomic, assign) CGRect weatherLabelFrame;
@property (nonatomic, assign) CGRect tempFrame;
@property (nonatomic, assign) CGRect windFrame;

@property (nonatomic, assign) CGRect temFrame;
@property (nonatomic, assign) CGRect winFrame;
@property (nonatomic, assign) CGRect humidityFrame;

@property (nonatomic, assign) CGRect locationFrame;

@end
