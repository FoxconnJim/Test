//
//  JZHPwodejiatingViewController.h
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZHPwodejiatingViewController : UIViewController

@property (nonatomic, strong) NSMutableArray *personInfoArray;

@end
