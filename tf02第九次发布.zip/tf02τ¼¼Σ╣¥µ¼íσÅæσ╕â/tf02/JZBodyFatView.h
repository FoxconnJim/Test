//
//  JZBodyFatView.h
//  tf02
//
//  Created by AN PEN on 4/8/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZLineChartView.h"

@interface JZBodyFatView : JZLineChartView
@property (nonatomic, copy) NSString *timeLengthString;

@end
