//
//  NSArray+JZOrderByTime.h
//  tf02
//
//  Created by F7686324 on 2016/12/20.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (JZOrderByTime)

- (NSArray *)orderByTime;

@end
