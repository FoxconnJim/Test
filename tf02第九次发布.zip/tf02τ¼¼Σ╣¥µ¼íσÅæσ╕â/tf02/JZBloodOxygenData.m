//
//  JZBloodOxygenData.m
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZBloodOxygenData.h"

@implementation JZBloodOxygenData
- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super initWithDictionary:dict]) {
        self.data = [NSString stringWithFormat:@"%d", (int)([dict[@"rsp02data"] floatValue] * 100)];
        self.physicalstate = [NSString stringWithFormat:@"%@", dict[@"physicalstate"]];
        if (self.physicalstate.integerValue == 0) {
            self.physicalstate = @"刚起床 (起床立即测量)";
        } else if (self.physicalstate.integerValue == 1) {
            self.physicalstate = @"睡前 (睡觉前半小时)";
        } else if (self.physicalstate.integerValue == 2) {
            self.physicalstate = @"运动后 (运动后身心还未平稳)";
        } else {
            self.physicalstate = @"其他 (除上述情况外正常测量)";
        }
    }
    return self;
}

@end
