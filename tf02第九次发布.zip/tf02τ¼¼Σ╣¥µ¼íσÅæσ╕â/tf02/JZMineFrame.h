//
//  JZMineFrame.h
//  tf02
//
//  Created by Jim on 16/3/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZMineFrame : NSObject

@property (nonatomic, assign) CGRect iconImgFrame;
@property (nonatomic, assign) CGRect iconNameFrame;
@property (nonatomic, assign) CGRect tbViewFrame;
@property (nonatomic, assign) CGRect cellFrame;

@end
