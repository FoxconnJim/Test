//
//  JZHealthDetailECGViewController.m
//  tf02
//
//  Created by AN PEN on 6/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHealthDetailECGViewController.h"


@interface JZHealthDetailECGViewController ()


@end

@implementation JZHealthDetailECGViewController

- (UISegmentedControl *)segment
{
    if (!_segment) {
        _segment = [[UISegmentedControl alloc] initWithFrame:CGRectMake(screenEdgeMargin, 10, screenW - screenEdgeMargin * 2, 30)];
        _segment.tintColor = barBackgroundColor;
        [_segment insertSegmentWithTitle:@"20mm/mV" atIndex:0 animated:NO];
        [_segment insertSegmentWithTitle:@"10mm/mV" atIndex:1 animated:NO];
        [_segment insertSegmentWithTitle:@"5mm/mV" atIndex:2 animated:NO];
        _segment.selectedSegmentIndex = 1;
        [_segment addTarget:self action:@selector(selectSegment:) forControlEvents:UIControlEventValueChanged];
    }
    return _segment;
}

- (UILabel *)lblUnit
{
    if (!_lblUnit) {
        _lblUnit = [[UILabel alloc] initWithFrame:CGRectMake(screenW - ratio * 2 - 10, 50, ratio * 2, ratio / 4)];
        _lblUnit.text = @"10mm/mV, 25mm/s";
        _lblUnit.textAlignment = NSTextAlignmentCenter;
        _lblUnit.adjustsFontSizeToFitWidth = YES;
    }
    return _lblUnit;
}

- (UILabel *)lblTurns
{
    if (!_lblTurns) {
        _lblTurns = [[UILabel alloc] initWithFrame: CGRectMake(0, 50, 50, ratio / 4)];
        _lblTurns.textAlignment = NSTextAlignmentCenter;
        _lblTurns.adjustsFontSizeToFitWidth = YES;
    }
    return _lblTurns;
}

- (JZECGScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[JZECGScrollView alloc] initWithFrame:CGRectMake(0, 50, screenW, screenH - statusBarHeight - naviHeight - 50)];
        [_scrollView addSubview:self.dataView];

    }
    return _scrollView;
}

- (JZECGDataView *)dataView
{
    if (!_dataView) {
        _dataView = [[JZECGDataView alloc] initWithFrame:CGRectZero];
        _dataView.type = @"10mm/mV,25mm/s";

    }
    return _dataView;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        ratio = 64;
        space = ratio / 60;

    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"心电图详情";
    [self.view addSubview: self.segment];

    [self.view addSubview:self.scrollView];
    [self.view addSubview: self.lblUnit];
    [self.view addSubview: self.lblTurns];

    NSArray *gestureArray = self.navigationController.view.gestureRecognizers;
    for (UIGestureRecognizer *gestureRecoginzer in gestureArray) {
        if ([gestureRecoginzer isKindOfClass:[UIScreenEdgePanGestureRecognizer class]]) {
            [self.scrollView.panGestureRecognizer requireGestureRecognizerToFail:gestureRecoginzer];
        }
    }
}

- (void)setArray:(NSMutableArray *)array
{
    _array = array;
    self.scrollView.contentSize = CGSizeMake(array.count * space, screenH - statusBarHeight - naviHeight - 50);
    self.dataView.jzHeight = screenH - statusBarHeight - naviHeight - 50;
    self.dataView.dataArray = array;
    NSLog(@"dataView.frame = %@", NSStringFromCGRect(self.dataView.frame));
    self.segment.selectedSegmentIndex = 1;
}

- (void)selectSegment: (UISegmentedControl *)sender
{
    if (sender.selectedSegmentIndex == 0) {
        self.dataView.type = @"20mm/mV,50mm/s";
        self.lblUnit.text = @"20mm/mV,50mm/s";
        space = ratio / 60 * 2;

    } else if (sender.selectedSegmentIndex == 1) {
        self.dataView.type = @"10mm/mV,25mm/s";
        self.lblUnit.text = @"10mm/mV,25mm/s";
        space = ratio / 60;

    } else if (sender.selectedSegmentIndex == 2) {
        self.dataView.type = @"5mm/mV,12.5mm/s";
        self.lblUnit.text = @"5mm/mV,12.5mm/s";
        space = ratio / 60 / 2;

    }
    self.dataView.dataArray = self.array;
    self.scrollView.contentSize = CGSizeMake(self.array.count * space, screenH - statusBarHeight - naviHeight - 50);
}


@end
