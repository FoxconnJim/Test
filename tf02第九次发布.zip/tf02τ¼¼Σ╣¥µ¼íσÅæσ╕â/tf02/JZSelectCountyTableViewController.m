//
//  JZSelectCountyTableViewController.m
//  tf02
//
//  Created by F7686324 on 16/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZSelectCountyTableViewController.h"
#import "Utility.h"
#import "JZCityModel.h"
#import "NSString+JZChineseToPinyin.h"

@interface JZSelectCountyTableViewController ()
@property (nonatomic, strong) NSMutableArray *districtArray;
@property (nonatomic, strong) NSMutableArray *indexArray;
@property (nonatomic, strong) NSMutableDictionary *dataDictionary;
@end

@implementation JZSelectCountyTableViewController

- (NSMutableArray *)districtArray
{
    if (!_districtArray) {
        _districtArray = [NSMutableArray array];
    }
    return _districtArray;
}

- (NSMutableArray *)indexArray
{
    if (!_indexArray) {
        _indexArray = [NSMutableArray array];
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            [_indexArray addObject:[NSString stringWithFormat:@"%c", ch]];
        }
    }
    return _indexArray;
}

- (NSMutableDictionary *)dataDictionary
{
    if (!_dataDictionary) {
        _dataDictionary = [NSMutableDictionary dictionary];
    }
    return _dataDictionary;
}

- (void)setJzCityModel:(JZCityModel *)jzCityModel
{
    _jzCityModel = jzCityModel;
    NSArray *districtArray = jzCityModel.district;
    if ([districtArray isKindOfClass:[NSArray class]]) {
        [self.districtArray removeAllObjects];
        for (NSDictionary *districtDict in districtArray) {
            NSString *district = districtDict[@"district"];
            [self.districtArray addObject:district];
        }
        NSMutableArray *indexArr = [NSMutableArray array];
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            [indexArr addObject:[NSString stringWithFormat:@"%c", ch]];
        }
        
        NSMutableDictionary *dataDict = [NSMutableDictionary dictionary];
        for (NSString *charStr in indexArr) {
            NSMutableArray *array = [NSMutableArray array];
            [dataDict setObject:array forKey:charStr];
        }
        
        for (NSString *district in self.districtArray) {
            NSString *firstLetter = [[[district chineseToPinyin] substringToIndex:1] uppercaseString];
            NSMutableArray *array = dataDict[firstLetter];
            [array addObject:district];
        }
        
        self.dataDictionary = [dataDict mutableCopy];
        [dataDict enumerateKeysAndObjectsUsingBlock:^(id key,id obj, BOOL *stop) {
            obj = [[obj sortedArrayUsingComparator:^NSComparisonResult(NSString *obj1, NSString *obj2)
                    {
                        NSComparisonResult result = [[[obj1 chineseToPinyin] lowercaseString] compare:[[obj2 chineseToPinyin] lowercaseString]];
                        return result == NSOrderedDescending;// 升序
                    }]mutableCopy];
            [self.dataDictionary setObject:obj forKey:key];
        }];
        
        for (int i = 0; i < indexArr.count; i++) {
            NSString *charStr = indexArr[i];
            NSMutableArray *array = self.dataDictionary[charStr];
            NSLog(@"charStr = %@", charStr);
            if (!array.count) {
                [self.indexArray removeObject:charStr];
                [self.dataDictionary removeObjectForKey:charStr];
            }
        }
        [self.tableView reloadData];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选择县级市";

}

#pragma mark UITableViewDelegate && UITableViewDataSource methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *key = self.indexArray[section];
    NSMutableArray *array = self.dataDictionary[key];
    return array.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.indexArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"ProvinceCellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }

    NSString *key = self.indexArray[indexPath.section];
    NSMutableArray *array = self.dataDictionary[key];
    NSString *district = array[indexPath.row];
    cell.textLabel.text = district;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *key = self.indexArray[indexPath.section];
    NSMutableArray *array = self.dataDictionary[key];
    NSString *district = array[indexPath.row];
    NSMutableDictionary *selectedAddressDict = [NSMutableDictionary valueByKey:kSelectedAddressDict];
    selectedAddressDict[@"city"] = district;
    [selectedAddressDict storeValueByKey:kSelectedAddressDict];
    [[NSNotificationCenter defaultCenter] postNotificationName:updateSelectedCityNotification object:nil];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return self.indexArray[section];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return self.indexArray;
}


@end
