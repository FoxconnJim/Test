//
//  JZRemindEventViewController.m
//  tf02
//
//  Created by F7686324 on 12/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZRemindEventViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "JZNaoZhongView.h"
#import <EventKit/EventKit.h>
#import "EventManger.h"
#import "JZRemindEvent.h"
#import "NSObject+JZEKEvent.h"
#import "NSMutableArray+JZArrayToRemindRepeat.h"

@interface JZRemindEventViewController () <JZNaoZhongViewDelegate, UITextFieldDelegate>

@property (nonatomic, strong) JZNaoZhongView *naozhongView;
@property (nonatomic, strong) NSMutableArray *btnBGArray;
@property (nonatomic, copy) NSString *jzRemindInfo;
@property (nonatomic, strong) NSDate *jzRemindDate;
@property (nonatomic, strong) JZRemindEvent *remindEvent;
@property (nonatomic, strong) NSDateFormatter *dateFormatter;
@property (nonatomic, copy) NSString *timeString;

@end

@implementation JZRemindEventViewController

- (JZNaoZhongView *)naozhongView
{
    if (!_naozhongView) {
        _naozhongView = [[JZNaoZhongView alloc] initWithFrame:self.view.bounds];
        _naozhongView.delegate = self;
        for (int i = 0; i < 7; i++) {
            UIButton *btn = _naozhongView.selectWeekDayView.btnArray[i];
            [btn addTarget:self action:@selector(selectWeekDayAction:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    return _naozhongView;
}

- (JZRemindEvent *)remindEvent
{
    if (!_remindEvent) {
        _remindEvent = [[JZRemindEvent alloc] init];
    }
    return _remindEvent;
}

- (NSDateFormatter *)dateFormatter
{
    if (!_dateFormatter) {
        _dateFormatter = [[NSDateFormatter alloc] init];
        [_dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];

    }
    return _dateFormatter;
}

- (void)viewDidLoad {

    [super viewDidLoad];
    self.title = @"提醒设置";
    self.jzRemindInfo = @"测量提醒";
    self.jzRemindDate = [self.dateFormatter dateFromString:[NSString stringWithFormat:@"%@:00", [[[[NSDate date] localDate] dateToString] substringToIndex:16]]];
    self.btnBGArray = [NSMutableArray arrayWithObjects:@"normal", @"normal", @"normal", @"normal", @"normal", @"normal", @"normal", nil];

    [self.view addSubview:self.naozhongView];
    UIBarButtonItem *cancelItem = [[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(cancelAction)];
    UIBarButtonItem *storeItem = [[UIBarButtonItem alloc] initWithTitle:@"存储" style:UIBarButtonItemStylePlain target:self action:@selector(storeAction)];
    self.navigationItem.leftBarButtonItem = cancelItem;
    self.navigationItem.rightBarButtonItem = storeItem;

}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];

}

- (void)cancelAction
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)storeAction
{
    NSDateComponents *componets = [[NSCalendar currentCalendar] components:(NSCalendarUnitWeekday | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitYear | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond) fromDate:[NSDate date]];
    NSInteger weekday = componets.weekday;  //1代表星期日，2代表星期一，后面依次
    NSInteger currentweek = 0;
    switch (weekday) {
        case 1:
            currentweek = 6;
            break;
        case 2:
            currentweek = 0;
            break;
        case 3:
            currentweek = 1;
            break;
        case 4:
            currentweek = 2;
            break;
        case 5:
            currentweek = 3;
            break;
        case 6:
            currentweek = 4;
            break;
        case 7:
            currentweek = 5;
            break;
        default:
            break;
    }
    for (NSInteger selectweek = 0; selectweek < self.btnBGArray.count; selectweek++) {
        NSString *str = [self.btnBGArray objectAtIndex:selectweek];
        if ([str isEqualToString:@"selected"]) {
            self.jzRemindDate = [NSDate dateWithTimeIntervalSince1970:[self.jzRemindDate timeIntervalSince1970] + 60 * 60 * 24 * (selectweek - currentweek)];

            break;
        }
    }

    if ([self.jzRemindDate timeIntervalSince1970] < [[NSDate date] timeIntervalSince1970] && [[self.btnBGArray arrayToRemindRepeat] isEqualToString:@"今天"]) {
        [LCProgressHUD showInfoMsg:@"您要设置的提醒时间已过"];
    } else {

        EKEvent *newEvent = [NSObject eventWithRemindInfo:self.jzRemindInfo remindDate:self.jzRemindDate remindRepeatArray:self.btnBGArray];
        [[EventManger shareInstance] createEvent:newEvent];

        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[@"remindTime"] = self.jzRemindDate;
        dict[@"remindInfo"] = self.jzRemindInfo;
        dict[@"remindRepeat"] = self.btnBGArray;
        dict[@"remindIdentifier"] = newEvent.eventIdentifier;

        JZRemindEvent *remindEvent = [JZRemindEvent remindEventWithDict:dict];

        NSMutableArray *remindEventArray = [NSMutableArray valueByKey:kremindEvent];
        if (!remindEventArray) {
            remindEventArray = [NSMutableArray array];
        }
        [remindEventArray addObject:remindEvent];
        [remindEventArray storeValueByKey:kremindEvent];

        [[NSNotificationCenter defaultCenter] postNotificationName:measureRemindNotification object:nil];
        [self dismissViewControllerAnimated:YES completion:nil];
    }

}

- (void)selectWeekDayAction:(UIButton *)btn
{
    NSLog(@"%s", __FUNCTION__);
    NSLog(@"%ld", (long)btn.tag);
    NSString *statusStr = self.btnBGArray[btn.tag];
    [self.btnBGArray removeObjectAtIndex:btn.tag];
    if ([statusStr isEqualToString:@"normal"]) {
        [self.btnBGArray insertObject:@"selected" atIndex:btn.tag];
        btn.backgroundColor = [UIColor orangeColor];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    } else {
        [self.btnBGArray insertObject:@"normal" atIndex:btn.tag];
        btn.backgroundColor = appBackgroundColor;
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];

    }
    self.naozhongView.remindRepeatArray = self.btnBGArray;
    [self.naozhongView.tbView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:1 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];

}
#pragma mark JZNaoZhongViewDelegate Methods
- (void)naoZhongView:(JZNaoZhongView *)naoZhongView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"提醒时间" preferredStyle:UIAlertControllerStyleAlert];
            UIDatePicker *datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(15, 60, 240, 25 * 7)];
            datePicker.backgroundColor = [UIColor colorWithWhite:0.98 alpha:1];
            datePicker.datePickerMode = UIDatePickerModeTime;
            datePicker.date = [NSDate date];

            [alertController.view addSubview:datePicker];

            for (int i = 0; i < 7; i++) {
                [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                    textField.enabled = NO;
                }];
            }

            UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {

                self.jzRemindDate = [self.dateFormatter dateFromString:[NSString stringWithFormat:@"%@:00", [[[datePicker.date localDate] dateToString] substringToIndex:16]]];

                self.naozhongView.remindDate = self.jzRemindDate;
                [self.naozhongView.tbView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            }];

            [alertController addAction:okAction];
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            }];
            [alertController addAction:cancelAction];
            [self presentViewController:alertController animated:YES completion:nil];
        }
    } else if (indexPath.section == 2) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"提醒备注" preferredStyle:UIAlertControllerStyleAlert];

        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.placeholder = @"请输入提醒内容";
            textField.delegate = self;
            textField.text = self.jzRemindInfo;
            [textField becomeFirstResponder];
        }];

        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            self.naozhongView.jzRemindInfo = self.jzRemindInfo;
            [self.naozhongView.tbView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:0 inSection:2]] withRowAnimation:UITableViewRowAnimationNone];
        }];
        [alertController addAction:okAction];

        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {

        }];
        [alertController addAction:cancelAction];

        [self presentViewController:alertController animated:YES completion:nil];
    }


}

#pragma mark UITextFieldDelegate Methods
- (void)textFieldDidEndEditing:(UITextField *)textField
{
    self.jzRemindInfo = textField.text;
    [textField resignFirstResponder];
}


@end
