//
//  JZLoginFrame.h
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JZLoginFrame : NSObject

@property (nonatomic, assign) CGRect imageViewFrame;
@property (nonatomic, assign) CGRect userLabelFrame;
@property (nonatomic, assign) CGRect userTFFrame;
@property (nonatomic, assign) CGRect passwordLabelFrame;
@property (nonatomic, assign) CGRect passwordTFFrame;
@property (nonatomic, assign) CGRect loginBtnFrame;
@property (nonatomic, assign) CGRect forgetPasswordBtnFrame;
@property (nonatomic, assign) CGRect marginFrame;
@property (nonatomic, assign) CGRect promptFrame;
@property (nonatomic, assign) CGRect registerFrame;
@property (nonatomic, assign) CGRect leftLineFrame;
@property (nonatomic, assign) CGRect rightLineFrame;
@property (nonatomic, assign) CGRect otherLoginWayFrame;
@property (nonatomic, assign) CGRect visitorsImageFrame;
@property (nonatomic, assign) CGRect visitorFrame;
@property (nonatomic, assign) CGRect rememberPasswordFrame;
@end
