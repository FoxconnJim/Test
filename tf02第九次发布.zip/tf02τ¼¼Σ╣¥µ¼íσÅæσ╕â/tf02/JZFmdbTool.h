//
//  JZFmdbTool.h
//  tf02
//
//  Created by F7686324 on 2017/1/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"
#import "JZBloodPressureData.h"
#import "JZHeartRateData.h"
#import "JZBodyFatData.h"
#import "JZWeightData.h"
#import "JZBloodOxygenData.h"
#import "JZBloodSugarData.h"
#import "NSString+Date.h"

@interface JZFmdbTool : NSObject

+ (void)beginTransaction;

+ (void)commit;

+ (void)rollBack;

// 增加模型数据
+ (BOOL)insertBloodPressureData:(JZBloodPressureData *)bloodPressureData cardID:(NSString *)cardID;
+ (BOOL)insertHeartRateData:(JZHeartRateData *)heartRateData cardID:(NSString *)cardID;
+ (BOOL)insertBodyFatData:(JZBodyFatData *)bodyFatData cardID:(NSString *)cardID;
+ (BOOL)insertWeightData:(JZWeightData *)weightData cardID:(NSString *)cardID;
+ (BOOL)insertBloodOxygenData:(JZBloodOxygenData *)bloodOxygenData cardID:(NSString *)cardID;
+ (BOOL)insertBloodSugarData:(JZBloodSugarData *)bloodSugarData cardID:(NSString *)cardID;

// 查询数据，如果 传空 默认会查询表中所有数据
+ (NSArray *)queryBloodPressureDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (NSArray *)queryHeartRateDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (NSArray *)queryBodyFatDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (NSArray *)queryWeightDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (NSArray *)queryBloodOxygenDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (NSArray *)queryBloodSugarDataWithID:(NSString *)cardID timeType:(NSString *)timeType;

// 删除数据，如果 传空 默认会删除表中所有数据
+ (BOOL)deleteBloodPressureDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (BOOL)deleteHeartRateDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (BOOL)deleteBodyFatDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (BOOL)deleteWeightDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (BOOL)deleteBloodOxygenDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
+ (BOOL)deleteBloodSugarDataWithID:(NSString *)cardID timeType:(NSString *)timeType;

// 修改数据
+ (BOOL)modifyData:(NSString *)modifySql;

@end
