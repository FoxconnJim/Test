//
//  NSArray+changeOrder.m
//  tf02
//
//  Created by Jim on 16/10/6.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "NSArray+changeOrder.h"

@implementation NSArray (changeOrder)

- (NSMutableArray *)changeOrder
{
    NSMutableArray *array = [NSMutableArray array];
    for (int i = 0; i < self.count; i++) {
        [array addObject: [self objectAtIndex: self.count - 1 - i]];
    }
    return array;
}

@end
