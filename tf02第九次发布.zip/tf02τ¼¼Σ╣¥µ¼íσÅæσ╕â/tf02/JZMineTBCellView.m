//
//  JZMineTBCellView.m
//  tf02
//
//  Created by Jim on 16/8/20.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZMineTBCellView.h"

@implementation JZMineTBCellView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {


    }
    return self;
}

@end
