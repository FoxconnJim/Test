//
//  JZTodayRecommendViewController.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZTodayRecommendViewController.h"
#import "Utility.h"
#import "JZOperation.h"
#import "JZNewsCell.h"
#import "JZjinrituijianViewController.h"
#import "MJRefresh.h"

@interface JZTodayRecommendViewController () <UITableViewDelegate, UITableViewDataSource, JZOperationDelegate, UIViewControllerPreviewingDelegate>
{
    NSInteger jz_count;
}
@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) NSMutableArray *hotNewsArray;
@property (nonatomic, strong) NSOperationQueue *queue;

@end

@implementation JZTodayRecommendViewController

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (NSMutableArray *)hotNewsArray
{
    if (!_hotNewsArray) {
        _hotNewsArray = [NSMutableArray array];
    }
    return _hotNewsArray;
}


- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight)];
        _tbView.delegate = self;
        _tbView.dataSource = self;
        _tbView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    }
    return _tbView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"今日推荐";
    self.view.backgroundColor = appBackgroundColor;
    [self.view addSubview: self.tbView];

    jz_count = 0;


}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    self.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock: ^{

        jz_count = 0;
        [self getAllRecommendInfo];
    }];

    self.tbView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self getAllRecommendInfo];
    }];

    JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];

    if (refreshInfo.canTodayRecommendRefresh) {
        [self.tbView.mj_header beginRefreshing];
        refreshInfo.canTodayRecommendRefresh = NO;
        [refreshInfo storeValueByKey:kRefreshInfo];
    } else {
        if (!self.hotNewsArray.count) {
            [self getAllRecommendInfo];
        }
    }

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllRecommendInfo) name:cancelshoucangNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllRecommendInfo) name:shoucangNotification object:nil];
}
- (void)getAllRecommendInfo
{
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    if (!jz_count) {
        param[@"id"] = @"0";
    } else {
        JZHotNews *hotNews = [self.hotNewsArray objectAtIndex:jz_count - 1];
        param[@"id"] = hotNews.ID;
    }
    [LCProgressHUD showInfoMsg:@"加载中..."];
    JZOperation *operation = [JZOperation operationWithURLString:moretodayrecommendURL andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
    operation.name = todayRecommendOperation;
}

#pragma mark JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    [LCProgressHUD hide];
    if ([responseObject[@"data"] isKindOfClass:[NSArray class]]) {
        NSArray *arr = responseObject[@"data"];

        if (!jz_count) {
            [self.hotNewsArray removeAllObjects];
        }

        for (int i = 0; i < arr.count; i++) {
            JZHotNews *hotNews = [JZHotNews hotNewsWithDictionary:arr[i]];
            hotNews.tag = i;
            [self.hotNewsArray addObject: hotNews];
        }

        if (arr.count < 10) {
            jz_count += arr.count;

            [self.tbView.mj_footer endRefreshingWithNoMoreData];
        } else {
            jz_count += 10;

            [self.tbView.mj_footer endRefreshing];

        }
    } else {
        [self.tbView.mj_footer endRefreshingWithNoMoreData];
    }

    [self.tbView.mj_header endRefreshing];

    [self.tbView reloadData];

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    [LCProgressHUD showInfoMsg:@"网络有点卡..."];
    [self.tbView.mj_header endRefreshing];
    [self.tbView.mj_footer endRefreshing];
}

#pragma mark UITableViewDataSource Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.hotNewsArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZNewsCell *cell = [[JZNewsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"allRecommendID"];
    JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
    cell.hotNews = hotNews;
    [cell.imgView sd_setImageWithURL:[NSURL URLWithString: hotNews.newsFront] placeholderImage:[UIImage imageNamed:@"资讯"]];
    if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
        [self registerForPreviewingWithDelegate:self sourceView:cell];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return newsRowHeight;
}

#pragma mark UITableViewDelegate Methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView reloadRowsAtIndexPaths: [NSArray arrayWithObject: indexPath] withRowAnimation:UITableViewRowAnimationNone];
    JZjinrituijianViewController *jrtjVC = [[JZjinrituijianViewController alloc] init];
    JZHotNews *hotNews = self.hotNewsArray[indexPath.row];

    jrtjVC.hotNews = hotNews;
    [self.navigationController pushViewController:jrtjVC animated:YES];
}
#pragma mark UIViewControllerPreviewingDelegate Methods
//peek(预览)
- (nullable UIViewController *)previewingContext:(id<UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location
{
    //获取按压的cell所在行， [previewingContext sourceView]就是按压的那个视图
    NSIndexPath *indexPath = [self.tbView indexPathForCell:(UITableViewCell *)[previewingContext sourceView]];

    //设定预览的界面
    JZjinrituijianViewController *childVC = [[JZjinrituijianViewController alloc] init];
    childVC.preferredContentSize = CGSizeMake(0.f, 500.f);
    childVC.title = @"今日推荐";
    JZHotNews *hotNews = self.hotNewsArray[indexPath.row];
    childVC.hotNews = hotNews;

    //调整不被虚化的范围，按压的那个cell不被虚化（轻轻按压时周边会被虚化，再稍用力展示预览，再加力跳页至设定界面)
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width, newsRowHeight);
    previewingContext.sourceRect = rect;

    //返回预览界面
    return childVC;
}

//pop (再加力进入)
- (void)previewingContext:(id<UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit
{
    [self showViewController:viewControllerToCommit sender:self];
}
@end
