//
//  JZPageControlView.m
//  tf02
//
//  Created by AN PEN on 4/13/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZPageControlView.h"

@implementation JZPageControlView

- (UIScrollView *)helpScrView
{
    if (!_helpScrView) {
        //创建UIScrollView
        _helpScrView = [[UIScrollView alloc] initWithFrame:CGRectMake(self.bounds.origin.x, self.bounds.origin.y, self.bounds.size.width, self.bounds.size.height)];  //创建UIScrollView，位置大小与主界面一样。
        _helpScrView.pagingEnabled = YES;  //设为YES时，会按页滑动
        _helpScrView.bounces = NO; //取消UIScrollView的弹性属性，这个可以按个人喜好来定
        [_helpScrView setDelegate:self];//UIScrollView的delegate函

        //        数在本类中定义
        _helpScrView.showsHorizontalScrollIndicator = NO;  //因为我们使用UIPageControl表示页面进度，所以取消UIScrollView自己的进度条。
    }
    return _helpScrView;
}

- (UIPageControl *)pageCtrl
{
    if (!_pageCtrl) {
        //创建UIPageControl
        _pageCtrl = [[UIPageControl alloc] initWithFrame:CGRectMake(self.bounds.size.width * 3 / 4, self.bounds.size.height * 3 / 4, self.bounds.size.width / 4, self.bounds.size.height / 4)];  //创建UIPageControl，位置在屏幕最下方。
        _pageCtrl.currentPage = 0; //当前页
        _pageCtrl.currentPageIndicatorTintColor = [UIColor blueColor];
        _pageCtrl.pageIndicatorTintColor = [UIColor colorWithRed:0 green:0 blue:1 alpha:0.5];
        [_pageCtrl addTarget:self action:@selector(pageTurn:) forControlEvents:UIControlEventValueChanged];  //用户点击UIPageControl的响应函数
    }
    return _pageCtrl;
}
- (void)setADModelArray:(NSMutableArray *)ADModelArray
{
    _ADModelArray = ADModelArray;
    [_helpScrView setContentSize:CGSizeMake(self.bounds.size.width * ADModelArray.count, self.bounds.size.width * 340 / 720)];  //设置全部内容的尺寸，这里帮助图片是3张，所以宽度设为界面宽度*3，高度和界面一致。
    self.pageCtrl.numberOfPages = ADModelArray.count;//总的图片页数

    for (int i = 0; i < ADModelArray.count; i++) {
        //加载蒙板图片，限于篇幅，这里仅显示一张图片的加载方法
        UIImageView* imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i * self.bounds.size.width, self.bounds.origin.y, self.bounds.size.width, self.bounds.size.height)];  //创建UIImageView，位置大小与主界面一样。
        JZADModel *ADModel = ADModelArray[i];

        [imageView sd_setImageWithURL:[NSURL URLWithString:[ADModel newsFront]] placeholderImage:[UIImage imageNamed:@"健康广告"]];
        [self.helpScrView addSubview: imageView]; //将UIImageView添加到UIScrollView中。
    }
}


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview: self.helpScrView]; //将UIScrollView添加到主界面上。
        [self addSubview: self.pageCtrl];  //将UIPageControl添加到主界面上。
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture)];
        [self addGestureRecognizer: tap];
        pageNumbers = 0;
        [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(scrollImage) userInfo:nil repeats:YES];
    }
    return self;
}

- (void)scrollImage
{
    [self.pageCtrl setCurrentPage: pageNumbers];
    CGSize viewSize = self.helpScrView.frame.size;
    CGRect rect = CGRectMake(pageNumbers * viewSize.width, 0, viewSize.width, viewSize.height);
    [self.helpScrView scrollRectToVisible:rect animated:YES];
    pageNumbers++;
    if (pageNumbers >= self.ADModelArray.count) {
        pageNumbers = 0;
    }
}

//其次是UIScrollViewDelegate的scrollViewDidEndDecelerating函数，用户滑动页面停下后调用该函数。
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //更新UIPageControl的当前页
    CGPoint offset = scrollView.contentOffset;
    CGRect bounds = scrollView.frame;
    [self.pageCtrl setCurrentPage:offset.x / bounds.size.width];
}

//然后是点击UIPageControl时的响应函数pageTurn
- (void)pageTurn:(UIPageControl*)sender
{
    //令UIScrollView做出相应的滑动显示
    CGSize viewSize = self.helpScrView.frame.size;
    CGRect rect = CGRectMake(sender.currentPage * viewSize.width, 0, viewSize.width, viewSize.height);
    [self.helpScrView scrollRectToVisible:rect animated:YES];
}

- (void)handleTapGesture
{
    NSLog(@"clickPageControlView");
    [self.delegate clickToguanggaoWithCurrentPage: self.pageCtrl.currentPage];
}

@end
