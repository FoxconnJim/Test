//
//  JZzixunwenzhangViewController.m
//  tf02
//
//  Created by AN PEN on 8/8/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZzixunwenzhangViewController.h"
#import "JZh5View.h"

@interface JZzixunwenzhangViewController ()

@property (nonatomic, strong) JZh5View *h5View;

@end

@implementation JZzixunwenzhangViewController

- (JZh5View *)h5View
{
    if (!_h5View) {
        _h5View = [[JZh5View alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight)];
    }
    return _h5View;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    self.title = @"资讯文章";
    
    [self.view addSubview: self.h5View];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.h5View.urlString = self.urlString;

}

- (void)setUrlString:(NSString *)urlString
{
    _urlString = urlString;
}


@end
