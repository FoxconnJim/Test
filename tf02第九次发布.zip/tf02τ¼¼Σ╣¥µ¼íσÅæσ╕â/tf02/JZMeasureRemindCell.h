//
//  JZMeasureRemindCell.h
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZMeasureRemindCell : UITableViewCell

@property (nonatomic, strong) UILabel *leftLabel;
@property (nonatomic, strong) UILabel *rightLabel;
@property (nonatomic, strong) UILabel *downLabel;
@property (nonatomic, strong) UISwitch *jzSwitch;

+ (JZMeasureRemindCell *)cellWithTableView:(UITableView *)tableView;

@end
