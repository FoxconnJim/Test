//
//  NSArray+JZRemoveByInteval.h
//  tf02
//
//  Created by F7686324 on 2017/1/4.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (JZRemoveByInteval)

- (NSMutableArray *)removeByInteval:(NSInteger)inteval;

@end
