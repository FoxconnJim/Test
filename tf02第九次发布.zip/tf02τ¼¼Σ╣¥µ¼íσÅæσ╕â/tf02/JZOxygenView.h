//
//  JZOxygenView.h
//  tf02
//
//  Created by AN PEN on 3/31/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZLineChartView.h"

@interface JZOxygenView : JZLineChartView
@property (nonatomic, copy) NSString *timeLengthString;

@end
