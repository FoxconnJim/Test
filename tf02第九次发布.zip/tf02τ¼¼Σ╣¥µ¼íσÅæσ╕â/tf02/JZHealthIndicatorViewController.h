


//
//  JZHealthIndicatorViewController.h
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZHealthIndicatorView.h"
#import "JZHealthDataViewController.h"
#import "Utility.h"
#import "MJRefresh.h"

@interface JZHealthIndicatorViewController : UIViewController 

@property (nonatomic, strong) JZHealthIndicatorView *healthIndicatorView;

@end
