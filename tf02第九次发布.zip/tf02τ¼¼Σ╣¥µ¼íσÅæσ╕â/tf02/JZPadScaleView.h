//
//  JZPadScaleView.h
//  tf02
//
//  Created by F7686324 on 03/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZSegment.h"
#import "JZTime.h"
#import "JZTimeView.h"

@interface JZPadScaleView : UIView

@property (nonatomic, strong) JZSegment *segment;
@property (nonatomic, copy) NSString *timeLengthString;

@property (nonatomic, strong) NSMutableArray *textArray;

@property (nonatomic, strong) NSMutableArray *pointArray;

@property (nonatomic, assign) CGFloat jzScale;
@property (nonatomic, strong) JZTimeView *timeView;
@property (nonatomic, strong) JZTime *jzTime;

- (void)jzSetNeedsDisplay;


@end
