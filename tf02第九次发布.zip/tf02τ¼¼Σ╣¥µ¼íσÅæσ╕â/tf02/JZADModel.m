//
//  JZADModel.m
//  tf02
//
//  Created by F7686324 on 9/24/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZADModel.h"

@implementation JZADModel

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.newsFront = [NSString stringWithFormat: @"%@", dict[@"newsFront"]];
        self.netUrl = [NSString stringWithFormat: @"%@", dict[@"netUrl"]];

    }
    return self;
}

+ (instancetype)ADModelWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
