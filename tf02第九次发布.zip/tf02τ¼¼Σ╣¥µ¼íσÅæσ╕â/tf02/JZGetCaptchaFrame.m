//
//  JZGetCaptchaFrame.m
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZGetCaptchaFrame.h"

@implementation JZGetCaptchaFrame

- (instancetype)init
{
    self = [super init];
    if (self) {
        CGFloat margin = screenW / 15;

        CGFloat titleX = margin;
        CGFloat titleY = screenH / 6;
        CGFloat titleW = screenW -titleX;
        CGFloat titleH = 30;
        self.titleFrame = CGRectMake(titleX, titleY, titleW, titleH);

        CGFloat upLabelX = titleX;
        CGFloat upLabelY = titleY + titleH + margin;
        CGFloat upLabelW = screenW / 5;
        CGFloat upLabelH = titleH;
        self.upLabelFrame = CGRectMake(upLabelX, upLabelY, upLabelW, upLabelH);

        CGFloat upFieldX = upLabelX + upLabelW + 5;
        CGFloat upFieldY = upLabelY;
        CGFloat upFieldW = screenW - upFieldX - margin;
        CGFloat upFieldH = upLabelH;
        self.upFieldFrame = CGRectMake(upFieldX, upFieldY, upFieldW, upFieldH);

        CGFloat upSubLabelX = upFieldX;
        CGFloat upSubLabelY = upFieldY + upFieldH + 5;
        CGFloat upSubLabelW = upFieldW;
        CGFloat upSubLabelH = upFieldH / 2;
        self.upSublabelFrame = CGRectMake(upSubLabelX, upSubLabelY, upSubLabelW, upSubLabelH);

        CGFloat downLabelX = upLabelX;
        CGFloat downLabelY = upLabelY + upLabelH + margin * 2;
        CGFloat downLabelW = upLabelW;
        CGFloat downLabelH = upLabelH;
        self.downLabelFrame = CGRectMake(downLabelX, downLabelY, downLabelW, downLabelH);

        CGFloat downFieldX = upFieldX;
        CGFloat downFieldY = downLabelY;
        CGFloat downFieldW = upFieldW * 2 / 3;
        CGFloat downFieldH = downLabelH;
        self.downFieldFrame = CGRectMake(downFieldX, downFieldY, downFieldW, downFieldH);

        CGFloat downSublabelX = upSubLabelX;
        CGFloat downSublabelY = downFieldY + downFieldH + 5;
        CGFloat downSublabelW = upSubLabelW;
        CGFloat downSublabelH = upSubLabelH;
        self.downSublabelFrame = CGRectMake(downSublabelX, downSublabelY, downSublabelW, downSublabelH);

        CGFloat captchaX = downFieldX + downFieldW;
        CGFloat captchaY = downFieldY;
        CGFloat captchaW = upFieldW / 3;
        CGFloat captchaH = downLabelH;
        self.captchaFrame = CGRectMake(captchaX, captchaY, captchaW, captchaH);

        CGFloat btnX = margin * 2;
        CGFloat btnY = captchaY + captchaH + margin * 3;
        CGFloat btnW = screenW - btnX * 2;
        CGFloat btnH = 35;
        self.foundBackBtnFrame = CGRectMake(btnX, btnY, btnW, btnH);
        
        CGFloat backBtnW = btnW;
        CGFloat backBtnH = btnH;
        CGFloat backBtnX = btnX;
        CGFloat backBtnY = btnY + btnH + 5;
        self.backBtnFrame = CGRectMake(backBtnX, backBtnY, backBtnW, backBtnH);
    }
    return self;
}


@end
