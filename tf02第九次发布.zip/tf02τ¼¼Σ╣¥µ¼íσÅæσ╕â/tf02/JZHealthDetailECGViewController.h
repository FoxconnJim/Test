//
//  JZHealthDetailECGViewController.h
//  tf02
//
//  Created by AN PEN on 6/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZECGScrollView.h"
#import "JZECGDataView.h"
@interface JZHealthDetailECGViewController : UIViewController
{
    CGFloat ratio;
    CGFloat space;
}
@property (nonatomic, strong) JZECGDataView *dataView;
@property (nonatomic, strong) JZECGScrollView *scrollView;
@property (nonatomic, strong) UISegmentedControl *segment;
@property (nonatomic, strong) UILabel *lblUnit;
@property (nonatomic, strong) UILabel *lblTurns;
@property (nonatomic, strong) NSMutableArray *array;

@end
