//
//  JZSegment.h
//  tf02
//
//  Created by F7686324 on 14/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZSegment : UISegmentedControl

@end
