//
//  JZData.m
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZData.h"

@implementation JZData

- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.meatime = [[NSString stringWithFormat:@"%@", dict[@"meatime"]] turnServiceToMyFormatter];
        self.healthrecord = [NSString stringWithFormat:@"%@", dict[@"healthrecord"]];
        if ([self.healthrecord isEqualToString:@"null"]) {
            self.healthrecord = @"<null>";
        }

        self.ID = [NSString stringWithFormat:@"%@", dict[@"id"]];
    }
    return self;
}

+ (instancetype)dataWithDictionary:(NSDictionary *)dict
{
    return [[self alloc] initWithDictionary:dict];
}

@end
