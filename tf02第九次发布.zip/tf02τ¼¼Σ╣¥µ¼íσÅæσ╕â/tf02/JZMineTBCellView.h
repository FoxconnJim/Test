//
//  JZMineTBCellView.h
//  tf02
//
//  Created by Jim on 16/8/20.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZMineTBCellView : UIView

@property (nonatomic, strong) UIImageView *arrowImgView;
@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *textLabel;

@end
