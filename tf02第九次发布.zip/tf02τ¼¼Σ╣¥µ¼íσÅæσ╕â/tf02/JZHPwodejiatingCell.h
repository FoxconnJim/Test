//
//  JZHPwodejiatingCell.h
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZHPwodejiatingFrame.h"
#import "JZPersonInfo.h"

@interface JZHPwodejiatingCell : UITableViewCell

@property (nonatomic, strong) JZPersonInfo *personInfo;

@property (nonatomic, strong) JZHPwodejiatingFrame *wdjtFrame;
@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *upLabel;
@property (nonatomic, strong) UILabel *downLabel;
@property (nonatomic, strong) UIImageView *arrowImgView;

+ (instancetype)cellWithTableView: (UITableView*)tableView;

@end
