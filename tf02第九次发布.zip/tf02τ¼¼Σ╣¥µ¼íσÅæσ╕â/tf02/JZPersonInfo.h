//
//  JZPersonInfo.h
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZPersonInfo : NSObject 

@property (nonatomic, copy) NSString *nickname;
@property (nonatomic, copy) NSString *membersname;
@property (nonatomic, copy) NSString *sex;
@property (nonatomic, copy) NSString *idCard;
@property (nonatomic, copy) NSString *idType;
@property (nonatomic, copy) NSString *tel;
@property (nonatomic, copy) NSString *picture;
@property (nonatomic, copy) NSString *bloodType;
@property (nonatomic, copy) NSString *marryStatus;
@property (nonatomic, copy) NSString *job;
@property (nonatomic, copy) NSString *birthday;
@property (nonatomic, copy) NSString *socialCard;
@property (nonatomic, copy) NSString *address;
@property (nonatomic, copy) NSString *home;
@property (nonatomic, copy) NSString *height;
@property (nonatomic, copy) NSString *weight;

@property (nonatomic, copy) NSString *family;
@property (nonatomic, copy) NSString *allergic;
@property (nonatomic, copy) NSString *history;
@property (nonatomic, copy) NSString *createtime;
@property (nonatomic, copy) NSString *delflag;
@property (nonatomic, copy) NSString *memberId;
@property (nonatomic, assign) NSInteger tag;

- (instancetype)initWithDict: (NSDictionary *)dict;
+ (instancetype)personInfoWithDict: (NSDictionary *)dict;

@end
