//
//  JZData.h
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utility.h"

@interface JZData : NSObject
@property (nonatomic, copy) NSString *meatime;
@property (nonatomic, copy) NSString *data;
@property (nonatomic, copy) NSString *healthrecord;
@property (nonatomic, copy) NSString *physicalstate;
@property (nonatomic, copy) NSString *ID;

- (instancetype)initWithDictionary: (NSDictionary *)dict;
+ (instancetype)dataWithDictionary: (NSDictionary *)dict;

@end
