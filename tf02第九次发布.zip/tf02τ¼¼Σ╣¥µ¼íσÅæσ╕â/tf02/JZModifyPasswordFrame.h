//
//  JZModifyPasswordFrame.h
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZModifyPasswordFrame : NSObject

@property (nonatomic, assign) CGRect titleFrame;
@property (nonatomic, assign) CGRect upFieldFrame;
@property (nonatomic, assign) CGRect upLabelFrame;
@property (nonatomic, assign) CGRect upSublabelFrame;
@property (nonatomic, assign) CGRect upTipFrame;
@property (nonatomic, assign) CGRect downFieldFrame;
@property (nonatomic, assign) CGRect downLabelFrame;
@property (nonatomic, assign) CGRect downSublabelFrame;
@property (nonatomic, assign) CGRect downTipFrame;
@property (nonatomic, assign) CGRect modifyBtnFrame;
@property (nonatomic, assign) CGRect backBtnFrame;

@end
