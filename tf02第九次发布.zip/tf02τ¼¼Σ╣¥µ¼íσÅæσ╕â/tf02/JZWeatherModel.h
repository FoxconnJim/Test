//
//  JZWeatherModel.h
//  tf02
//
//  Created by Jim on 2016/11/28.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZWeatherModel : NSObject

@property (nonatomic, copy) NSString *airCondition;
@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *coldIndex;
@property (nonatomic, copy) NSString *date;
@property (nonatomic, copy) NSString *distrct;
@property (nonatomic, copy) NSString *dressingIndex;
@property (nonatomic, copy) NSString *exerciseIndex;
@property (nonatomic, copy) NSArray *future;

@property (nonatomic, copy) NSString *humidity;
@property (nonatomic, copy) NSString *pollutionIndex;
@property (nonatomic, copy) NSString *province;
@property (nonatomic, copy) NSString *sunrise;
@property (nonatomic, copy) NSString *sunset;
@property (nonatomic, copy) NSString *temperature;
@property (nonatomic, copy) NSString *time;
@property (nonatomic, copy) NSString *updateTime;
@property (nonatomic, copy) NSString *washIndex;
@property (nonatomic, copy) NSString *weather;
@property (nonatomic, copy) NSString *week;
@property (nonatomic, copy) NSString *wind;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (instancetype)weatherModelWithDict:(NSDictionary *)dict;
@end
