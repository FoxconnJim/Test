//
//  JZWeatherView.h
//  tf02
//
//  Created by Jim on 16/3/12.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZWeatherFrame.h"
#import "Utility.h"
#import "JZOperation.h"
#import "JZWeatherModel.h"

@interface JZWeatherView : UIView <JZLocationDelegate>

@property (nonatomic, strong) UIView *weatherInfo;
@property (nonatomic, strong) UIImageView *weatherImage;
@property (nonatomic, strong) UIImageView *leftImage;
@property (nonatomic, strong) UILabel *mid;
@property (nonatomic, strong) UIImageView *rightImage;
@property (nonatomic, strong) UILabel *weather;

@property (nonatomic, strong) UILabel *temp;
@property (nonatomic, strong) UILabel *wind;
@property (nonatomic, strong) UILabel *airCondition;

@property (nonatomic, strong) UIButton *location;

@property (nonatomic, strong) JZWeatherFrame *weatherFrame;
@property (nonatomic, strong) JZWeatherModel *weatherModel;

@property (nonatomic, strong) UIActivityIndicatorView *tips;
@property (nonatomic, strong) UILabel *nullcity;
@end
