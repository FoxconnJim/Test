//
//  JZSelectCountyTableViewController.h
//  tf02
//
//  Created by F7686324 on 16/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZCityModel.h"

@interface JZSelectCountyTableViewController : UITableViewController

@property (nonatomic, strong) JZCityModel *jzCityModel;

@end
