//
//  JZTodayRemindViewController.m
//  tf02
//
//  Created by AN PEN on 5/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZTodayRemindViewController.h"
#import "Utility.h"
#import "HMSegmentedControl.h"
#import "JZTodayRemindData.h"

#import "JZOperation.h"
#import "MJRefresh.h"

#import "JZTodayRemindCell.h"
#import "JZRemindTableView.h"
#import "NSArray+JZOrderByTime.h"
#import "LCProgressHUD.h"
#import "JZlishitixingViewController.h"

@interface JZTodayRemindViewController () <JZOperationDelegate, UIScrollViewDelegate, JZRemindTableViewDelegate>
{
    BOOL todayType;
    BOOL isRequest;
    NSInteger jz_count;
}

@property (nonatomic, strong) NSMutableArray *todayRemindDataArray;
@property (nonatomic, strong) NSMutableArray *historyRemindDataArray;
@property (nonatomic, strong) JZRemindTableView *todayTBView;
@property (nonatomic, strong) JZRemindTableView *historyTBView;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) HMSegmentedControl *hmSegment;
@property (nonatomic, strong) NSMutableArray *todayRemindCellHeightArray;
@property (nonatomic, strong) NSMutableArray *historyRemindCellHeightArray;

@end

@implementation JZTodayRemindViewController

- (HMSegmentedControl *)hmSegment
{
    if (!_hmSegment) {
        _hmSegment = [[HMSegmentedControl alloc] initWithSectionTitles:@[@"今日提醒", @"历史提醒"]];
        _hmSegment.frame = CGRectMake(0, 0, screenW, HMSegmentHeight);
        _hmSegment.selectionIndicatorHeight = 3.0f;
        _hmSegment.titleTextAttributes = @{NSFontAttributeName:[UIFont systemFontOfSize:17]};
        _hmSegment.backgroundColor = [UIColor whiteColor];
        _hmSegment.selectionIndicatorLocation = HMSegmentedControlSelectionIndicatorLocationDown;
        _hmSegment.selectionStyle = HMSegmentedControlSelectionStyleFullWidthStripe;
        _hmSegment.selectedTitleTextAttributes = @{NSForegroundColorAttributeName:barBackgroundColor};
        _hmSegment.selectionIndicatorColor = barBackgroundColor;

        __weak typeof(self) weakSelf = self;
        [self.hmSegment setIndexChangeBlock: ^(NSInteger index) {
            [weakSelf.scrollView scrollRectToVisible:CGRectMake(screenW * index, 0, screenW, screenH - naviHeight - statusBarHeight - HMSegmentHeight) animated:YES];
        }];
        [_hmSegment addTarget:self action:@selector(segmentedControlChangedValue:) forControlEvents:UIControlEventValueChanged];

    }
    return _hmSegment;
}

- (NSMutableArray *)todayRemindDataArray
{
    if (!_todayRemindDataArray) {
        _todayRemindDataArray = [NSMutableArray array];
    }
    return _todayRemindDataArray;
}

- (NSMutableArray *)historyRemindDataArray
{
    if (!_historyRemindDataArray) {
        _historyRemindDataArray = [NSMutableArray array];
    }
    return _historyRemindDataArray;
}

- (NSMutableArray *)todayRemindCellHeightArray
{
    if (!_todayRemindCellHeightArray) {
        _todayRemindCellHeightArray = [NSMutableArray array];
    }
    return _todayRemindCellHeightArray;
}

- (NSMutableArray *)historyRemindCellHeightArray
{
    if (!_historyRemindCellHeightArray) {
        _historyRemindCellHeightArray = [NSMutableArray array];
    }
    return _historyRemindCellHeightArray;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (JZRemindTableView *)todayTBView
{
    if (!_todayTBView) {
        _todayTBView = [[JZRemindTableView alloc] initWithFrame: CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight - HMSegmentHeight)];
    }
    return _todayTBView;
}

- (JZRemindTableView *)historyTBView
{
    if (!_historyTBView) {
        _historyTBView = [[JZRemindTableView alloc] initWithFrame: CGRectMake(screenW, 0, screenW, screenH - naviHeight - statusBarHeight - HMSegmentHeight)];

    }
    return _historyTBView;
}

- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] initWithFrame: CGRectMake(0, HMSegmentHeight, screenW, screenH - naviHeight - statusBarHeight - HMSegmentHeight)];
        _scrollView.backgroundColor = appBackgroundColor;

        _scrollView.delegate = self;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.contentSize = CGSizeMake(screenW * 2, screenH - naviHeight - statusBarHeight - HMSegmentHeight);
        _scrollView.delegate = self;
        _scrollView.bounces = NO;

        [_scrollView addSubview: self.todayTBView];
        [_scrollView addSubview: self.historyTBView];
    }
    return _scrollView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"提醒记录";
    self.view.backgroundColor = appBackgroundColor;
    [self.view addSubview: self.hmSegment];
    [self.view addSubview: self.scrollView];
    NSString *colorType = @"灰";
    [colorType storeValueByKey:JZRefreshColor];
    todayType = YES;
    isRequest = YES;


}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSArray *gestureArray = self.navigationController.view.gestureRecognizers;
    for (UIGestureRecognizer *gestureRecoginzer in gestureArray) {
        if ([gestureRecoginzer isKindOfClass:[UIScreenEdgePanGestureRecognizer class]]) {
            [self.scrollView.panGestureRecognizer requireGestureRecognizerToFail:gestureRecoginzer];
        }
    }
    self.todayTBView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self getRemind];
    }];
    self.historyTBView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock: ^{
        [self getRemind];
    }];

    JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];

    if (refreshInfo.canTodayRemindRefresh) {
        [self.todayTBView.mj_header beginRefreshing];
        refreshInfo.canTodayRemindRefresh = NO;
        [refreshInfo storeValueByKey:kRefreshInfo];
    } else {
        if (!self.todayRemindDataArray.count) {
            [self getRemind];
        }
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
    [JZOperation cancelAFHTTPRequest];
}

- (void)segmentedControlChangedValue: (HMSegmentedControl *)control
{
    NSLog(@"control.selectedSegmentIndex = %ld", (long)control.selectedSegmentIndex);
    [LCProgressHUD hide];

    if (control.selectedSegmentIndex == 0) {
        todayType = YES;
        NSLog(@"segmentedControlChangedValuetodayType = YES");
        if (!self.todayRemindDataArray.count) {
            [self getRemind];

        }
    } else {
        todayType = NO;
        NSLog(@"segmentedControlChangedValuetodayType = NO");
        JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];
        if (refreshInfo.canHistoryRemindMemberListRefresh) {
            [self.historyTBView.mj_header beginRefreshing];
            refreshInfo.canHistoryRemindMemberListRefresh = NO;
            [refreshInfo storeValueByKey:kRefreshInfo];
        } else {
            if (!self.historyRemindDataArray.count) {
                [self getRemind];

            }
        }
    }
}

- (void)getRemind
{
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"tel"] = [[JZFamilyInfo valueByKey:kFamilyInfo] tel];


    if (todayType) {
        [LCProgressHUD showInfoMsg:@"加载中..."];

        NSLog(@"getTodayRemind");
        JZOperation *operation = [JZOperation operationWithURLString:todayRemindURL andParam:param getOrPost:JZ_POST];
        operation.delegate = self;
        operation.name = todayRemindOperation;
    } else {
        [LCProgressHUD showInfoMsg:@"加载中..."];

        NSLog(@"getHistoryRemind");
        JZOperation *operation = [JZOperation operationWithURLString:historyRemindMemberURL andParam:param getOrPost:JZ_POST];
        operation.delegate = self;
        operation.name = todayRemindHistoryOperation;
    }

}


#pragma mark JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    [LCProgressHUD hide];
    if ([operation.name isEqualToString: todayRemindOperation]) {
        NSArray *arr = (NSArray *)responseObject[@"data"];
        [self.todayRemindDataArray removeAllObjects];
        [self.todayRemindCellHeightArray removeAllObjects];
        if ([arr isKindOfClass:[NSArray class]]) {

            NSLog(@"todayArr.count = %lu", (unsigned long)arr.count);

            for (NSDictionary *dict in arr) {
                JZTodayRemindData *todayRemindData = [JZTodayRemindData todayRemindDataWithDict: dict];
                [self.todayRemindDataArray addObject: todayRemindData];
                CGSize size = [todayRemindData.remindContent textSizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(screenW - 100, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping];
                NSNumber *cellHeight = [NSNumber numberWithFloat:size.height + 50];
                [self.todayRemindCellHeightArray addObject:cellHeight];
            }

            [self.todayTBView.mj_header endRefreshing];
            if (arr.count < 10) {
                [self.todayTBView.mj_footer endRefreshingWithNoMoreData];
            } else {
                [self.todayTBView.mj_footer endRefreshing];

            }
        } else {
            [self.todayTBView.mj_header endRefreshing];
            [self.todayTBView.mj_footer endRefreshingWithNoMoreData];
        }
        self.todayTBView.showIndicator = NO;
        self.todayTBView.cellHeightArray = self.todayRemindCellHeightArray;
        self.todayTBView.dataArray = self.todayRemindDataArray;


        if (self.todayRemindDataArray.count) {
            [self.todayTBView.tips removeFromSuperview];
        } else {
            self.todayTBView.tips.text = @"暂无今日提醒~";
            [self.todayTBView addSubview:self.todayTBView.tips];

        }
    } else if ([operation.name isEqualToString: todayRemindHistoryOperation]) {
        NSArray *arr = (NSArray *)responseObject[@"data"];
        [self.historyRemindDataArray removeAllObjects];
        [self.historyRemindCellHeightArray removeAllObjects];
        if ([arr isKindOfClass:[NSArray class]]) {

            for (NSDictionary *dict in arr) {
                JZTodayRemindData *todayRemindData = [JZTodayRemindData todayRemindDataWithDict: dict];
                [self.historyRemindDataArray addObject: todayRemindData];
                CGSize size = [todayRemindData.remindContent textSizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(screenW - 100, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping];
                NSNumber *cellHeight = [NSNumber numberWithFloat:size.height + 50];
                [self.historyRemindCellHeightArray addObject:cellHeight];
            }

            [self.historyTBView.mj_header endRefreshing];

            if (arr.count < 10) {
                [self.historyTBView.mj_footer endRefreshingWithNoMoreData];
            } else {
                [self.historyTBView.mj_footer endRefreshing];
            }
        } else {
            [self.historyTBView.mj_header endRefreshing];
            [self.historyTBView.mj_footer endRefreshingWithNoMoreData];
        }

        self.historyTBView.showIndicator = YES;
        self.historyTBView.cellHeightArray = self.historyRemindCellHeightArray;
        self.historyTBView.dataArray = self.historyRemindDataArray;
        self.historyTBView.remindDelegate = self;

        if (self.historyRemindDataArray.count) {
            [self.historyTBView.tips removeFromSuperview];
        } else {
            self.historyTBView.tips.text = @"暂无历史提醒~";
            [self.historyTBView addSubview:self.historyTBView.tips];
        }
    }

}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [LCProgressHUD showInfoMsg:@"网络有点卡..."];

    } else {
        [LCProgressHUD showInfoMsg:@"拼命加载中..."];
    }
    [self.todayTBView.mj_header endRefreshing];
    [self.historyTBView.mj_header endRefreshing];
    [self.todayTBView.mj_footer endRefreshing];
    [self.historyTBView.mj_footer endRefreshing];
}

#pragma mark UIScrollViewDelegate Methods
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSInteger page = scrollView.contentOffset.x / screenW;
    if (page == self.hmSegment.selectedSegmentIndex) {
        isRequest = NO;
    } else {
        isRequest = YES;
    }
    
    [self.hmSegment setSelectedSegmentIndex:page animated:YES];
    if (isRequest) {
        [LCProgressHUD hide];
        if (!self.hmSegment.selectedSegmentIndex) {
            todayType = YES;
            if (!self.todayRemindDataArray.count) {
                [self getRemind];

            }
            NSLog(@"scrollViewDidEndDeceleratingtodayType = YES");
        } else {
            todayType = NO;
            JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];
            if (refreshInfo.canHistoryRemindMemberListRefresh) {
                [self.historyTBView.mj_header beginRefreshing];
                refreshInfo.canHistoryRemindMemberListRefresh = NO;
                [refreshInfo storeValueByKey:kRefreshInfo];
            } else {
                if (!self.historyRemindDataArray.count) {
                    [self getRemind];

                }
            }
            NSLog(@"scrollViewDidEndDeceleratingtodayType = NO");
        }
    }

}


#pragma mark JZRemindTableViewDelegate Method
- (void)remindTableView:(JZRemindTableView *)remindTableView didSelectRowsAtIndexPath:(NSIndexPath *)indexPath
{

    JZlishitixingViewController *lstxVC = [[JZlishitixingViewController alloc] init];
    JZTodayRemindData *todayRemindData = self.historyRemindDataArray[indexPath.row];
    lstxVC.memberId = todayRemindData.memberId;
    JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];
    if (refreshInfo.canHistoryRemindRefresh) {
        lstxVC.canHistoryRemindRefresh = YES;
        refreshInfo.canHistoryRemindRefresh = NO;
        [refreshInfo storeValueByKey:kRefreshInfo];
    } else {
        lstxVC.canHistoryRemindRefresh = NO;
    }

    [self.navigationController pushViewController:lstxVC animated:YES];
}
@end
