//
//  JZTodayRemindCell.h
//  tf02
//
//  Created by F7686324 on 10/6/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZTodayRemindData.h"
#import "Utility.h"
#import "JZRemindTableView.h"

@interface JZTodayRemindCell : UITableViewCell
{
    CGFloat margin;
}
@property (nonatomic, strong) UIView *bgView;
@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UILabel *content;
@property (nonatomic, copy) NSString *cellID;
@property (nonatomic, assign) CGFloat cellHeight;
@property (nonatomic) BOOL showIndicator;

@property (nonatomic, strong) JZTodayRemindData *todayRemindData;


+ (JZTodayRemindCell *)cellWithTableView: (UITableView *)tableView cellID: (NSString *)cellID;

@end
