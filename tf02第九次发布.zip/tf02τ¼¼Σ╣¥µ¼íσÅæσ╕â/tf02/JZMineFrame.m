//
//  JZMineFrame.m
//  tf02
//
//  Created by Jim on 16/3/14.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZMineFrame.h"

@implementation JZMineFrame

- (instancetype)init
{
    self = [super init];
    if (self) {

        CGFloat margin = 10;

        CGFloat iconImgW = screenW / 5;
        CGFloat iconImgH = iconImgW;
        CGFloat iconImgX = screenW * 2 / 5;
        CGFloat iconImgY = margin * 2;

        self.iconImgFrame = CGRectMake(iconImgX, iconImgY, iconImgW, iconImgH);

        CGFloat iconNameX = iconImgX;
        CGFloat iconNameY = iconImgY + iconImgH;
        CGFloat iconNameW = iconImgW;
        CGFloat iconNameH = iconNameW / 2;

        self.iconNameFrame = CGRectMake(iconNameX, iconNameY, iconNameW, iconNameH);

        CGFloat tbViewX = screenEdgeMargin;
        CGFloat tbViewY = screenEdgeMargin;
        CGFloat tbViewW = screenW - screenEdgeMargin * 2;
        CGFloat tbViewH = screenH - tbViewY - tabBarHeight;

        self.tbViewFrame = CGRectMake(tbViewX, tbViewY, tbViewW, tbViewH);

        CGFloat cellX = 0;
        CGFloat cellY = margin;
        CGFloat cellW = tbViewW;
        CGFloat cellH = 40;
        self.cellFrame = CGRectMake(cellX, cellY, cellW, cellH);

    }
    return self;
}

@end
