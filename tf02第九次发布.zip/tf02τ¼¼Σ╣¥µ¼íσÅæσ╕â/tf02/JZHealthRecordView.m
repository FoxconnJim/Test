//
//  JZHealthRecordView.m
//  tf02
//
//  Created by F7686324 on 20/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHealthRecordView.h"
#import "NSMutableArray+JZHexDataToArray.h"
@interface JZHealthRecordView ()
{
    // 下载句柄
    NSURLSessionDownloadTask *_downloadTask;
}

@end

@implementation JZHealthRecordView
- (JZpromptLabel *)promptLabel
{
    if (!_promptLabel) {
        _promptLabel = [[JZpromptLabel alloc] init];
    }
    return _promptLabel;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - naviHeight - statusBarHeight) style:UITableViewStyleGrouped];
        _tbView.delegate = self;
        _tbView.dataSource = self;

    }
    return _tbView;
}

- (void)setJzType:(NSString *)jzType
{
    _jzType = jzType;
}


- (NSMutableArray *)firstArray
{
    if (!_firstArray) {
        _firstArray = [NSMutableArray array];
    }
    return _firstArray;
}

- (NSMutableArray *)secondArray
{
    if (!_secondArray) {
        _secondArray = [NSMutableArray array];
    }
    return _secondArray;
}

- (NSMutableArray *)thirdArray
{
    if (!_thirdArray) {
        _thirdArray = [NSMutableArray array];
    }
    return _thirdArray;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;

    }
    return _queue;
}

- (UILabel *)topLabel
{
    if (!_topLabel) {
        _topLabel = [[UILabel alloc] initWithFrame: CGRectMake(0, 10, screenW, 30)];
        _topLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _topLabel;
}

- (void)setJzdata:(JZData *)jzdata
{
    _jzdata = jzdata;
    NSLog(@"jzdata.id = %@" ,jzdata.ID);
    [self.tbView reloadData];
}

- (void)setBpData:(JZBloodPressureData *)bpData
{
    _bpData = bpData;
    NSLog(@"bpData.id = %@", bpData.ID);
    [self.tbView reloadData];
}

- (void)setHrData:(JZHeartRateData *)hrData
{
    _hrData = hrData;
    NSLog(@"hrData.id = %@", hrData.ID);

    NSLog(@"hrData.eegdata = %@", hrData.eegdata);
    if (hrData.eegdata && ![hrData.eegdata isEqualToString:@"<null>"]) {
        [self downFileFromServerWithURL:hrData.eegdata];
        //下载地址
//        NSURL *url = [NSURL URLWithString: hrData.eegdata];
        //保存路径
//        NSString *rootPath = [self dirDoc];
//        _filePath = [rootPath stringByAppendingPathComponent:@"wave.txt"];
//        AFHTTPRequestOperation *op = [[AFHTTPRequestOperation alloc] initWithRequest:[NSURLRequest requestWithURL:url]];
//        op.outputStream = [NSOutputStream outputStreamToFileAtPath:_filePath append:NO];

//        JZOperation *operation = [JZOperation operationWithURLString:hrData.eegdata andParam:nil getOrPost:JZ_GET];
//        operation.delegate = self;
        // 根据下载量设置进度条的百分比
//        [op setDownloadProgressBlock:^(NSUInteger bytesRead, long long totalBytesRead, long long totalBytesExpectedToRead) {
//            CGFloat precent = (CGFloat)totalBytesRead / totalBytesExpectedToRead;
//            NSLog(@"下载量百分比:%f", precent);
//
//        }];

//        [op setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
//            NSLog(@"下载成功");
//            [self getAllFileNames: @"wave.txt"];
//            [self.tbView reloadData];
//            
//        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//            
//            NSLog(@"下载失败");
//            self.promptLabel.jz_text = @"心电图数据下载失败";
//            [self addSubview:self.promptLabel];
//        }];
//        //开始下载
//        [self.queue addOperations:[NSArray arrayWithObject:op] waitUntilFinished:NO];

    }

}

//#pragma mark JZOperationDelegate Methods
//- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
//{
//    NSLog(@"下载失败");
//    self.promptLabel.jz_text = @"心电图数据下载失败";
//    [self addSubview:self.promptLabel];
//}
//
//- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
//{
//    NSLog(@"下载成功");
//    [self getAllFileNames: @"wave.txt"];
//    [self.tbView reloadData];
//}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview: self.tbView];
    }
    return self;
}
//获取Documents目录
-(NSString *)dirDoc{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    return documentsDirectory;
}

- (void)getAllFileNames:(NSString *)dirName
{
    // 获得此程序的沙盒路径
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);

    // 获取Documents路径
    // [patchs objectAtIndex:0]
    NSString *documentsDirectory = [paths objectAtIndex:0];

    //判断文件是否存在
    if (!documentsDirectory) {
        NSLog(@"Documents directory not found!");
    } else {
        NSString *fileDirectory = [documentsDirectory stringByAppendingPathComponent:dirName];

        if([[NSFileManager defaultManager] fileExistsAtPath:fileDirectory]){
            NSLog(@"File is found");
        }

        NSData *data = [NSData dataWithContentsOfFile:fileDirectory];
        NSMutableArray *array = [NSMutableArray arrayFromJZHexData:data];
        if (self.hrData.numberturns && ![self.hrData.numberturns isEqualToString:@"<null>"]) {
            if ([self.hrData.numberturns integerValue] == 1) {
                self.firstArray = array;
            } else {
                for (int i = 0; i < array.count; i += 3) {
                    [self.firstArray addObject: array[i]];
                }
                for (int i = 1; i < array.count; i += 3) {
                    [self.secondArray addObject: array[i]];
                }
                for (int i = 2; i < array.count; i += 3) {
                    [self.thirdArray addObject: array[i]];
                }
            }
        }
     }
}

- (void)downFileFromServerWithURL:(NSString *)url
{

    //远程地址
    NSURL *URL = [NSURL URLWithString:url];
    //默认配置
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];

    //AFN3.0+基于封装URLSession的句柄
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];

    //请求
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];

    //下载Task操作
    _downloadTask = [manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {

        // @property int64_t totalUnitCount;     需要下载文件的总大小
        // @property int64_t completedUnitCount; 当前已经下载的大小

        // 给Progress添加监听 KVO
        NSLog(@"percent = %f",1.0 * downloadProgress.completedUnitCount / downloadProgress.totalUnitCount);

    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {

        //- block的返回值, 要求返回一个URL, 返回的这个URL就是文件的位置的路径

        NSString *path = [[self dirDoc] stringByAppendingPathComponent:response.suggestedFilename];
        return [NSURL fileURLWithPath:path];

    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        NSLog(@"error = %@", error);
        //设置下载完成操作
        // filePath就是你下载文件的位置，你可以解压，也可以直接拿来使用
        if (error) {
            self.promptLabel.jz_text = @"下载失败";
            [self addSubview:self.promptLabel];
        } else {
            NSLog(@"下载成功");

            [self getAllFileNames:response.suggestedFilename];
            [self.tbView reloadData];
        }
        
    }];
    [_downloadTask resume];
}

#pragma mark UITableViewDataSource Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if ([self.jzType isEqualToString:@"心率"]) {
        if (self.hrData.numberturns.integerValue == 1) {
            return 2;
        } else {
            return 4;
        }
    } else {
        return 1;
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.jzType isEqualToString:@"血压"]) {
        if ([self.bpData.healthrecord isEqualToString:@"<null>"] || self.bpData.healthrecord.length == 0) {
            return 3;
        } else {
            return 4;
        }
    } else if ([self.jzType isEqualToString:@"心率"]) {
        if (section == 0) {
            if ([self.hrData.healthrecord isEqualToString:@"<null>"] || self.hrData.healthrecord.length == 0) {
                return 3;
            } else {
                return 4;
            }
        } else {
            return 1;
        }
    } else {
        if ([self.jzdata.healthrecord isEqualToString:@"<null>"] || self.jzdata.healthrecord.length == 0) {
            return 3;
        } else {
            return 4;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
        cell.separatorInset = UIEdgeInsetsZero;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (indexPath.row == 0) {

            if ([self.jzType isEqualToString:@"血压"]) {
                cell.textLabel.text = [self.bpData.meatime substringToIndex:16];
            } else if ([self.jzType isEqualToString:@"心率"]) {
                cell.textLabel.text = [self.hrData.meatime substringToIndex:16];
            } else {
                cell.textLabel.text = [self.jzdata.meatime substringToIndex:16];
            }


        } else if (indexPath.row == 1) {
            if ([self.jzType isEqualToString:@"血压"]) {
                cell.textLabel.text = self.bpData.physicalstate;
            } else if ([self.jzType isEqualToString:@"心率"]) {
                cell.textLabel.text = self.hrData.physicalstate;
            } else {
                cell.textLabel.text = self.jzdata.physicalstate;
            }
        } else if (indexPath.row == 2) {
            if ([self.jzType isEqualToString:@"血压"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"血压:%@/%@mmHg  脉搏:%@次/分钟", self.bpData.bpSp, self.bpData.bpDp, self.bpData.bpHr];
            } else if ([self.jzType isEqualToString:@"心率"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"心率:%@次/分钟", self.hrData.data];
            } else if ([self.jzType isEqualToString:@"血糖"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"血糖:%@mmol/L", self.jzdata.data];
            } else if ([self.jzType isEqualToString:@"血氧"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"血氧:%@%%", self.jzdata.data];
            } else if ([self.jzType isEqualToString:@"体脂"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"体脂:%@%%", self.jzdata.data];
            } else if ([self.jzType isEqualToString:@"体重"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"体重:%@kg", self.jzdata.data];
            }

        } else {
            cell.textLabel.numberOfLines = 0;

            if ([self.jzType isEqualToString:@"血压"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"备注:%@", self.bpData.healthrecord];

            } else if ([self.jzType isEqualToString:@"心率"]) {
                cell.textLabel.text = [NSString stringWithFormat:@"备注:%@", self.hrData.healthrecord];
                
            } else {
                cell.textLabel.text = [NSString stringWithFormat:@"备注:%@", self.jzdata.healthrecord];

            }
        }
        return cell;

    } else {
        JZECGCell *cell = [JZECGCell ECGCellWithTableView:tableView];

        if (indexPath.section == 1) {
            cell.lblTurns.text = @"I";
            cell.dataView.lblText = @"I";

            cell.dataView.jzHeight = 192;
            cell.dataArray = self.firstArray;
            cell.dataView.delegate = self;

        } else if (indexPath.section == 2) {
            cell.lblTurns.text = @"II";
            cell.dataView.lblText = @"II";

            cell.dataView.jzHeight = 192;
            cell.dataArray = self.secondArray;
            cell.dataView.delegate = self;

        } else if (indexPath.section == 3) {
            cell.lblTurns.text = @"III";
            cell.dataView.lblText = @"III";

            cell.dataView.jzHeight = 192;
            cell.dataArray = self.thirdArray;
            cell.dataView.delegate = self;

        }
        return cell;

    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 3) {
            if ([self.jzType isEqualToString:@"血压"]) {
                if ([self.bpData.healthrecord isEqualToString:@"<null>"] || self.bpData.healthrecord.length == 0) {
                    return 0;
                } else {
                    CGFloat height = [self.bpData.healthrecord textSizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(screenW - 30, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping].height + 17;
                    NSLog(@"height = %f", height);
                    return height;
                }
            } else if ([self.jzType isEqualToString:@"心率"]) {
                if ([self.hrData.healthrecord isEqualToString:@"<null>"] || self.hrData.healthrecord.length == 0) {
                    return 0;
                } else {
                    return [self.hrData.healthrecord textSizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(screenW - 30, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping].height + 17;
                }
            } else {
                if ([self.jzdata.healthrecord isEqualToString:@"<null>"] || self.jzdata.healthrecord.length == 0) {
                    return 0;
                } else {
                    return [self.jzdata.healthrecord textSizeWithFont:[UIFont systemFontOfSize:17] constrainedToSize:CGSizeMake(screenW - 30, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping].height + 17;
                }
            }
        } else {
            return 44;
        }
    } else {
        return 192;

    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

#pragma mark JZDataViewDelegate Methods
- (void)showECGGainWithECGDataView:(JZECGDataView *)ECGDataView
{
    [self.delegate showECGGainWithECGDataView:ECGDataView];
}


@end
