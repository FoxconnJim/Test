//
//  JZHPbangzhuViewController.m
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHPbangzhuViewController.h"
#import "Utility.h"
#import "JZbangzhuTableView.h"
#import "JZHPyijianfankuiViewController.h"
#import "JZOperation.h"

#import "JZBangzhuModel.h"

@interface JZHPbangzhuViewController () <JZOperationDelegate>

@property (nonatomic, strong) JZbangzhuTableView *bangzhuTBView;
@property (nonatomic, strong) NSMutableArray *sectionArray;
@property (nonatomic, strong) NSMutableArray *rowArray;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, strong) UILabel *tips;

@end

@implementation JZHPbangzhuViewController

- (UILabel *)tips
{
    if (!_tips) {
        _tips = [[UILabel alloc] initWithFrame:self.bangzhuTBView.bounds];
        _tips.textAlignment = NSTextAlignmentCenter;
        _tips.text = @"暂无帮助内容~";
        _tips.textColor = [UIColor grayColor];
    }
    return _tips;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (NSMutableArray *)sectionArray
{
    if (!_sectionArray) {
        _sectionArray = [NSMutableArray array];
    }
    return _sectionArray;
}

- (NSMutableArray *)rowArray
{
    if (!_rowArray) {
        _rowArray = [NSMutableArray array];

    }
    return _rowArray;
}

- (JZbangzhuTableView *)bangzhuTBView
{
    if (!_bangzhuTBView) {
        _bangzhuTBView = [[JZbangzhuTableView alloc] initWithFrame:CGRectMake(screenEdgeMargin, screenEdgeMargin, screenW - screenEdgeMargin * 2, screenH - naviHeight - statusBarHeight - screenEdgeMargin * 2 -60)];
        _bangzhuTBView.layer.cornerRadius = 10;
        _bangzhuTBView.layer.masksToBounds = YES;
    }
    return _bangzhuTBView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"帮助与反馈";
    self.view.backgroundColor = appBackgroundColor;

    [self.view addSubview: self.bangzhuTBView];
    
    //意见反馈按钮
    UIButton *yijianfankuiBtn = [[UIButton alloc] initWithFrame:CGRectMake(60, screenH - naviHeight - statusBarHeight - screenEdgeMargin - 55, screenW - 120, 45)];
    [yijianfankuiBtn addTarget:self action:@selector(BtnPress) forControlEvents:UIControlEventTouchUpInside];
    yijianfankuiBtn.backgroundColor = [UIColor blueColor];
    yijianfankuiBtn.layer.cornerRadius = 22.5;
    yijianfankuiBtn.layer.masksToBounds = YES;
    [yijianfankuiBtn setTitle:@"意见反馈" forState:UIControlStateNormal];
    [yijianfankuiBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [yijianfankuiBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateHighlighted];

    [self.view addSubview:yijianfankuiBtn];

}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [LCProgressHUD showInfoMsg:@"加载中..."];
    JZOperation *operation = [JZOperation operationWithURLString:getHelplistURL andParam:nil getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = getHelplistOperation;
}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [LCProgressHUD showInfoMsg:@"网络有点卡..."];
        [self.tips removeFromSuperview];
        self.tips.text = @"网络有点卡...";
        [self.bangzhuTBView addSubview:self.tips];
    }
}

- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    [LCProgressHUD hide];
    if (responseObject) {
        [self.tips removeFromSuperview];
        NSArray *arr = responseObject[@"data"];
        NSLog(@"arr = %@", arr);
        if ([arr isKindOfClass:[NSArray class]]) {
            [self.sectionArray removeAllObjects];
            [self.rowArray removeAllObjects];
            for (NSDictionary *dict in arr) {
                JZBangzhuModel *bangzhuModel = [JZBangzhuModel bangzhuModelWithDict:dict];
                [self.sectionArray addObject:bangzhuModel.helpTitle];
                [self.rowArray addObject:bangzhuModel.helpContent];
            }
            if (self.sectionArray.count && self.rowArray.count) {
                self.bangzhuTBView.sectionArray = self.sectionArray;
                self.bangzhuTBView.rowArray = self.rowArray;
                [self.bangzhuTBView reloadData];
            } else {
                self.tips.text = @"暂无帮助内容~";
                [self.bangzhuTBView addSubview:self.tips];
            }

        } else {
            [self.bangzhuTBView addSubview:self.tips];
        }
    } else {
        [self.bangzhuTBView addSubview:self.tips];
    }
}

- (void)BtnPress
{
    NSLog(@"~~~~~~press~~~");
    JZHPyijianfankuiViewController *fankuiVC = [[JZHPyijianfankuiViewController alloc] init];
    [self.navigationController pushViewController:fankuiVC animated:YES];
}

@end
