//
//  CaptchaView.h
//  purecode (OC)
//
//  Created by Jim on 15-9-14.
//  Copyright (c) 2015年 Jim. All rights reserved.
//

#ifndef purecode__OC__CaptchaView_h
#define purecode__OC__CaptchaView_h

#import <UIKit/UIKit.h>

@interface CaptchaView : UIView

@property (nonatomic, retain) NSArray *changeArray; //字符素材数组
@property (nonatomic, retain) NSMutableString *changeString;  //验证码的字符串

@end
#endif
