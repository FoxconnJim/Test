//
//  JZSelectCityTableViewController.m
//  tf02
//
//  Created by F7686324 on 16/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZSelectCityTableViewController.h"
#import "Utility.h"
#import "JZCityModel.h"
#import "JZSelectCountyTableViewController.h"
#import "NSString+JZChineseToPinyin.h"
@interface JZSelectCityTableViewController ()
@property (nonatomic, strong) NSMutableArray *cityArray;
@property (nonatomic, strong) NSMutableArray *indexArray;
@property (nonatomic, strong) NSMutableDictionary *dataDictionary;

@property (nonatomic, strong) JZSelectCountyTableViewController *selectCountyTBVC;
@end

@implementation JZSelectCityTableViewController

- (NSMutableArray *)cityArray
{
    if (!_cityArray) {
        _cityArray = [NSMutableArray array];
    }
    return _cityArray;
}

- (NSMutableArray *)indexArray
{
    if (!_indexArray) {
        _indexArray = [NSMutableArray array];
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            [_indexArray addObject:[NSString stringWithFormat:@"%c", ch]];
        }
    }
    return _indexArray;
}

- (NSMutableDictionary *)dataDictionary
{
    if (!_dataDictionary) {
        _dataDictionary = [NSMutableDictionary dictionary];
    }
    return _dataDictionary;
}

- (void)setJzProvinceModel:(JZProvinceModel *)jzProvinceModel
{
    _jzProvinceModel = jzProvinceModel;
    NSArray *cityArray = jzProvinceModel.city;
    if ([cityArray isKindOfClass:[NSArray class]]) {
        [self.cityArray removeAllObjects];
        for (NSDictionary *cityDict in cityArray) {
            JZCityModel *cityModel = [JZCityModel cityModelWithDict:cityDict];
            [self.cityArray addObject:cityModel];
        }
        NSMutableArray *indexArr = [NSMutableArray array];
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            [indexArr addObject:[NSString stringWithFormat:@"%c", ch]];
        }
        
        NSMutableDictionary *dataDict = [NSMutableDictionary dictionary];
        for (NSString *charStr in indexArr) {
            NSMutableArray *array = [NSMutableArray array];
            [dataDict setObject:array forKey:charStr];
        }
        
        for (JZCityModel *model in self.cityArray) {
            NSString *firstLetter = [[[model.city chineseToPinyin] substringToIndex:1] uppercaseString];
            NSMutableArray *array = dataDict[firstLetter];
            [array addObject:model];
        }
        
        self.dataDictionary = [dataDict mutableCopy];
        [dataDict enumerateKeysAndObjectsUsingBlock:^(id key,id obj, BOOL *stop) {
            obj = [[obj sortedArrayUsingComparator:^NSComparisonResult(JZCityModel *obj1, JZCityModel *obj2)
                    {
                        NSComparisonResult result = [[[obj1.city chineseToPinyin] lowercaseString] compare:[[obj2.city chineseToPinyin] lowercaseString]];
                        return result == NSOrderedDescending;// 升序
                    }]mutableCopy];
            [self.dataDictionary setObject:obj forKey:key];
        }];
        
        for (int i = 0; i < indexArr.count; i++) {
            NSString *charStr = indexArr[i];
            NSMutableArray *array = self.dataDictionary[charStr];
            NSLog(@"charStr = %@", charStr);
            if (!array.count) {
                [self.indexArray removeObject:charStr];
                [self.dataDictionary removeObjectForKey:charStr];
            }
        }
        [self.tableView reloadData];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选择城市";
}

#pragma mark UITableViewDelegate && UITableViewDataSource methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *key = self.indexArray[section];
    NSMutableArray *array = self.dataDictionary[key];
    return array.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.indexArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"ProvinceCellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }

    NSString *key = self.indexArray[indexPath.section];
    NSMutableArray *array = self.dataDictionary[key];
    JZCityModel *model = array[indexPath.row];
    cell.textLabel.text = model.city;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    NSString *key = self.indexArray[indexPath.section];
    NSMutableArray *array = self.dataDictionary[key];
    JZCityModel *model = array[indexPath.row];
    NSLog(@"name = %@", model.city);
    _selectCountyTBVC = [[JZSelectCountyTableViewController alloc] init];
    _selectCountyTBVC.jzCityModel = model;
    NSMutableDictionary *selectedAddressDict = [NSMutableDictionary valueByKey:kSelectedAddressDict];
    selectedAddressDict[@"city"] = model.city;
    [selectedAddressDict storeValueByKey:kSelectedAddressDict];
    [self.navigationController pushViewController:_selectCountyTBVC animated:YES];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return self.indexArray[section];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return self.indexArray;
}


@end
