//
//  JZHomePageViewController.h
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JZHomePageSection, JZFamilyIconView;
@interface JZHomePageViewController : UIViewController

@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) JZFamilyIconView *familyIconView;
@property (nonatomic, strong) JZHomePageSection *todayRemindSection;
@property (nonatomic, strong) JZHomePageSection *todayRecommendSection;
@property (nonatomic, strong) NSOperationQueue *queue;

@property (nonatomic) BOOL isVisitors;

@end
