//
//  JZNewsCell.h
//  tf02
//
//  Created by AN PEN on 8/8/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZHotNews.h"
#import "Utility.h"

@interface JZNewsCell : UITableViewCell

@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *title;
@property (nonatomic, strong) UILabel *content;
@property (nonatomic, strong) JZHotNews *hotNews;

+ (JZNewsCell *)cellWithTableView: (UITableView *)tableView;

@end
