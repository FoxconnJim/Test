//
//  JZpromptLabel.m
//  tf02
//
//  Created by Jim on 16/8/19.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZpromptLabel.h"

@implementation JZpromptLabel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        self.layer.cornerRadius = 5;
        self.layer.masksToBounds = YES;
        self.numberOfLines = 0;
        self.textAlignment = NSTextAlignmentCenter;
        self.adjustsFontSizeToFitWidth = YES;
        self.textColor = [UIColor whiteColor];
        self.isRemoved = YES;
    }
    return self;
}

- (void)setJz_text:(NSString *)jz_text
{
    _jz_text = jz_text;
    self.isRemoved = YES;
    self.text = jz_text;
    NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:20]};
    CGSize size = [jz_text boundingRectWithSize:CGSizeMake(screenW * 2 / 3, MAXFLOAT) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    self.frame = CGRectMake((screenW - size.width) / 2, screenH * 2 / 3, size.width, size.height * 2);
    self.textColor = [UIColor whiteColor];
    self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    [NSObject cancelPreviousPerformRequestsWithTarget: self];
    [self performSelector:@selector(threadEvent:) withObject:self afterDelay:2];

}

- (void)setIsRemoved:(BOOL)isRemoved
{
    _isRemoved = isRemoved;
}

- (void)threadEvent: (id)sender
{
    if (self.isRemoved) {
        [self removeFromSuperview];

    }
}

@end
