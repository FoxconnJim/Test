function connectWebViewJavascriptBridge(callback) {
	if (window.webViewJavascriptBridge) {
		callback(webViewJavascriptBridge)
	} else {
		document.addEventListener('webViewJavascriptBridgeReady', function() {
			callback(webViewJavascriptBridge)
		}, false)
	}
}

connectWebViewJavascriptBridge(function(bridge) {
	bridge.init(function(message, responseCallback) {
		log('JS got a message', message)
		var data = {
			'Javascript Responds':'Wee!'}
		}
		log('JS responding with' data)
		responseCallback(data)
	})
})