//
//  JZPadScaleView2017.m
//  tf02
//
//  Created by F7686324 on 2017/1/13.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZPadScaleView2017.h"
#import "NSArray+JZRemoveByInteval.h"
#import "NSString+JZGetStringWidth.h"

@implementation JZPadScaleView2017

- (UISegmentedControl *)segment
{
    if (!_segment) {
        _segment = [[JZSegment alloc] init];
    }
    return _segment;
}

- (JZTimeView2017 *)timeView
{
    if (!_timeView) {
        _timeView = [[JZTimeView2017 alloc] initWithFrame:self.bounds];
    }
    return _timeView;
}

- (void)setTextArray:(NSMutableArray *)textArray
{
    _textArray = textArray;
}

- (void)setPointArray:(NSMutableArray *)pointArray
{
    _pointArray = pointArray;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.jzScale = 1.f;
        [self addSubview:self.timeView];
    }
    return self;
}

- (JZTime *)jzTime
{
    if (!_jzTime) {
        _jzTime = [[JZTime alloc] init];
    }
    return _jzTime;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    _timeLengthString = timeLengthString;

    self.timeView.timeLengthString = timeLengthString;
    self.timeView.frame = CGRectZero;
    [self.segment removeFromSuperview];

    CGRect frame = self.frame;
    CGFloat margin = 5;
    CGFloat jzWidth = screenW - screenEdgeMargin * 2 - margin * 2;
    frame.size.width = jzWidth * self.jzScale;
    self.frame = frame;
    self.timeView.frame = self.bounds;
    if (self.textArray.count) {
        CGFloat scaleWidth = 0;
        for (NSString *text in self.textArray) {
            if ([text getStringWidth] > scaleWidth) {
                scaleWidth = [text getStringWidth];
            }
        }
        scaleWidth += 10;
        for (int i = 0; i < self.textArray.count; i++) {
            NSMutableArray *textArr = [self.textArray removeByInteval:i];
            CGFloat width = self.bounds.size.width / textArr.count;

            if (width >= scaleWidth) {
                self.timeView.textArray = textArr;
                self.timeView.pointArray = [self.pointArray removeByInteval:i];
                break;
            }
        }
    }

}

- (void)setJzScale:(CGFloat)jzScale
{
    _jzScale = jzScale;

    [self jzSetNeedsDisplay];
}

- (void)jzSetNeedsDisplay
{
    CGRect frame = self.frame;
    CGFloat margin = 5;
    CGFloat jzWidth = screenW - screenEdgeMargin * 2 - margin * 2;
    frame.size.width = jzWidth * self.jzScale;
    self.frame = frame;
    self.timeView.frame = self.bounds;

    if (self.textArray.count) {
        CGFloat scaleWidth = 0;
        for (NSString *text in self.textArray) {
            if ([text getStringWidth] > scaleWidth) {
                scaleWidth = [text getStringWidth];
            }
        }
        scaleWidth += 10;
        for (int i = 0; i < self.textArray.count; i++) {
            NSMutableArray *textArr = [self.textArray removeByInteval:i];
            CGFloat width = self.bounds.size.width / textArr.count;

            if (width >= scaleWidth) {
                self.timeView.textArray = textArr;
                self.timeView.pointArray = [self.pointArray removeByInteval:i];
                break;
            }
        }
    }

}

@end
