//
//  JZDataPoint.h
//  tf02
//
//  Created by F7686324 on 01/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZDataPoint : NSObject

@property (nonatomic, copy) NSString *meatime;
@property (nonatomic, copy) NSString *data;

- (instancetype)initWithMeatime:(NSString *)meatime data:(NSString *)data;
+ (instancetype)dataPointWithMeatime:(NSString *)meatime data:(NSString *)data;

@end
