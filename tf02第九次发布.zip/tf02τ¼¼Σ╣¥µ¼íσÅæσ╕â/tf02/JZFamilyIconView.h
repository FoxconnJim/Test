//
//  JZFamilyIconView.h
//  tf02
//
//  Created by Jim on 16/3/11.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZFamilyIconFrame.h"
#import "JZPersonInfo.h"
#import "JZHomePageIconView.h"
#import "JZFamilyInfo.h"

@class JZFamilyIconFrame;
@interface JZFamilyIconView : UIView
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIScrollView *iconScrollView;
@property (nonatomic, strong) NSMutableArray *personArray;
@property (nonatomic, strong) NSMutableArray *personInfoArray;
@property (nonatomic, strong) JZFamilyIconFrame *familyIconFrame;
@property (nonatomic, strong) UIImageView *tickImgView;

@end
