//
//  JZHealthServicesOptView.m
//  tf02
//
//  Created by F7686324 on 2016/12/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZHealthServicesOptView.h"

@implementation JZHealthServicesOptView

- (UIImageView *)imgView
{
    if (!_imgView) {
        _imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 75, 75)];
        _imgView.layer.cornerRadius = 37.5;
        _imgView.layer.masksToBounds = YES;

    }
    return _imgView;
}

- (UILabel *)lbl
{
    if (!_lbl) {
        _lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, 87, 75, 17)];
        _lbl.textAlignment = NSTextAlignmentCenter;
        _lbl.adjustsFontSizeToFitWidth = YES;
    }
    return _lbl;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.imgView];
        [self addSubview:self.lbl];
    }
    return self;
}

@end
