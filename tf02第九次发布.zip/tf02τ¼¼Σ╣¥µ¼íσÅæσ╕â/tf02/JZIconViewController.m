//
//  JZIconViewController.m
//  tf02
//
//  Created by F7686324 on 17/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZIconViewController.h"
#import "Utility.h"
#import "JZFamilyInfo.h"

@interface JZIconViewController () <UIGestureRecognizerDelegate, UIScrollViewDelegate>

@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *imageView;


@end

@implementation JZIconViewController

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

-(void)loadView
{
    [super loadView];

    UIView *view = [[UIView alloc] initWithFrame:self.view.bounds];
    view.backgroundColor = [UIColor blackColor];
    self.view = view;
    _scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];//申明一个scrollview
    _scrollView.delegate = self;//需要在.h中引用scrollview的delegate
    _scrollView.backgroundColor = [UIColor blackColor];
    _scrollView.alpha = 1.0;

    JZFamilyInfo *familyInfo = [JZFamilyInfo valueByKey:kFamilyInfo];
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, (screenH - screenW) / 2, 3750, 6670)];//申明一个imageview
    [_imageView sd_setImageWithURL:[NSURL URLWithString:familyInfo.photo] placeholderImage:[UIImage imageNamed:@"默认"]];
    UITapGestureRecognizer* tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesAction:)];//给imageview添加tap手势
    _imageView.userInteractionEnabled = YES;
    [_scrollView addSubview:_imageView];//需要将imageview添加到scrollview上
    [self.view addSubview:_scrollView];
    [_imageView addGestureRecognizer:tap];

    float minimumScale = [_scrollView frame].size.width / [_imageView frame].size.width;//设置缩放比例
    [_scrollView setMinimumZoomScale:minimumScale];//设置最小的缩放大小
    [_scrollView setZoomScale:minimumScale];//设置scrollview的缩放
    //    [_scrollView setMaximumZoomScale:10000000.0];//设置最大的缩放大小
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor blackColor];
    _scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];//申明一个scrollview
    _scrollView.delegate = self;//需要在.h中引用scrollview的delegate
    _scrollView.backgroundColor = [UIColor blackColor];
    _scrollView.alpha = 1.0;

    JZFamilyInfo *familyInfo = [JZFamilyInfo valueByKey:kFamilyInfo];
    _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, (screenH - screenW) / 2, 3000, 3000)];//申明一个imageview
    [_imageView sd_setImageWithURL:[NSURL URLWithString:familyInfo.photo] placeholderImage:[UIImage imageNamed:@"默认"]];
    UITapGestureRecognizer* tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesAction:)];//给imageview添加tap手势
    _imageView.userInteractionEnabled = YES;
    [_scrollView addSubview:_imageView];//需要将imageview添加到scrollview上
    [self.view addSubview:_scrollView];
    [_imageView addGestureRecognizer:tap];

    float minimumScale = [_scrollView frame].size.width / [_imageView frame].size.width;//设置缩放比例
    [_scrollView setMinimumZoomScale:minimumScale];//设置最小的缩放大小
    [_scrollView setZoomScale:minimumScale];//设置scrollview的缩放
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tapGesAction:(UIGestureRecognizer*)gestureRecognizer//手势执行事件
{
//    float newscale = 0.2 * 1.5;
//    CGRect zoomRect = [self zoomRectForScale:newscale withCenter:[gestureRecognizer locationInView:gestureRecognizer.view]];
//    NSLog(@"zoomRect:%@",NSStringFromCGRect(zoomRect));
//    [ _scrollView zoomToRect:zoomRect animated:YES];//重新定义其cgrect的x和y值
//    //    [_scrollView setZoomScale:newscale animated:YES];//以原先中心为点向外扩
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView//scrollview的delegate事件。需要设置缩放才会执行。
{
    return _imageView;
}


- (CGRect)zoomRectForScale:(float)scale withCenter:(CGPoint)center {//传入缩放比例和手势的点击的point返回缩放后的scrollview的大小和X、Y坐标点

    CGRect zoomRect;

    // the zoom rect is in the content view's coordinates.
    //    At a zoom scale of 1.0, it would be the size of the imageScrollView's bounds.
    //    As the zoom scale decreases, so more content is visible, the size of the rect grows.
    zoomRect.size.height = [_scrollView frame].size.height / scale;
    zoomRect.size.width  = [_scrollView frame].size.width  / scale;

    // choose an origin so as to get the right center.
    zoomRect.origin.x    = center.x - (zoomRect.size.width  / 2.0);
    //    zoomRect.origin.x=center.x;
    //    zoomRect.origin.y=center.y;
    zoomRect.origin.y    = center.y - (zoomRect.size.height / 2.0);

    return zoomRect;
}


@end
