//
//  JZLineChartFrame.h
//  tf02
//
//  Created by Jim on 16/3/18.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JZLineChartFrame : NSObject

@property (nonatomic, assign) CGRect titleLabelFrame;
@property (nonatomic, assign) CGRect imgViewFrame;
@property (nonatomic, assign) CGRect valueLabelFrame;
@property (nonatomic, assign) CGRect timeLabelFrame;
@property (nonatomic, assign) CGRect topLineFrame;
@property (nonatomic, assign) CGRect bottomLineFrame;
@property (nonatomic, assign) CGRect maxValueFrame;
@property (nonatomic, assign) CGRect minValueFrame;
@property (nonatomic, assign) CGRect scaleViewFrame;
@property (nonatomic, assign) CGRect dataViewFrame;
@property (nonatomic, assign) CGRect scrollViewFrame;
@property (nonatomic, assign) CGRect indicatorFrame;
- (instancetype)initWithFrame: (CGRect)frame;

@end
