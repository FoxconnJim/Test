//
//  JZSoundTools.h
//  tf02
//
//  Created by F7686324 on 29/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"

@interface JZSoundTools : NSObject

// 单例宏
singleton_interface(JZSoundTools)

// 要播放的音效名
- (void)playSoundWithName:(NSString *)name;

@end
