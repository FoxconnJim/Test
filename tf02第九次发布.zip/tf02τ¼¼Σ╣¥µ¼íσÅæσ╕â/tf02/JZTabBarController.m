//
//  JZTabBarController.m
//  tf02
//
//  Created by AN PEN on 5/16/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZTabBarController.h"
#import "JZPersonInfo.h"
#import "LCProgressHUD.h"

@interface JZTabBarController () <UITabBarControllerDelegate>

@end

@implementation JZTabBarController

- (JZHomePageViewController *)homePageVC
{
    if (!_homePageVC) {
        _homePageVC = [[JZHomePageViewController alloc]init];
        _homePageVC.tabBarItem.title = @"首页";
        _homePageVC.tabBarItem.image = [UIImage imageNamed:@"homePage"];
        _homePageVC.tabBarItem.selectedImage = [UIImage imageNamed:@"homePageSelected"];
    }
    return _homePageVC;
}

- (JZHealthIndicatorViewController *)healthIndicatorVC
{
    if (!_healthIndicatorVC) {
        _healthIndicatorVC = [[JZHealthIndicatorViewController alloc]init];
        _healthIndicatorVC.tabBarItem.title = @"健康指标";
        _healthIndicatorVC.tabBarItem.image = [UIImage imageNamed:@"healthIndicator"];
        _healthIndicatorVC.tabBarItem.selectedImage = [UIImage imageNamed:@"healthIndicatorSelected"];
    }
    return _healthIndicatorVC;
}

- (JZHealthServicesViewController *)healthServicesVC
{
    if (!_healthServicesVC) {
        _healthServicesVC = [[JZHealthServicesViewController alloc]init];
        _healthServicesVC.tabBarItem.title = @"健康服务";
        _healthServicesVC.tabBarItem.image = [UIImage imageNamed:@"healthServices"];
        _healthServicesVC.tabBarItem.selectedImage = [UIImage imageNamed:@"healthServicesSelected"];
    }
    return _healthServicesVC;
}

- (JZMineViewController *)mineVC
{
    if (!_mineVC) {
        _mineVC = [[JZMineViewController alloc]init];
        _mineVC.tabBarItem.title = @"我的";
        _mineVC.tabBarItem.image = [UIImage imageNamed:@"mine"];
        _mineVC.tabBarItem.selectedImage = [UIImage imageNamed:@"mineSelected"];
    }
    return _mineVC;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear: animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBar.translucent = YES;
    self.tabBar.barStyle = UIBarStyleDefault;
    self.tabBar.itemPositioning = UITabBarItemPositioningFill;
    self.delegate = self;
    self.viewControllers = @[self.homePageVC, self.healthIndicatorVC, self.healthServicesVC, self.mineVC];

}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    [LCProgressHUD hide];
//    [JZOperation cancelAFHTTPRequest];
    NSLog(@"didSelectTabBarController");
//    tabBarController.navigationItem.rightBarButtonItem = nil;
//    tabBarController.navigationItem.leftBarButtonItem = nil;
    if (self.selectedIndex == 0) {
        NSLog(@"homePageVC");
        tabBarController.navigationItem.title = @"首页";

    } else if (self.selectedIndex == 1) {
        NSLog(@"healthIndicatorVC");
        tabBarController.navigationItem.title = @"健康指标";

    } else if (self.selectedIndex == 2) {
        NSLog(@"healthServicesVC");
        tabBarController.navigationItem.title = @"健康服务";
    } else if (self.selectedIndex == 3) {
        NSLog(@"mineVC");
        tabBarController.navigationItem.title = @"我的";
        [self.mineVC.mineView.tbView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
    }
}

@end
