//
//  JZlishitixingViewController.m
//  tf02
//
//  Created by F7686324 on 2017/1/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZlishitixingViewController.h"
#import "Utility.h"
#import "JZOperation.h"
#import "JZTodayRemindData.h"
#import "MJRefresh.h"
#import "JZTodayRemindCell.h"


@interface JZlishitixingViewController () <UITableViewDelegate, UITableViewDataSource, JZOperationDelegate>
{
    NSInteger jz_count;
}
@property (nonatomic, strong) UITableView *tbView;
@property (nonatomic, strong) UILabel *tips;
@property (nonatomic, strong) NSMutableArray *remindDataArray;
@property (nonatomic, strong) NSMutableArray *remindCellHeightArray;
@property (nonatomic, strong) NSOperationQueue *queue;
@end

@implementation JZlishitixingViewController

- (void)setMemberId:(NSString *)memberId
{
    _memberId = memberId;
}

-(UILabel *)tips
{
    if (!_tips) {
        _tips = [[UILabel alloc] initWithFrame:CGRectMake(0, (self.view.frame.size.height - 20) / 2, self.view.frame.size.width, 20)];
        _tips.textAlignment = NSTextAlignmentCenter;
        _tips.text = @"暂无提醒消息～";
        _tips.textColor = [UIColor grayColor];
    }
    return _tips;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH - 64)];
        _tbView.dataSource = self;
        _tbView.delegate = self;
        _tbView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tbView;
}

- (NSMutableArray *)remindDataArray
{
    if (!_remindDataArray) {
        _remindDataArray = [NSMutableArray array];
    }
    return _remindDataArray;
}

- (NSMutableArray *)remindCellHeightArray
{
    if (!_remindCellHeightArray) {
        _remindCellHeightArray = [NSMutableArray array];
    }
    return _remindCellHeightArray;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"历史提醒";
    self.view.backgroundColor = appBackgroundColor;
    [self.view addSubview:self.tbView];
    [self.tbView addSubview:self.tips];
    jz_count = 0;

}

- (void)setCanHistoryRemindRefresh:(BOOL)canHistoryRemindRefresh
{
    _canHistoryRemindRefresh = canHistoryRemindRefresh;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    self.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        jz_count = 0;
        [self sendRequest];

    }];

    self.tbView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self sendRequest];
    }];

    if (self.canHistoryRemindRefresh) {
        [self.tbView.mj_header beginRefreshing];
    } else {
        if (!self.remindDataArray.count) {
            [self sendRequest];
        }
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [LCProgressHUD hide];
}
- (void)sendRequest
{
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"tel"] = [[JZFamilyInfo valueByKey:kFamilyInfo] tel];
    param[@"memberId"] = self.memberId;
    if (!jz_count) {
        param[@"id"] = @"0";

    } else {
        JZTodayRemindData *remindData = self.remindDataArray[jz_count - 1];
        param[@"id"] = remindData.ID;
    }
    NSLog(@"param = %@", param);
    [LCProgressHUD showInfoMsg:@"加载中..."];

    JZOperation *operation = [JZOperation operationWithURLString:historyRemindURL andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
}

#pragma mark UITableViewDelegate, UITableViewDataSource Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.remindDataArray.count;

}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JZTodayRemindCell *cell = [JZTodayRemindCell cellWithTableView:tableView cellID:@"JZlishitixingViewController-cellID"];

    NSNumber *cellHeight = self.remindCellHeightArray[indexPath.row];
    cell.cellHeight = cellHeight.floatValue;
    cell.todayRemindData = self.remindDataArray[indexPath.row];
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSNumber *cellHeight = self.remindCellHeightArray[indexPath.row];
    return cellHeight.floatValue;

}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 10)];
    headerView.backgroundColor = appBackgroundColor;
    return headerView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

#pragma mark JZOperationDelegate Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSLog(@"responseObject = %@", responseObject);
    [LCProgressHUD hide];
    NSArray *arr = (NSArray *)responseObject[@"data"];
    if ([arr isKindOfClass:[NSArray class]]) {
        if (!jz_count) {
            [self.remindDataArray removeAllObjects];
            [self.remindCellHeightArray removeAllObjects];
        }

        NSLog(@"todayArr.count = %lu", (unsigned long)arr.count);

        for (NSDictionary *dict in arr) {
            JZTodayRemindData *todayRemindData = [JZTodayRemindData todayRemindDataWithDict: dict];
            [self.remindDataArray addObject: todayRemindData];
            CGSize size = [todayRemindData.remindContent textSizeWithFont:[UIFont systemFontOfSize:15] constrainedToSize:CGSizeMake(screenW - 100, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping];
            NSNumber *cellHeight = [NSNumber numberWithFloat:size.height + 50];
            [self.remindCellHeightArray addObject:cellHeight];
        }

        [self.tbView.mj_header endRefreshing];
        if (arr.count < 10) {
            jz_count += arr.count;

            [self.tbView.mj_footer endRefreshingWithNoMoreData];
        } else {
            jz_count += 10;

            [self.tbView.mj_footer endRefreshing];

        }
    } else {
        [self.tbView.mj_header endRefreshing];
        [self.tbView.mj_footer endRefreshingWithNoMoreData];
    }
    NSLog(@"self.todayRemindDataArray.count = %lu", (unsigned long)self.remindDataArray.count);

    //        self.todayTBView.dataArray = [self.remindDataArray orderByTime];


    if (self.remindDataArray.count) {
        [self.tips removeFromSuperview];
    } else {
        self.tips.text = @"暂无提醒消息~";
        [self.tbView addSubview:self.tips];

    }
    [self.tbView reloadData];
}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        [self.tips removeFromSuperview];
        self.tips.text = @"网络有点卡...";
        [self.tbView addSubview:self.tips];

        [self.tbView.mj_header endRefreshing];
        [self.tbView.mj_footer endRefreshing];
        [LCProgressHUD showInfoMsg:@"网络有点卡..."];
    } else {
        [self.tbView.mj_header endRefreshing];
        [self.tbView.mj_footer endRefreshing];
    }
}
@end
