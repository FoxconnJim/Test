//
//  JZCityModel.m
//  tf02
//
//  Created by Jim on 2016/11/28.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZCityModel.h"
#import "NSDictionary+JSONString.h"
@implementation JZCityModel
- (instancetype)initWithDict:(NSDictionary *)dict
{
    NSLog(@"dict = %@", [dict JSONString]);
    if (self = [super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}

+ (instancetype)cityModelWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}
@end
