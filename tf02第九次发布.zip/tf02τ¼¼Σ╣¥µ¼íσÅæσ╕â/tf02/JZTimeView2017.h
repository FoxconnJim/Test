//
//  JZTimeView2017.h
//  tf02
//
//  Created by F7686324 on 2017/1/13.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZTimeView2017 : UIView

@property (nonatomic, strong) NSMutableArray *pointArray;
@property (nonatomic, copy) NSString *timeLengthString;
@property (nonatomic, strong) NSMutableArray *textArray;
@property (nonatomic, strong) NSMutableArray *textFrameArray;

@end
