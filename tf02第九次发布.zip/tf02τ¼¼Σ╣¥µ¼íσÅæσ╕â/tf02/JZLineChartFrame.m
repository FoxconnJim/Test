//
//  JZLineChartFrame.m
//  tf02
//
//  Created by Jim on 16/3/18.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZLineChartFrame.h"

@implementation JZLineChartFrame

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        CGFloat margin = 5;

        CGFloat imgViewX = margin;
        CGFloat imgViewY = margin;
        CGFloat imgViewW = frame.size.height / 6;
        CGFloat imgViewH = imgViewW;

        self.imgViewFrame = CGRectMake(imgViewX, imgViewY, imgViewW, imgViewH);

        CGFloat titleLabelX = imgViewX + imgViewW + margin;
        CGFloat titleLabelY = 0;
        CGFloat titleLabelH = imgViewH + imgViewY + margin;
        CGFloat titlelabelW = titleLabelH * 2;

        self.titleLabelFrame = CGRectMake(titleLabelX, titleLabelY, titlelabelW, titleLabelH);

        CGFloat valueLabelW = frame.size.width / 2;
        CGFloat valueLabelH = imgViewH / 2 + margin;
        CGFloat valueLabelX = frame.size.width - margin - valueLabelW;
        CGFloat valueLabelY = margin;
        self.valueLabelFrame = CGRectMake(valueLabelX, valueLabelY, valueLabelW, valueLabelH);

        CGFloat timeLabelX = valueLabelX;
        CGFloat timeLabelY = valueLabelY + valueLabelH;
        CGFloat timeLabelW = valueLabelW;
        CGFloat timeLabelH = imgViewH / 2;

        self.timeLabelFrame = CGRectMake(timeLabelX, timeLabelY, timeLabelW, timeLabelH);

        CGFloat topViewX = margin;
        CGFloat topViewY = imgViewY + imgViewH + margin;
        CGFloat topViewW = frame.size.width - margin * 2;
        CGFloat topViewH = 1;
        self.topLineFrame = CGRectMake(topViewX, topViewY, topViewW, topViewH);

        CGFloat bottomViewX = margin;
        CGFloat bottomViewY = frame.size.height * 4 / 5;
        CGFloat bottomViewW = topViewW;
        CGFloat bottomViewH = topViewH;
        self.bottomLineFrame = CGRectMake(bottomViewX, bottomViewY, bottomViewW, bottomViewH);

        CGFloat indicatorX = margin;
        CGFloat indicatorH = 30;
        CGFloat indicatorW = topViewW;
        CGFloat indicatorY = topViewY + topViewH + (bottomViewY - topViewY - indicatorH) / 2;
        self.indicatorFrame = CGRectMake(indicatorX, indicatorY, indicatorW, indicatorH);

        CGFloat scrollViewX = margin;
        CGFloat scrollViewY = topViewY + topViewH + 10;
        CGFloat scrollViewW = topViewW;
        CGFloat scrollViewH = frame.size.height - scrollViewY;
        self.scrollViewFrame = CGRectMake(scrollViewX, scrollViewY, scrollViewW, scrollViewH);

        CGFloat dataViewX = 0;
        CGFloat dataViewY = 0;
        CGFloat dataViewW = topViewW;
        CGFloat dataViewH = bottomViewY - scrollViewY - 10;
        self.dataViewFrame = CGRectMake(dataViewX, dataViewY, dataViewW, dataViewH);

        CGFloat scaleViewW = bottomViewW;
        CGFloat scaleViewH = frame.size.height - bottomViewY - bottomViewH;
        CGFloat scaleViewX = 0;
        CGFloat scaleViewY = scrollViewH - scaleViewH;
        self.scaleViewFrame = CGRectMake(scaleViewX, scaleViewY, scaleViewW, scaleViewH);

        CGFloat maxValueX = topViewX;
        CGFloat maxValueY = topViewY + topViewH;
        CGFloat maxValueW = frame.size.width / 7;
        CGFloat maxValueH = 10;
        self.maxValueFrame = CGRectMake(maxValueX, maxValueY, maxValueW, maxValueH);

        CGFloat minValueW = maxValueW;
        CGFloat minValueH = maxValueH;
        CGFloat minValueX = bottomViewX;
        CGFloat minValueY = bottomViewY - minValueH;
        self.minValueFrame = CGRectMake(minValueX, minValueY, minValueW, minValueH);
    }
    return self;
}

@end
