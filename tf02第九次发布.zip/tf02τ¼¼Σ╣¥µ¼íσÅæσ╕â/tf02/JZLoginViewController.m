//
//  JZLoginViewController.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZLoginViewController.h"
#import "JZLoginView.h"
#import "JZTabBarController.h"
#import "JZOperation.h"
#import "NSDate+local.h"
#import "JZFamilyInfo.h"

#import "JZGetCaptchaViewController.h"

#import "BPush.h"
#import "MZNavigationController.h"

@interface JZLoginViewController() <JZOperationDelegate>
{
    NSString *jzTel;
    NSString *jzMail;
    NSString *jzPwd;
    NSString *photo;
}

@property (nonatomic, strong) JZLoginView *loginView;

@property (nonatomic, strong) JZTabBarController *tabBarC;
@property (nonatomic, strong) JZGetCaptchaViewController *getCaptchaVC;
@property (nonatomic, strong) MZNavigationController *navi;
@property (nonatomic, strong) NSOperationQueue *queue;

@end

@implementation JZLoginViewController

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (JZLoginView *)loginView
{
    if (!_loginView) {
        _loginView = [[JZLoginView alloc] initWithFrame:self.view.bounds];
        [_loginView.loginBtn addTarget: self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
        [_loginView.forgetPasswordBtn addTarget:self action:@selector(forgetPassword) forControlEvents:UIControlEventTouchUpInside];
        if ([JZFamilyInfo valueByKey: kFamilyInfo]) {
            _loginView.userTF.text = [NSString valueByKey:kAcount];

            if ([[NSString valueByKey:kIsRemember] isEqualToString:@"YES"]) {
                _loginView.passwordTF.text = [NSString valueByKey:kPassword];
            } else {
                _loginView.passwordTF.text = @"";
            }

        }
        [_loginView.visitorsBtn addTarget:self action:@selector(visitorsAction:) forControlEvents:UIControlEventTouchUpInside];
        [_loginView.rememberPasswordView.btn addTarget:self action:@selector(rememberPassword:) forControlEvents:UIControlEventTouchUpInside];
        NSString *remember = [NSString valueByKey:kIsRemember];
        if ([remember isEqualToString:@"YES"]) {
            self.loginView.rememberPasswordView.imgView.image = [UIImage imageNamed:@"tick"];
        } else {
            self.loginView.rememberPasswordView.imgView.image = nil;
        }
    }
    return _loginView;
}

- (void)visitorsAction:(UIButton *)btn
{
    NSMutableDictionary *cityListParam = [NSMutableDictionary dictionary];
    cityListParam[@"key"] = JZMobAppKey;
    JZOperation *operation = [JZOperation operationWithURLString:cityListURL andParam:cityListParam getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = getCityOperation;
    JZFamilyInfo *familyInfo = [[JZFamilyInfo alloc] init];
    [familyInfo storeValueByKey:kFamilyInfo];
    [@"visitors" storeValueByKey:kVisitors];
}

- (JZTabBarController *)tabBarC
{
    if (!_tabBarC) {
        _tabBarC = [[JZTabBarController alloc] init];
        _tabBarC.navigationItem.title = @"首页";
    }
    return _tabBarC;
}

- (MZNavigationController *)navi
{
    if (!_navi) {
        _navi = [[MZNavigationController alloc] initWithRootViewController:self.tabBarC];
//        _navi.navigationBar.barStyle = UIBarStyleBlack;
//        _navi.navigationBar.barTintColor = barBackgroundColor;
//        _navi.navigationBar.tintColor = [UIColor whiteColor];
//        _navi.navigationBar.translucent = NO;
    }
    return _navi;
}

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *remember = [NSString valueByKey:kIsRemember];
    if (!remember) {
        remember = @"YES";
        [remember storeValueByKey:kIsRemember];
    }
    NSString *account = [NSString valueByKey:kAcount];
    if (!account) {
        account = @"";
        [account storeValueByKey:kAcount];
    }
    NSString *password = [NSString valueByKey:kPassword];
    if (!password) {
        password = @"";
        [password storeValueByKey:kPassword];
    }
    [self.view addSubview: self.loginView];

    if([[NSString valueByKey:kAutoLogin] isEqualToString:@"autologin"] && account.length == 11 && password.length) {
        [self login];
    }

}

- (void)login
{
    [@"users" storeValueByKey:kVisitors];
    if ([[NSString valueByKey:kIsRemember] isEqualToString:@"YES"]) {
        self.loginView.rememberPasswordView.imgView.image = [UIImage imageNamed:@"tick"];
        [self.loginView.userTF.text storeValueByKey:kAcount];
        [self.loginView.passwordTF.text storeValueByKey:kPassword];
    } else {
        self.loginView.rememberPasswordView.imgView.image = nil;
        [self.loginView.userTF.text storeValueByKey:kAcount];
        [@"" storeValueByKey:kPassword];
    }

    [self.loginView.userTF resignFirstResponder];
    [self.loginView.passwordTF resignFirstResponder];

    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    if([self.loginView.userTF.text rangeOfString:@"@"].location != NSNotFound)
    {
        param[@"mail"] = self.loginView.userTF.text;
        param[@"pwd"] = self.loginView.passwordTF.text;
        jzMail = self.loginView.userTF.text;
    } else {
        param[@"tel"] = self.loginView.userTF.text;
        param[@"pwd"] = self.loginView.passwordTF.text;
        jzTel = self.loginView.userTF.text;
    }
    jzPwd = self.loginView.passwordTF.text;

    [JZOperation cancelAFHTTPRequest];

    JZOperation *operation = [JZOperation operationWithURLString:usersLoginURL andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
    operation.name = loginOperation;
    self.loginView.promptLabel.jz_text = @"正在登陆中，请稍后...";
    self.loginView.promptLabel.isRemoved = NO;
    [self.view addSubview: self.loginView.promptLabel];

}

#pragma mark JZOperationDelegat Methods
- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    NSLog(@"%@", operation.name);
    if ([operation.name isEqualToString:bindChannelIdOperation]) {
        return;
    } else if ([operation.name isEqualToString:getCityOperation]) {
        [UIApplication sharedApplication].keyWindow.rootViewController = self.navi;

    } else if ([operation.name isEqualToString:loginOperation]) {
        NSString *code = [NSString stringWithFormat: @"%@", responseObject[@"code"]];
        NSString *info = [NSString stringWithFormat: @"%@", responseObject[@"info"]];
        if ([code intValue] == 0) {
            JZFamilyInfo *familyInfoInit = [JZFamilyInfo valueByKey:kFamilyInfo];

            
            JZFamilyInfo *familyInfo = [JZFamilyInfo familyInfoWithDictionary: responseObject[@"data"]];
            if (![familyInfoInit.account isEqualToString:familyInfo.account]) {
                
                JZPersonInfo *personInfo = [[JZPersonInfo alloc] init];
                personInfo.tag = 100;
                [personInfo storeValueByKey:kCurrentFamilyMemberInfo];
            }

            NSLog(@"family.pwd = %@", familyInfo.pwd);
            familyInfo.pwd = jzPwd;
            if (!familyInfo.photo) {
                familyInfo.photo = @"";
                
            } else {
                if ([familyInfo.photo isKindOfClass:[NSNull class]]) {
                    familyInfo.photo = @"";
                } else if ([familyInfo.photo isEqualToString:@"<null>"]) {
                    familyInfo.photo = @"";
                    
                }
            }
            
            NSLog(@"family.pwd = %@", familyInfo.pwd);
            NSLog(@"token = %@", [[JZFamilyInfo valueByKey:kFamilyInfo] token]);
            NSLog(@"family.photo = %@", familyInfo.photo);
            [familyInfo storeValueByKey:kFamilyInfo];

            [@"handlogin" storeValueByKey:kAutoLogin];

            [UIApplication sharedApplication].keyWindow.rootViewController = self.navi;
            
            NSLog(@"登录成功, token值已设置");
            // 绑定ChannelId
            [self bindChannelIdFor:familyInfo];
            
        } else {
            if (info) {
                self.loginView.promptLabel.jz_text = info;
                [self.view addSubview:self.loginView.promptLabel];
            } else {
                self.loginView.promptLabel.jz_text = @"未知错误";
                [self.view addSubview:self.loginView.promptLabel];
            }
            
            JZFamilyInfo *familyInfo = [[JZFamilyInfo alloc] init];
            familyInfo.tel = jzTel;
            familyInfo.mail = jzMail;
            familyInfo.pwd = jzPwd;
            familyInfo.photo = @"";
            [familyInfo storeValueByKey: kFamilyInfo];
            
        }

    } else if ([operation.name isEqualToString:forgetPwdOperation]) {
        _getCaptchaVC = [[JZGetCaptchaViewController alloc] init];
        [self presentViewController: _getCaptchaVC animated:YES completion:nil];
    }
}

// 绑定channelID
- (void)bindChannelIdFor:(JZFamilyInfo *)familyInfo
{
    // 获取channel_id
    NSString *myChannel_id = [BPush getChannelId];
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    [df setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
    NSString *dateString = [df stringFromDate:[NSDate date]];
    
    NSMutableDictionary *param = [NSMutableDictionary dictionary];
    param[@"channelId"] = myChannel_id;
    param[@"userId"] = familyInfo.tel;
    param[@"editTime"] = dateString;
    param[@"loginTime"] = dateString;
    
    JZOperation *operation = [JZOperation operationWithURLString:bindChannelId andParam:param getOrPost:JZ_POST];
    operation.delegate = self;
    operation.name = bindChannelIdOperation;
}

- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    NSLog(@"登录失败");
    if (error.code == -1009) {
        self.loginView.promptLabel.jz_text = @"网络有点卡...";
        [self.view addSubview: self.loginView.promptLabel];
        //    [UIApplication sharedApplication].keyWindow.rootViewController = self.navi;

        JZFamilyInfo *familyInfo = [[JZFamilyInfo alloc] init];
        familyInfo.tel = jzTel;
        familyInfo.mail = jzMail;
        familyInfo.pwd = jzPwd;
        familyInfo.photo = @"";
        [familyInfo storeValueByKey: kFamilyInfo];
    }

}

- (void)forgetPassword
{
    NSLog(@"forgetPassword");

    JZOperation *operation = [JZOperation operationWithURLString:weatherURL andParam:nil getOrPost:JZ_GET];
    operation.delegate = self;
    operation.name = forgetPwdOperation;

}

- (void)rememberPassword:(UIButton *)button
{
    NSString *remember = [NSString valueByKey:kIsRemember];
    if ([remember isEqualToString:@"YES"]) {
        [@"NO" storeValueByKey:kIsRemember];
        self.loginView.rememberPasswordView.imgView.image = nil;
    } else {
        [@"YES" storeValueByKey:kIsRemember];
        self.loginView.rememberPasswordView.imgView.image = [UIImage imageNamed:@"tick"];
    }

}





























@end
