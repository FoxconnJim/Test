//
//  JZSelectProvinceTableViewController.h
//  tf02
//
//  Created by Jim on 2016/11/28.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZSelectProvinceTableViewController : UITableViewController

@end
