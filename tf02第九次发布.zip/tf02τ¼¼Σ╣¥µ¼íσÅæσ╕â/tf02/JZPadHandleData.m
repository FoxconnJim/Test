//
//  JZPadHandleData.m
//  tf02
//
//  Created by F7686324 on 03/12/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZPadHandleData.h"

@interface JZPadHandleData()

@property (nonatomic, strong) NSMutableArray *xArray;
@property (nonatomic, strong) NSMutableArray *yArray;

@end

@implementation JZPadHandleData

- (NSMutableArray *)totalArray
{
    if (!_totalArray) {
        _totalArray = [NSMutableArray array];
    }
    return _totalArray;
}

- (NSMutableArray *)meatimeArray
{
    if (!_meatimeArray) {
        _meatimeArray = [NSMutableArray array];
    }
    return _meatimeArray;
}

- (NSMutableArray *)yArray
{
    if (!_yArray) {
        _yArray = [NSMutableArray array];
    }
    return _yArray;
}

- (NSMutableArray *)xArray
{
    if (!_xArray) {
        _xArray = [NSMutableArray array];
    }
    return _xArray;
}

- (instancetype)initWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString
{
    if (self = [super init]) {

        if ([timeLengthString isEqual:jzYear]) {
            value = 3600 * 24 * 365;
        }
        NSString *endTimeString = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd"];
        NSDate *date = [[dateFormatter dateFromString: endTimeString] localDate];
        NSInteger endValue = [date timeIntervalSince1970] + 24 * 60 * 60;
        startValue = endValue - value;

        [self.xArray removeAllObjects];
        [self.yArray removeAllObjects];
        [self.meatimeArray removeAllObjects];
        [self.totalArray removeAllObjects];

        if ([timeLengthString isEqualToString:jzYear]) {
            NSString *monthStr = [[[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject] componentsSeparatedByString:@"-"][1];
            dataArray = [dataArray sortByMonth];

            NSMutableArray *orderArray = [NSMutableArray array];

            for (int i = 0; i < dataArray.count; i++) {
                [orderArray addObject:dataArray[i]];
            }

            for (NSMutableArray *array in orderArray) {
                if (array.count) {
                    CGFloat dataValue = 0.f;
                    for (JZDataPoint *dataPoint in array) {
                        dataValue += [dataPoint.data floatValue];
                    }
                    [self.yArray addObject:[NSString stringWithFormat:@"%f", dataValue / array.count]];
                } else {
                    [self.yArray addObject:@"0"];
                }
            }

            [self.yArray removeObjectAtIndex:0];
            
            for (int i = 0; i < 12; i++) {
                CGFloat x = 1.f / 24.f + i * 1.f / 12.f;
                [self.xArray addObject:[NSString stringWithFormat:@"%f", x]];
            }

            // add
            NSString *yearStr = [[[[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject] componentsSeparatedByString:@"-"] firstObject];
            int yearInt = yearStr.intValue;
            int monthInt = monthStr.intValue;

            NSMutableArray *textArr = [NSMutableArray array];
            for (int i = 0; i < 12; i++) {
                if (monthInt > 0) {
                    [textArr addObject:[NSString stringWithFormat:@"%d/%d", yearInt, monthInt]];
                } else {
                    [textArr addObject:[NSString stringWithFormat:@"%d/%d", yearInt - 1, monthInt + 12]];
                }
                monthInt--;
            }
            self.meatimeArray = [textArr changeOrder];


        } else {
            CGFloat viewWidth = screenW - screenEdgeMargin * 2;
            CGFloat layerWidth = viewWidth - 10;
            CGFloat pointWidth = layerWidth / dataArray.count;
            CGFloat showLayerWidth = layerWidth - pointWidth;
            
            if (dataArray.count >= 2) {
                dataArray = [dataArray changeOrder];
                for (int i = 0; i < dataArray.count; i++) {
                    JZDataPoint *dataPoint = [dataArray objectAtIndex:i];
                    CGFloat x = pointWidth / 2 / layerWidth + showLayerWidth / layerWidth / (dataArray.count - 1) * i;
                    NSLog(@"x = %f", x);
                    [self.xArray addObject:[NSString stringWithFormat:@"%f", x]];
                    [self.yArray addObject:[NSString stringWithFormat:@"%@", dataPoint.data]];
                    [self.meatimeArray addObject:[self stringToFormatWithString:dataPoint.meatime]];
                }
            } else if (dataArray.count == 1) {
                JZDataPoint *dataPoint = [dataArray firstObject];
                [self.xArray addObject:@"0.5"];
                [self.yArray addObject:dataPoint.data];
                [self.meatimeArray addObject:[self stringToFormatWithString:dataPoint.meatime]];
            }
        }
        
        if (self.xArray.count == self.yArray.count) {
            for (int i = 0; i < self.xArray.count; i++) {
                NSString *xStr = self.xArray[i];
                NSString *yStr = self.yArray[i];
                JZPoint *point = [JZPoint pointWithX:xStr.floatValue y:yStr.floatValue];
                [self.totalArray addObject:point];
            }
        } else {
            NSLog(@"横纵坐标数不等");
        }
    }
    return self;
}

- (nonnull NSString *)stringToFormatWithString:(NSString *)string
{
    if (string) {
        NSArray *Arr = [string componentsSeparatedByString:@" "];
        NSArray *arr = [Arr.firstObject componentsSeparatedByString:@"-"];
        NSInteger monthInt = [[arr objectAtIndex:1] integerValue];
        NSInteger dayInt = [[arr objectAtIndex:2] integerValue];
        NSString *monthStr = [NSString stringWithFormat:@"%ld", (long)monthInt];
        NSString *dayStr = [NSString stringWithFormat:@"%ld", (long)dayInt];
        NSString *meatimeStr = [NSString stringWithFormat:@"%@/%@", monthStr, dayStr];
        return meatimeStr;

    } else {
        return @"";
    }

}

+ (instancetype)dataWithArray:(NSMutableArray *)dataArray timeLengthString:(NSString *)timeLengthString
{
    return [[self alloc] initWithArray:dataArray timeLengthString:timeLengthString];
}

@end
