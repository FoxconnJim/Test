//
//  JZzixunwenzhangViewController.h
//  tf02
//
//  Created by AN PEN on 8/8/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZzixunwenzhangViewController : UIViewController

@property (nonatomic, copy) NSString *urlString;

@end
