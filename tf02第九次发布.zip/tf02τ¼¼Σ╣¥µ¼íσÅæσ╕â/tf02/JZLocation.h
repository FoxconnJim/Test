//
//  JZLocation.h
//  tf02
//
//  Created by Jim on 16/3/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>
#import <CoreLocation/CLLocationManagerDelegate.h>
#import <UIKit/UIKit.h>
@protocol JZLocationDelegate <NSObject>

@optional
- (void)locationInfoWithProvince: (NSString *)province city:(NSString *)city;

- (void)locationFailWithMessage: (NSString *)failMessage;

- (void)locationOff;

- (void)locationUnvaliable;

@end


@interface JZLocation : CLLocation <CLLocationManagerDelegate>

@property (nonatomic, copy) NSString *cityName;
@property (nonatomic, copy) NSString *provinceName;
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) NSOperationQueue *queue;
@property (nonatomic, weak) id <JZLocationDelegate> delegate;

- (void)getLocation;

@end
