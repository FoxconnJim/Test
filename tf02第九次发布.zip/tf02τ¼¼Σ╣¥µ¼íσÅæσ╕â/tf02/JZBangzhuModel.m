//
//  JZBangzhuModel.m
//  tf02
//
//  Created by F7686324 on 11/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZBangzhuModel.h"

@implementation JZBangzhuModel

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.helpTitle = [NSString stringWithFormat:@"%@", dict[@"helpTitle"]];
        self.helpContent = [NSString stringWithFormat:@"%@", dict[@"helpContent"]];
    }
    return self;
}

+ (instancetype)bangzhuModelWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
