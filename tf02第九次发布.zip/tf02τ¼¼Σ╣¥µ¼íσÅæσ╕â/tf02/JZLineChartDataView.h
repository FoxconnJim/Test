//
//  JZLineChartDataView.h
//  tf02
//
//  Created by F7686324 on 10/13/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"
#import "JZLineChartDataLayer.h"

@interface JZLineChartDataView : UIView

@property (nonatomic, strong) NSArray *bigDataArray;
@property (nonatomic, strong) NSArray *colorArray;
@property (nonatomic, strong) NSMutableArray *bigPointArray;
@property (nonatomic, strong) JZLineChartDataLayer *dataLayer1;
@property (nonatomic, strong) JZLineChartDataLayer *dataLayer2;
@property (nonatomic, strong) NSMutableArray *maxArray;
@property (nonatomic, strong) NSMutableArray *minArray;
@property (nonatomic, assign, readonly) CGFloat minValue;
@property (nonatomic, assign, readonly) CGFloat maxValue;

@property (nonatomic, assign) CGFloat jzScale;

- (void)jzSetNeedsDisplay;

@end
