//
//  JZStoreValue.h
//  tf02
//
//  Created by Jim on 16/8/22.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZStoreValue : NSObject

+ (JZStoreValue *)shareInstance;
- (void)storeValue: (id)value withKey: (NSString *)key;
- (id)valueWithKey: (NSString *)key;

@end