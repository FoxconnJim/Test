//
//  JZIndicatorView.h
//  tf02
//
//  Created by F7686324 on 02/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utility.h"

@interface JZIndicatorView : UIView
{
    CGFloat radius;
    CGFloat lineWidth;
}
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *pointArray;
@property (nonatomic, strong) NSMutableArray *pointFrameArray;

@end
