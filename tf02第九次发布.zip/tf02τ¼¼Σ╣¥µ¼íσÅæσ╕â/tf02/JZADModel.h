//
//  JZADModel.h
//  tf02
//
//  Created by F7686324 on 9/24/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JZADModel : NSObject

@property (nonatomic, copy) NSString *newsFront;
@property (nonatomic, copy) NSString *netUrl;

- (instancetype)initWithDict: (NSDictionary *)dict;
+ (instancetype)ADModelWithDict: (NSDictionary *)dict;

@end
