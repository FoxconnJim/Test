//
//  JZjinrituijianViewController.h
//  tf02
//
//  Created by F7686324 on 8/31/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZHotNews.h"

@interface JZjinrituijianViewController : UIViewController

@property (nonatomic, strong) JZHotNews *hotNews;

@end
