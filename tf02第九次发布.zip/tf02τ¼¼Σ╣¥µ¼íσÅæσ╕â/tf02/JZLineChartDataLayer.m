//
//  JZLineChartDataLayer.m
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZLineChartDataLayer.h"
#import "Utility.h"
#import "NSString+Date.h"
#import "JZPoint.h"
#import <UIKit/UIKit.h>

@interface JZLineChartDataLayer ()
{
    CGFloat animationTime;
    CGFloat lblWidth;
    CGFloat radius;
}

@end

@implementation JZLineChartDataLayer


- (void)setJzLayerScale:(CGFloat)jzLayerScale
{
    _jzLayerScale = jzLayerScale;

}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        self.jzLayerScale = 1.f;
        animationTime = 0.3f;
        radius = 1.5f;
        self.lineWidth = 1.5f;
        self.lineCap = kCALineCapRound;
        self.lineJoin = kCALineJoinRound;
        [self setFillColor:[UIColor clearColor].CGColor];
        [self setStrokeColor:[UIColor whiteColor].CGColor];
        self.frame = frame;
    }
    return self;
}

- (void)setPointArray:(NSMutableArray *)pointArray
{
    _pointArray = pointArray;

    if (pointArray.count) {
        CGFloat jzY = radius + self.lineWidth;
        CGFloat jzHeight = self.frame.size.height - radius * 2 - self.lineWidth;

        JZPoint *point0 = pointArray[0];
        
        CGMutablePathRef dataPath = CGPathCreateMutable();
        CGPathMoveToPoint(dataPath, NULL, self.frame.size.width * point0.x * self.jzLayerScale, jzY + jzHeight * point0.y);
        CGPathAddArc(dataPath,
                     NULL,
                     self.frame.size.width * point0.x * self.jzLayerScale,
                     jzY + jzHeight * point0.y,
                     radius,
                     0,
                     kDegreeToRadians(360),
                     0);
        CGPathMoveToPoint(dataPath, NULL, self.frame.size.width * point0.x * self.jzLayerScale, jzY + jzHeight * point0.y);
        if (pointArray.count > 1) {
            CGFloat pointWidth = self.frame.size.width * self.jzLayerScale / pointArray.count;

            for (int i = 1; i < pointArray.count; i++) {
                JZPoint *beginPoint = pointArray[i - 1];
                JZPoint *endPoint = pointArray[i];
                CGFloat beginX = self.frame.size.width * beginPoint.x * self.jzLayerScale;
                CGFloat beginY = jzY + jzHeight * beginPoint.y;
                CGFloat endX = self.frame.size.width * endPoint.x * self.jzLayerScale;
                CGFloat endY = jzY + jzHeight * endPoint.y;
                CGPathAddCurveToPoint(dataPath, NULL, (beginX + endX) / 2, beginY, (beginX + endX) / 2, endY, endX, endY);

                if (pointWidth >= radius * 2) {
                    CGPathAddArc(dataPath,
                                 NULL,
                                 self.frame.size.width * endPoint.x * self.jzLayerScale,
                                 jzY + jzHeight * endPoint.y,
                                 radius,
                                 0,
                                 kDegreeToRadians(360),
                                 0);
                }

                CGPathMoveToPoint(dataPath, NULL, self.frame.size.width * endPoint.x * self.jzLayerScale, jzY + jzHeight * endPoint.y);
            }
            
        }
        
        self.path = dataPath;
        CGPathRelease(dataPath);
    }
 

}

@end
