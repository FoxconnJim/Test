//
//  iRonIconCell.m
//  tf02
//
//  Created by IDSBG-00 on 2016/9/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "iRonIconCell.h"
#import "Utility.h"

@implementation iRonIconCell

//- (void)awakeFromNib {
//    // Initialization code
//}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    //这里cell的行高设置了110
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.layer.borderWidth = 1;
        self.layer.borderColor = appBackgroundColor.CGColor;
        self.backgroundColor = [UIColor clearColor];
        
        self.iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width / 2 - 35, 10, 70, 70)];
        self.iconImageView.layer.cornerRadius = 35;
        self.iconImageView.layer.masksToBounds = YES;
        [self addSubview:_iconImageView];
        
        self.familyNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 90, [UIScreen mainScreen].bounds.size.width - 40, 20)];
        self.familyNameLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_familyNameLabel];
    }
    return self;
}


@end
