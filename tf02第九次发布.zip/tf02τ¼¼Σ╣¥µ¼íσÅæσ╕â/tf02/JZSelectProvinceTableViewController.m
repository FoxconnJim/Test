//
//  JZSelectProvinceTableViewController.m
//  tf02
//
//  Created by Jim on 2016/11/28.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZSelectProvinceTableViewController.h"
#import "Utility.h"
#import "JZSelectCityTableViewController.h"
#import "JZSelectLocalCityView.h"
#import "JZProvinceModel.h"
#import "NSString+JZChineseToPinyin.h"

@interface JZSelectProvinceTableViewController ()

@property (nonatomic, strong) NSMutableArray *provinceArray;
@property (nonatomic, strong) NSMutableArray *indexArray;
@property (nonatomic, strong) NSMutableDictionary *dataDictionary;
@property (nonatomic, strong) JZSelectLocalCityView *selectLocalCityView;
@property (nonatomic, strong) JZSelectCityTableViewController *selectCityTBVC;

@end

@implementation JZSelectProvinceTableViewController

- (NSMutableArray *)provinceArray
{
    if (!_provinceArray) {
        _provinceArray = [NSMutableArray array];
    }
    return _provinceArray;
}

- (NSMutableArray *)indexArray
{
    if (!_indexArray) {
        _indexArray = [NSMutableArray array];
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            [_indexArray addObject:[NSString stringWithFormat:@"%c", ch]];
        }
    }
    return _indexArray;
}

- (NSMutableDictionary *)dataDictionary
{
    if (!_dataDictionary) {
        _dataDictionary = [NSMutableDictionary dictionary];
    }
    return _dataDictionary;
}

- (JZSelectLocalCityView *)selectLocalCityView
{
    if (!_selectLocalCityView) {
        _selectLocalCityView = [[JZSelectLocalCityView alloc] initWithFrame:CGRectMake(0, 0, screenW, 44)];
        [_selectLocalCityView.btn addTarget:self action:@selector(clickLocalCity:) forControlEvents:UIControlEventTouchUpInside];

    }
    return _selectLocalCityView;
}

//- (void)viewDidLayoutSubviews
//{
//    [super viewDidLayoutSubviews];
//    //设置导航字体颜色、字体、背景色
//    for (UIView* subview in [self.tableView subviews])
//    {
//        if ([subview isKindOfClass:NSClassFromString(@"UITableViewIndex")])
//        {
//            if([subview respondsToSelector:@selector(setIndexColor:)])
//            {
//                [subview performSelector:@selector(setIndexColor:) withObject:[UIColor redColor]];
//            }
//            if([subview respondsToSelector:@selector(setFont:)])
//            {
//                [subview performSelector:@selector(setFont:) withObject:[UIFont systemFontOfSize:30]];
//            }
//            if([subview respondsToSelector:@selector(setBackgroundColor:)])
//            {
//                [subview performSelector:@selector(setBackgroundColor:) withObject:[UIColor redColor]];
//            }
//        }
//    }
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选择省份";
    self.tableView.tableHeaderView = self.selectLocalCityView;

    NSMutableDictionary *localAddressDict = [NSMutableDictionary valueByKey:kLocalAddressDict];
    if (!localAddressDict) {
        localAddressDict[@"key"] = JZMobAppKey;
        localAddressDict[@"city"] = @"深圳";
        localAddressDict[@"province"] = @"广东";
        [localAddressDict storeValueByKey:kLocalAddressDict];
    }
    NSString *province = localAddressDict[@"province"];
    NSString *city = localAddressDict[@"city"];
    if (province.length && city.length) {
        NSString *localCityName = [NSString stringWithFormat:@"%@省 %@市", localAddressDict[@"province"], localAddressDict[@"city"]];
        self.selectLocalCityView.localCityName = localCityName;
    } else {
        self.selectLocalCityView.localCityName = @"获取不到您的城市(ಥ_ಥ)";
        self.selectLocalCityView.lbl.textColor = [UIColor grayColor];
        self.selectLocalCityView.detailLabel.text = @"";
    }
    NSMutableDictionary *cityListDict = [NSMutableDictionary valueByKey:kCityListDict];
    if ([cityListDict isKindOfClass:[NSDictionary class]]) {
        [self updateCityListWithDict:cityListDict];

    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateLocalCity:) name:updateLocalCityNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateCityList:) name:updateCityListNotification object:nil];
}

- (void)clickLocalCity:(UIButton *)btn
{
    [[NSNotificationCenter defaultCenter] postNotificationName:selectLocalCityNotification object:nil];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)updateLocalCity:(NSNotification *)note
{
    NSDictionary *localAddressDict = note.userInfo;
    
    NSString *province = localAddressDict[@"province"];
    NSString *city = localAddressDict[@"city"];
    if (province.length && city.length) {
        NSString *localCityName = [NSString stringWithFormat:@"%@省 %@市", localAddressDict[@"province"], localAddressDict[@"city"]];
        self.selectLocalCityView.localCityName = localCityName;
        [self.selectLocalCityView.btn addTarget:self action:@selector(clickLocalCity:) forControlEvents:UIControlEventTouchUpInside];
    } else {
        self.selectLocalCityView.localCityName = @"未能获取城市信息(ಥ_ಥ)";
        self.selectLocalCityView.lbl.textColor = [UIColor grayColor];
        self.selectLocalCityView.detailLabel.text = @"";
    }

}

- (void)updateCityList:(NSNotification *)note
{
    NSDictionary *cityListDict = note.userInfo;
    [self updateCityListWithDict:cityListDict];
}

- (void)updateCityListWithDict:(NSDictionary *)dict
{
    NSString *msg = dict[@"msg"];
    
    if ([msg isEqualToString:@"success"]) {
        NSArray *result = dict[@"result"];
        if ([result isKindOfClass:[NSArray class]]) {
            [self.provinceArray removeAllObjects];
            for (NSDictionary *provinceDict in result) {
                JZProvinceModel *provinceModel = [JZProvinceModel provinceModelWithDict:provinceDict];
                [self.provinceArray addObject:provinceModel];
            }
            NSMutableArray *indexArr = [NSMutableArray array];
            for (char ch = 'A'; ch <= 'Z'; ch++) {
                [indexArr addObject:[NSString stringWithFormat:@"%c", ch]];
            }
            
            NSMutableDictionary *dataDict = [NSMutableDictionary dictionary];
            for (NSString *charStr in indexArr) {
                NSMutableArray *array = [NSMutableArray array];
                [dataDict setObject:array forKey:charStr];
            }
            
            for (JZProvinceModel *model in self.provinceArray) {
                NSString *firstLetter = [[[model.province chineseToPinyin] substringToIndex:1] uppercaseString];
                NSMutableArray *array = dataDict[firstLetter];
                [array addObject:model];
            }
            
            self.dataDictionary = [dataDict mutableCopy];
            [dataDict enumerateKeysAndObjectsUsingBlock:^(id key,id obj, BOOL *stop) {
                obj = [[obj sortedArrayUsingComparator:^NSComparisonResult(JZProvinceModel *obj1, JZProvinceModel *obj2)
                        {
                            NSComparisonResult result = [[[obj1.province chineseToPinyin] lowercaseString] compare:[[obj2.province chineseToPinyin] lowercaseString]];
                            return result == NSOrderedDescending;// 升序
                        }]mutableCopy];
                [self.dataDictionary setObject:obj forKey:key];
            }];
            
            for (int i = 0; i < indexArr.count; i++) {
                NSString *charStr = indexArr[i];
                NSMutableArray *array = self.dataDictionary[charStr];
                NSLog(@"charStr = %@", charStr);
                if (!array.count) {
                    [self.indexArray removeObject:charStr];
                    [self.dataDictionary removeObjectForKey:charStr];
                }
            }
            [self.tableView reloadData];
        }
    }
}

#pragma mark UITableViewDelegate && UITableViewDataSource methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *key = self.indexArray[section];
    NSMutableArray *array = self.dataDictionary[key];
    return array.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.indexArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellid = @"ProvinceCellID";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];
    }
    
    NSString *key = self.indexArray[indexPath.section];
    NSMutableArray *array = self.dataDictionary[key];
    JZProvinceModel *model = array[indexPath.row];
    cell.textLabel.text = model.province;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *key = self.indexArray[indexPath.section];
    NSMutableArray *array = self.dataDictionary[key];
    JZProvinceModel *model = array[indexPath.row];
    NSLog(@"name = %@", model.province);
    _selectCityTBVC = [[JZSelectCityTableViewController alloc] init];
    _selectCityTBVC.jzProvinceModel = model;
    NSMutableDictionary *selectedAddressDict = [NSMutableDictionary dictionary];
    selectedAddressDict[@"key"] = JZMobAppKey;
    selectedAddressDict[@"province"] = model.province;
    [selectedAddressDict storeValueByKey:kSelectedAddressDict];
    [self.navigationController pushViewController:_selectCityTBVC animated:YES];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return self.indexArray[section];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return self.indexArray;
}

@end
