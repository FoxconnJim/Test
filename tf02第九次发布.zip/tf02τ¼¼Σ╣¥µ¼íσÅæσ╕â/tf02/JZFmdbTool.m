//
//  JZFmdbTool.m
//  tf02
//
//  Created by F7686324 on 2017/1/6.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZFmdbTool.h"

#define JZSQLITE_NAME @"jz_datas.sqlite"

@implementation JZFmdbTool
static FMDatabase *_fmdb;

#pragma mark 创建
+ (void)initialize
{
    // 执行打开数据库和创建表的操作
    NSString *filePath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject] stringByAppendingPathComponent:JZSQLITE_NAME];

    _fmdb = [FMDatabase databaseWithPath:filePath];

    [_fmdb open];
    //必须先打开数据库才能创建表，否则提示数据库没有打开

    if([_fmdb executeUpdate:@"CREATE TABLE IF NOT EXISTS jz_bp(ID INTEGER PRIMARY KEY AUTOINCREMENT, cardID TEXT NULL, meatime TEXT NULL, data TEXT NULL, healthrecord TEXT NULL, physicalstate TEXT NULL, bpSp TEXT NULL, bpDp TEXT NULL, bpHr TEXT NULL);"]) {
        NSLog(@"创建血压表成功");
    } else {
        NSLog(@"创建血压表失败");
    }
    if ([_fmdb executeUpdate:@"CREATE TABLE IF NOT EXISTS jz_hr(ID INTEGER PRIMARY KEY AUTOINCREMENT, cardID TEXT NULL, meatime TEXT NULL, data TEXT NULL, healthrecord TEXT NULL, physicalstate TEXT NULL, eegdata TEXT NULL, numberturns TEXT NULL);"]) {
        NSLog(@"创建心率表成功");
    } else {
        NSLog(@"创建心率表成功");
    }
    if ([_fmdb executeUpdate:@"CREATE TABLE IF NOT EXISTS jz_bf(ID INTEGER PRIMARY KEY AUTOINCREMENT, cardID TEXT NULL, meatime TEXT NULL, data TEXT NULL, healthrecord TEXT NULL, physicalstate TEXT NULL);"]) {
        NSLog(@"创建心率表成功");

    } else {
        NSLog(@"创建心率表失败");

    }
    if ([_fmdb executeUpdate:@"CREATE TABLE IF NOT EXISTS jz_bo(ID INTEGER PRIMARY KEY AUTOINCREMENT, cardID TEXT NULL, meatime TEXT NULL, data TEXT NULL, healthrecord TEXT NULL, physicalstate TEXT NULL);"]) {
        NSLog(@"创建血氧表成功");

    } else {
        NSLog(@"创建血氧表失败");

    }
    if ([_fmdb executeUpdate:@"CREATE TABLE IF NOT EXISTS jz_bw(ID INTEGER PRIMARY KEY AUTOINCREMENT, cardID TEXT NULL, meatime TEXT NULL, data TEXT NULL, healthrecord TEXT NULL, physicalstate TEXT NULL);"]) {
        NSLog(@"创建体重表成功");

    } else {
        NSLog(@"创建体重表失败");

    }
    if ([_fmdb executeUpdate:@"CREATE TABLE IF NOT EXISTS jz_bs(ID INTEGER PRIMARY KEY AUTOINCREMENT, cardID TEXT NULL, meatime TEXT NULL, data TEXT NULL, healthrecord TEXT NULL, physicalstate TEXT NULL);"]) {
        NSLog(@"创建血糖表成功");

    } else {
        NSLog(@"创建血糖表失败");

    }

}

+ (void)beginTransaction
{
    [_fmdb beginTransaction];
}

+ (void)commit
{
    [_fmdb commit];
}

+ (void)rollBack
{
    [_fmdb rollback];
}

#pragma mark 增加
+ (BOOL)insertBloodPressureData:(JZBloodPressureData *)bloodPressureData cardID:(NSString *)cardID
{
    NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO jz_bp(cardID, meatime, data, healthrecord, physicalstate, bpSp, bpDp, bpHr) VALUES ('%@', '%@', '%@', '%@', '%@', '%@', '%@', '%@');", cardID, bloodPressureData.meatime, bloodPressureData.data, bloodPressureData.healthrecord, bloodPressureData.physicalstate, bloodPressureData.bpSp, bloodPressureData.bpDp, bloodPressureData.bpHr];
    return [_fmdb executeUpdate:insertSql];
}

+ (BOOL)insertHeartRateData:(JZHeartRateData *)heartRateData cardID:(NSString *)cardID
{
    NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO jz_hr(cardID, meatime, data, healthrecord, physicalstate, eegdata, numberturns) VALUES ('%@', '%@', '%@', '%@', '%@', '%@', '%@');", cardID, heartRateData.meatime, heartRateData.data, heartRateData.healthrecord, heartRateData.physicalstate, heartRateData.eegdata, heartRateData.numberturns];
    return [_fmdb executeUpdate:insertSql];
}

+ (BOOL)insertBodyFatData:(JZBodyFatData *)bodyFatData cardID:(NSString *)cardID
{
    NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO jz_bf(cardID, meatime, data, healthrecord, physicalstate) VALUES ('%@', '%@', '%@', '%@', '%@');", cardID, bodyFatData.meatime, bodyFatData.data, bodyFatData.healthrecord, bodyFatData.physicalstate];
    return [_fmdb executeUpdate:insertSql];
}

+ (BOOL)insertBloodOxygenData:(JZBloodOxygenData *)bloodOxygenData cardID:(NSString *)cardID
{
    NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO jz_bo(cardID, meatime, data, healthrecord, physicalstate) VALUES ('%@', '%@', '%@', '%@', '%@');", cardID, bloodOxygenData.meatime, bloodOxygenData.data, bloodOxygenData.healthrecord, bloodOxygenData.physicalstate];
    return [_fmdb executeUpdate:insertSql];
}

+ (BOOL)insertWeightData:(JZWeightData *)weightData cardID:(NSString *)cardID
{
    NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO jz_bw(cardID, meatime, data, healthrecord, physicalstate) VALUES ('%@', '%@', '%@', '%@', '%@');", cardID, weightData.meatime, weightData.data, weightData.healthrecord, weightData.physicalstate];
    return [_fmdb executeUpdate:insertSql];
}

+ (BOOL)insertBloodSugarData:(JZBloodSugarData *)bloodSugarData cardID:(NSString *)cardID
{
    NSString *insertSql = [NSString stringWithFormat:@"INSERT INTO jz_bs(cardID, meatime, data, healthrecord, physicalstate) VALUES ('%@', '%@', '%@', '%@', '%@');", cardID, bloodSugarData.meatime, bloodSugarData.data, bloodSugarData.healthrecord, bloodSugarData.physicalstate];
    return [_fmdb executeUpdate:insertSql];
}

#pragma mark 查询
+ (NSDateFormatter *)dateFormatter
{
    static NSDateFormatter *dateFormatter = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dateFormatter = [[NSDateFormatter alloc] init];
    });
    return dateFormatter;
}

+ (NSArray *)queryBloodPressureDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *querySql = [JZFmdbTool queryDataWithID:cardID timeType:timeType tableName:@"jz_bp"];

    NSMutableArray *arrM = [NSMutableArray array];
    FMResultSet *set = [_fmdb executeQuery:querySql];

    while ([set next]) {
        JZBloodPressureData *bloodPressureData = [[JZBloodPressureData alloc] init];

        bloodPressureData.ID = @"";
        bloodPressureData.meatime = [set stringForColumn:@"meatime"];
        bloodPressureData.data = [set stringForColumn:@"data"];
        bloodPressureData.healthrecord = [set stringForColumn:@"healthrecord"];
        bloodPressureData.physicalstate = [set stringForColumn:@"physicalstate"];
        bloodPressureData.bpSp = [set stringForColumn:@"bpSp"];
        bloodPressureData.bpHr = [set stringForColumn:@"bpHr"];
        bloodPressureData.bpDp = [set stringForColumn:@"bpDp"];

        [arrM addObject:bloodPressureData];
    }
    return arrM;
}

+ (NSArray *)queryHeartRateDataWithID:(NSString *)cardID timeType:(NSString *)timeType;
{
    NSString *querySql = [JZFmdbTool queryDataWithID:cardID timeType:timeType tableName:@"jz_hr"];

    NSMutableArray *arrM = [NSMutableArray array];
    FMResultSet *set = [_fmdb executeQuery:querySql];

    while ([set next]) {
        JZHeartRateData *heartRateData = [[JZHeartRateData alloc] init];

        heartRateData.ID = @"";
        heartRateData.meatime = [set stringForColumn:@"meatime"];
        heartRateData.data = [set stringForColumn:@"data"];
        heartRateData.healthrecord = [set stringForColumn:@"healthrecord"];
        heartRateData.physicalstate = [set stringForColumn:@"physicalstate"];
        heartRateData.eegdata = [set stringForColumn:@"eegdata"];
        heartRateData.numberturns = [set stringForColumn:@"numberturns"];


        [arrM addObject:heartRateData];
    }
    return arrM;
}

+ (NSArray *)queryBodyFatDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *querySql = [JZFmdbTool queryDataWithID:cardID timeType:timeType tableName:@"jz_bf"];

    NSMutableArray *arrM = [NSMutableArray array];
    FMResultSet *set = [_fmdb executeQuery:querySql];

    while ([set next]) {
        JZBodyFatData *bodyFatData = [[JZBodyFatData alloc] init];

        bodyFatData.ID = @"";
        bodyFatData.meatime = [set stringForColumn:@"meatime"];
        bodyFatData.data = [set stringForColumn:@"data"];
        bodyFatData.healthrecord = [set stringForColumn:@"healthrecord"];
        bodyFatData.physicalstate = [set stringForColumn:@"physicalstate"];


        [arrM addObject:bodyFatData];
    }
    return arrM;
}

+ (NSArray *)queryWeightDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *querySql = [JZFmdbTool queryDataWithID:cardID timeType:timeType tableName:@"jz_bw"];

    NSMutableArray *arrM = [NSMutableArray array];
    FMResultSet *set = [_fmdb executeQuery:querySql];

    while ([set next]) {
        JZWeightData *weightData = [[JZWeightData alloc] init];

        weightData.ID = @"";
        weightData.meatime = [set stringForColumn:@"meatime"];
        weightData.data = [set stringForColumn:@"data"];
        weightData.healthrecord = [set stringForColumn:@"healthrecord"];
        weightData.physicalstate = [set stringForColumn:@"physicalstate"];

        [arrM addObject:weightData];
    }
    return arrM;
}

+ (NSArray *)queryBloodOxygenDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *querySql = [JZFmdbTool queryDataWithID:cardID timeType:timeType tableName:@"jz_bo"];

    NSMutableArray *arrM = [NSMutableArray array];
    FMResultSet *set = [_fmdb executeQuery:querySql];

    while ([set next]) {
        JZBloodOxygenData *bloodOxygenData = [[JZBloodOxygenData alloc] init];

        bloodOxygenData.ID = @"";
        bloodOxygenData.meatime = [set stringForColumn:@"meatime"];
        bloodOxygenData.data = [set stringForColumn:@"data"];
        bloodOxygenData.healthrecord = [set stringForColumn:@"healthrecord"];
        bloodOxygenData.physicalstate = [set stringForColumn:@"physicalstate"];


        [arrM addObject:bloodOxygenData];
    }
    return arrM;
}

+ (NSArray *)queryBloodSugarDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *querySql = [JZFmdbTool queryDataWithID:cardID timeType:timeType tableName:@"jz_bs"];
    NSMutableArray *arrM = [NSMutableArray array];
    FMResultSet *set = [_fmdb executeQuery:querySql];

    while ([set next]) {
        JZBloodSugarData *bloodSugarData = [[JZBloodSugarData alloc] init];

        bloodSugarData.ID = @"";
        bloodSugarData.meatime = [set stringForColumn:@"meatime"];
        bloodSugarData.data = [set stringForColumn:@"data"];
        bloodSugarData.healthrecord = [set stringForColumn:@"healthrecord"];
        bloodSugarData.physicalstate = [set stringForColumn:@"physicalstate"];

        [arrM addObject:bloodSugarData];
    }
    return arrM;
}

+ (NSString *)queryDataWithID:(NSString *)cardID timeType:(NSString *)timeType tableName:(NSString *)tableName
{
    NSString *endTimeString = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
    [[JZFmdbTool dateFormatter] setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [[[JZFmdbTool dateFormatter] dateFromString: endTimeString] localDate];
    NSInteger endTimeInt = [date timeIntervalSince1970] + 24 * 60 * 60;
    NSInteger staTimeInt = 0;
    if ([timeType isEqualToString:jzDay]) {
        staTimeInt = endTimeInt - 24 * 60 * 60;
    } else if ([timeType isEqualToString:jzWeek]) {
        staTimeInt = endTimeInt - 24 * 60 * 60 * 7;
    } else if ([timeType isEqualToString:jzMonth]) {
        staTimeInt = endTimeInt - 24 * 60 * 60 * 30;
    } else if ([timeType isEqualToString:jzYear]) {
        staTimeInt = endTimeInt - 24 * 60 * 60 * 365;
    }

    NSString *endTime = [[NSDate dateWithTimeIntervalSince1970:endTimeInt] dateToString];
    NSString *staTime = [[NSDate dateWithTimeIntervalSince1970:staTimeInt] dateToString];
    NSLog(@"timeType = %@, staTime = %@, endTime = %@", timeType, staTime, endTime);

    NSString *querySql = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE cardID = '%@' AND meatime BETWEEN '%@' AND '%@' ORDER BY meatime DESC", tableName, cardID, staTime, endTime];
    return querySql;
}

#pragma mark 删除
+ (BOOL)deleteBloodPressureDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *deleteSql = [JZFmdbTool deleteDataWithID:cardID timeType:timeType tableName:@"jz_bp"];
    return [_fmdb executeUpdate:deleteSql];
}

+ (BOOL)deleteHeartRateDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *deleteSql = [JZFmdbTool deleteDataWithID:cardID timeType:timeType tableName:@"jz_hr"];

    return [_fmdb executeUpdate:deleteSql];
}

+ (BOOL)deleteBodyFatDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *deleteSql = [JZFmdbTool deleteDataWithID:cardID timeType:timeType tableName:@"jz_bf"];

    return [_fmdb executeUpdate:deleteSql];
}

+ (BOOL)deleteWeightDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *deleteSql = [JZFmdbTool deleteDataWithID:cardID timeType:timeType tableName:@"jz_bw"];

    return [_fmdb executeUpdate:deleteSql];
}

+ (BOOL)deleteBloodOxygenDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *deleteSql = [JZFmdbTool deleteDataWithID:cardID timeType:timeType tableName:@"jz_bo"];

    return [_fmdb executeUpdate:deleteSql];
}

+ (BOOL)deleteBloodSugarDataWithID:(NSString *)cardID timeType:(NSString *)timeType
{
    NSString *deleteSql = [JZFmdbTool deleteDataWithID:cardID timeType:timeType tableName:@"jz_bs"];

    return [_fmdb executeUpdate:deleteSql];
}

+ (NSString *)deleteDataWithID:(NSString *)cardID timeType:(NSString *)timeType tableName:(NSString *)tableName
{
    NSString *endTimeString = [[[[[NSDate date] localDate] dateToString] componentsSeparatedByString:@" "] firstObject];
    [[JZFmdbTool dateFormatter] setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [[[JZFmdbTool dateFormatter] dateFromString: endTimeString] localDate];
    NSInteger endTimeInt = [date timeIntervalSince1970] + 24 * 60 * 60;
    NSInteger staTimeInt = 0;
    if ([timeType isEqualToString:jzDay]) {
        staTimeInt = endTimeInt - 24 * 60 * 60;
    } else if ([timeType isEqualToString:jzWeek]) {
        staTimeInt = endTimeInt - 24 * 60 * 60 * 7;
    } else if ([timeType isEqualToString:jzMonth]) {
        staTimeInt = endTimeInt - 24 * 60 * 60 * 30;
    } else if ([timeType isEqualToString:jzYear]) {
        staTimeInt = endTimeInt - 24 * 60 * 60 * 365;
    }

    NSString *endTime = [[NSDate dateWithTimeIntervalSince1970:endTimeInt] dateToString];
    NSString *staTime = [[NSDate dateWithTimeIntervalSince1970:staTimeInt] dateToString];
    NSLog(@"timeType = %@, staTime = %@, endTime = %@", timeType, staTime, endTime);

    NSString *deleteSql = [NSString stringWithFormat:@"DELETE FROM %@ WHERE cardID = '%@' AND meatime BETWEEN '%@' AND '%@'", tableName, cardID, staTime, endTime];
    return deleteSql;
}

#pragma mark 修改
+ (BOOL)modifyData:(NSString *)modifySql
{
    if (modifySql == nil) {
        modifySql = @"UPDATE jz_models SET sumary = '暂无简介~' WHERE sumary = ''";
    }
    return [_fmdb executeUpdate:modifySql];
}

@end
