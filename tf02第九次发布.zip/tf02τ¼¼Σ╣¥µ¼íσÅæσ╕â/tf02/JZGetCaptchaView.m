//
//  JZGetCaptchaView.m
//  tf02
//
//  Created by F7686324 on 2016/12/16.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZGetCaptchaView.h"

@implementation JZGetCaptchaView

- (JZGetCaptchaFrame *)getCaptchaFrame
{
    if (!_getCaptchaFrame) {
        _getCaptchaFrame = [[JZGetCaptchaFrame alloc] init];
    }
    return _getCaptchaFrame;
}

- (UIImageView *)backgroundImageView
{
    if (!_backgroundImageView) {
        _backgroundImageView = [[UIImageView alloc] initWithFrame:self.bounds];
        _backgroundImageView.image = [UIImage imageNamed:@"loginBackgroundImage"];
    }
    return _backgroundImageView;
}

- (UILabel *)title
{
    if (!_title) {
        _title = [[UILabel alloc] initWithFrame: self.getCaptchaFrame.titleFrame];
        _title.textColor = [UIColor whiteColor];
        _title.font = [UIFont systemFontOfSize: 25];
    }
    return _title;
}

- (UILabel *)upLabel
{
    if (!_upLabel) {
        _upLabel = [[UILabel alloc] initWithFrame: self.getCaptchaFrame.upLabelFrame];
        _upLabel.textColor = [UIColor whiteColor];
        _upLabel.textAlignment = NSTextAlignmentRight;
    }
    return _upLabel;
}

- (JZCustomField *)upField
{
    if (!_upField) {
        _upField = [[JZCustomField alloc] initWithFrame: self.getCaptchaFrame.upFieldFrame];
        _upField.textColor = [UIColor whiteColor];
        _upField.clearButtonMode = UITextFieldViewModeWhileEditing;
        _upField.keyboardType = UIKeyboardTypePhonePad;
    }
    return _upField;
}

- (UILabel *)upSublabel
{
    if (!_upSublabel) {
        _upSublabel = [[UILabel alloc] initWithFrame: self.getCaptchaFrame.upSublabelFrame];
        _upSublabel.textColor = [UIColor whiteColor];
        _upSublabel.font = [UIFont systemFontOfSize: 15];
    }
    return _upSublabel;
}

- (UILabel *)downLabel
{
    if (!_downLabel) {
        _downLabel = [[UILabel alloc] initWithFrame: self.getCaptchaFrame.downLabelFrame];
        _downLabel.textColor = [UIColor whiteColor];
        _downLabel.textAlignment = NSTextAlignmentRight;
    }
    return _downLabel;
}

- (JZCustomField *)downField
{
    if (!_downField) {
        _downField = [[JZCustomField alloc] initWithFrame: self.getCaptchaFrame.downFieldFrame];
        _downField.textColor = [UIColor whiteColor];
        _downField.keyboardType = UIKeyboardTypePhonePad;
    }
    return _downField;
}

- (UILabel *)downSublabel
{
    if (!_downSublabel) {
        _downSublabel = [[UILabel alloc] initWithFrame: self.getCaptchaFrame.downSublabelFrame];
        _downSublabel.textColor = [UIColor whiteColor];
        _downSublabel.font = [UIFont systemFontOfSize: 15];
    }
    return _downSublabel;
}

- (UIButton *)captchaBtn
{
    if (!_captchaBtn) {
        _captchaBtn = [[UIButton alloc] initWithFrame:self.getCaptchaFrame.captchaFrame];
        [_captchaBtn setTitle:@"点击获取" forState:UIControlStateNormal];
        _captchaBtn.titleLabel.adjustsFontSizeToFitWidth = YES;
        _captchaBtn.enabled = NO;
        _captchaBtn.layer.cornerRadius = 5;
        _captchaBtn.layer.masksToBounds = YES;
        _captchaBtn.backgroundColor = [UIColor colorWithRed:0.94 green:0.94 blue:0.96 alpha:1.00];
        [_captchaBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    }
    return _captchaBtn;
}
- (UIButton *)foundBackBtn
{
    if (!_foundBackBtn) {
        _foundBackBtn = [[UIButton alloc] initWithFrame: self.getCaptchaFrame.foundBackBtnFrame];
        _foundBackBtn.layer.cornerRadius = self.getCaptchaFrame.foundBackBtnFrame.size.height / 2;
        _foundBackBtn.layer.masksToBounds = YES;
        _foundBackBtn.backgroundColor = [UIColor colorWithRed:0.00 green:0.57 blue:0.91 alpha:1.00];
    }
    return _foundBackBtn;
}

- (UIButton *)backBtn
{
    if (!_backBtn) {
        _backBtn = [[UIButton alloc] initWithFrame: self.getCaptchaFrame.backBtnFrame];
        [_backBtn setTitle:@"返回到上一级" forState:UIControlStateNormal];
        _backBtn.titleLabel.font = [UIFont systemFontOfSize: 15];
        [_backBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_backBtn setTitleColor:[UIColor colorWithWhite:0.8 alpha:1] forState:UIControlStateHighlighted];
    }
    return _backBtn;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.backgroundImageView];
        [self addSubview:self.title];
        [self addSubview:self.upLabel];
        [self addSubview:self.upField];
        [self addSubview:self.upSublabel];
        [self addSubview:self.downLabel];
        [self addSubview:self.downSublabel];
        [self addSubview:self.captchaBtn];
        [self addSubview:self.downField];
        [self addSubview:self.foundBackBtn];
        [self addSubview:self.backBtn];
    }
    return self;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.upField resignFirstResponder];
    [self.downField resignFirstResponder];
}


@end
