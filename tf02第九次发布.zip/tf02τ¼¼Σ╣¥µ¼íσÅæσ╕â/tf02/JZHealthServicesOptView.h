//
//  JZHealthServicesOptView.h
//  tf02
//
//  Created by F7686324 on 2016/12/29.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZHealthServicesOptView : UIView

@property (nonatomic, strong) UIImageView *imgView;
@property (nonatomic, strong) UILabel *lbl;

@end
