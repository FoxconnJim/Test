//
//  JZHPyijianfankuiViewController.m
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHPyijianfankuiViewController.h"
#import "Utility.h"
#import "JZOperation.h"

@interface JZHPyijianfankuiViewController () <UITextViewDelegate, JZOperationDelegate>

@property (nonatomic, strong) UITextView *tv;
@property (nonatomic, strong) NSOperationQueue *queue;

@end

@implementation JZHPyijianfankuiViewController

- (NSOperationQueue *)queue
{
    if (!_queue) {
        _queue = [[NSOperationQueue alloc] init];
        _queue.maxConcurrentOperationCount = 2;
    }
    return _queue;
}

- (UITextView *)tv
{
    if (!_tv) {
        _tv = [[UITextView alloc] initWithFrame: CGRectMake(screenEdgeMargin * 2, screenEdgeMargin * 2, screenW - screenEdgeMargin * 4, screenH / 3)];
        _tv.delegate = self;
        _tv.backgroundColor = [UIColor whiteColor];
        _tv.text = @"您的宝贵意见是我们前进的动力，说点什么吧";
        _tv.textColor = [UIColor colorWithWhite:0.7 alpha:1];
        _tv.font = [UIFont systemFontOfSize: 17];
        _tv.layer.cornerRadius = 10;
        _tv.layer.masksToBounds = YES;
    }
    return _tv;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"意见反馈";
    self.view.backgroundColor = appBackgroundColor;
    [self.view addSubview: self.tv];


    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(screenEdgeMargin * 2, screenEdgeMargin * 2 + screenH / 3, screenW - screenEdgeMargin * 2, 40)];
    lbl.font = [UIFont systemFontOfSize: 15];
    lbl.text = @"可输入200字";
    [self.view addSubview: lbl];

    UIButton *submitBtn = [[UIButton alloc] initWithFrame:CGRectMake(screenW / 8, screenEdgeMargin * 2 + screenH / 3 + 50, screenW * 3 / 4, 40)];
    submitBtn.layer.cornerRadius = 15;
    submitBtn.layer.masksToBounds = YES;
    submitBtn.backgroundColor = barBackgroundColor;
    [submitBtn setTitle:@"提交" forState:UIControlStateNormal];
    [submitBtn addTarget: self action:@selector(clickToSubmit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview: submitBtn];

}

- (void)clickToSubmit
{
    NSLog(@"clickToSubmit");

    if (self.tv.text.length < 10 || [self.tv.text isEqualToString:@"您的宝贵意见是我们前进的动力，说点什么吧"]) {
        NSString *message = @"至少输入十个字哦，亲~";
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *alertAction) {
            
        }];
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];

        [alertController addAction: okAction];
        [self presentViewController:alertController animated:YES completion:nil];
    } else {
        NSMutableDictionary *param = [NSMutableDictionary dictionary];
        param[@"febaUser"] = [[JZFamilyInfo valueByKey:kFamilyInfo] account];
        param[@"febaContent"] = self.tv.text;
        JZOperation *operation = [JZOperation operationWithURLString:submitFeedbackURL andParam:param getOrPost:JZ_POST];
        operation.delegate = self;
        operation.name = submitFeedbackOperation;

    }

}

#pragma mark UITextViewDelegate Methods
- (void)textViewDidBeginEditing:(UITextView *)textView {
    if ([textView.text isEqualToString:@"您的宝贵意见是我们前进的动力，说点什么吧"]) {
        textView.text = @"";
    }
    textView.textColor = [UIColor blackColor];
}

- (void)textViewDidEndEditing:(UITextView *)textView {

    if (textView.text.length < 1) {
        textView.text = @"您的宝贵意见是我们前进的动力，说点什么吧";
        textView.textColor = [UIColor colorWithWhite:0.7 alpha:1];
    }
    
}

- (void)textViewDidChange:(UITextView *)textView
{
    NSLog(@"字数: %ld", (long)textView.text.length);
    if (textView.text.length > 200) {
        textView.text = [textView.text substringToIndex:200];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.tv resignFirstResponder];
}

#pragma mark JZOperationDelegate Methods
- (void)didFailureWithOperation:(JZOperation *)operation error:(NSError *)error
{
    if (error.code == -1009) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"提交失败" preferredStyle:UIAlertControllerStyleAlert];

        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *alertAction) {
            self.tv.text = @"您的宝贵意见是我们前进的动力，说点什么吧";
            self.tv.textColor = [UIColor colorWithWhite:0.7 alpha:1];
            [self.tv resignFirstResponder];
        }];
        [alertController addAction:okAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }

}

- (void)didFinishDownLoadWithOperation:(JZOperation *)operation andResponseObject:(id)responseObject
{
    if (responseObject) {
        NSString *message = [NSString stringWithFormat:@"%@", responseObject[@"info"]];
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];

        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *alertAction) {
            self.tv.text = @"您的宝贵意见是我们前进的动力，说点什么吧";
            self.tv.textColor = [UIColor colorWithWhite:0.7 alpha:1];
            [self.tv resignFirstResponder];
            [self.navigationController popViewControllerAnimated:YES];
        }];
        [alertController addAction:okAction];
        [self presentViewController:alertController animated:YES completion:nil];

    }
}
@end
