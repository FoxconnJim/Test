//
//  NSArray+JZOrderByTime.m
//  tf02
//
//  Created by F7686324 on 2016/12/20.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "NSArray+JZOrderByTime.h"
#import "JZTodayRemindData.h"
#import "NSString+DateFormatter.h"
#import "NSString+Date.h"
@implementation NSArray (JZOrderByTime)

- (NSArray *)orderByTime
{
    NSMutableArray *array = [NSMutableArray array];
    for (JZTodayRemindData *data in self) {
        NSInteger time = [[data.createDate turnServiceToMyFormatter] stringToTimeInteval];
        NSNumber *number = [NSNumber numberWithInteger:time];
        [array addObject:number];
    }
    return 0;
}

@end
