//
//  JZbangzhuTableView.h
//  tf02
//
//  Created by AN PEN on 5/18/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZbangzhuTableView : UITableView <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray *rowArray;
@property (nonatomic, strong) NSMutableArray *sectionArray;

@end
