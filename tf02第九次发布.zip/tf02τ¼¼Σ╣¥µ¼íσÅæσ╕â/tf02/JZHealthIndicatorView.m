//
//  JZHealthIndicatorView.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZHealthIndicatorView.h"


@implementation JZHealthIndicatorView
- (JZHealthIndicatorFrame *)healthIndicatorFrame
{
    if (!_healthIndicatorFrame) {
        _healthIndicatorFrame = [[JZHealthIndicatorFrame alloc] init];
    }
    return _healthIndicatorFrame;
}

- (UISegmentedControl *)segmentControl
{
    if (!_segmentControl) {
        _segmentControl = [[UISegmentedControl alloc] initWithFrame: self.healthIndicatorFrame.segmentFrame];
        _segmentControl.tintColor = [UIColor colorWithRed:0.33 green:0.67 blue:0.93 alpha:1];
        _segmentControl.backgroundColor = [UIColor whiteColor];
        //设置分段卡的边框
        _segmentControl.layer.masksToBounds = YES;
        _segmentControl.layer.borderColor = [UIColor colorWithRed:0.33 green:0.67 blue:0.93 alpha:1].CGColor;
        _segmentControl.layer.borderWidth = 1;
        _segmentControl.layer.cornerRadius = 5;
    }
    return _segmentControl;
}

- (UILongPressGestureRecognizer *)longPressGesture
{
    if (!_longPressGesture) {
        _longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressGestureRecognized:)];
    }
    return _longPressGesture;
}

- (UITableView *)tbView
{
    if (!_tbView) {
        _tbView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH)];
        _tbView.dataSource = self;
        _tbView.delegate = self;
        _tbView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tbView.showsVerticalScrollIndicator = NO;
        _tbView.backgroundColor = appBackgroundColor;
        [_tbView addGestureRecognizer:self.longPressGesture];
    }
    return _tbView;
}

- (JZBloodPressureView *)bloodPressureView
{
    if (!_bloodPressureView) {
        _bloodPressureView = [[JZBloodPressureView alloc] initWithFrame:self.healthIndicatorFrame.cellFrame];
        [_bloodPressureView.singleTapGesture requireGestureRecognizerToFail:self.longPressGesture];
    }
    return _bloodPressureView;
}

- (JZHeartRateView *)heartRateView
{
    if (!_heartRateView) {
        _heartRateView = [[JZHeartRateView alloc] initWithFrame:self.healthIndicatorFrame.cellFrame];
        [_heartRateView.singleTapGesture requireGestureRecognizerToFail:self.longPressGesture];
    }
    return _heartRateView;
}

- (JZBloodSugarView *)bloodSugarView
{
    if (!_bloodSugarView) {
        _bloodSugarView = [[JZBloodSugarView alloc] initWithFrame:self.healthIndicatorFrame.cellFrame];
        [_bloodSugarView.singleTapGesture requireGestureRecognizerToFail:self.longPressGesture];
    }
    return _bloodSugarView;
}

- (JZBodyFatView *)bloodFatView
{
    if (!_bloodFatView) {
        _bloodFatView = [[JZBodyFatView alloc] initWithFrame: self.healthIndicatorFrame.cellFrame];
        [_bloodFatView.singleTapGesture requireGestureRecognizerToFail:self.longPressGesture];

    }
    return _bloodFatView;
}

- (JZWeightView *)weightView
{
    if (!_weightView) {
        _weightView = [[JZWeightView alloc] initWithFrame: self.healthIndicatorFrame.cellFrame];
        [_weightView.singleTapGesture requireGestureRecognizerToFail:self.longPressGesture];

    }
    return _weightView;
}

- (JZOxygenView *)oxygenView
{
    if (!_oxygenView) {
        _oxygenView = [[JZOxygenView alloc] initWithFrame: self.healthIndicatorFrame.cellFrame];
        [_oxygenView.singleTapGesture requireGestureRecognizerToFail:self.longPressGesture];

    }
    return _oxygenView;
}

- (NSMutableArray *)items
{
    if (!_items) {
        if ([NSMutableArray valueByKey: kItems]) {
            _items = [NSMutableArray valueByKey: kItems];
        } else {
            _items = [NSMutableArray arrayWithObjects:@"0", @"1", @"2", @"3", @"4", @"5", nil];
            [_items storeValueByKey: kItems];
        }
    }
    return _items;
}

- (NSMutableArray *)viewItems
{
    if (!_viewItems) {
        NSArray *array = [NSArray arrayWithObjects:self.bloodPressureView, self.heartRateView, self.bloodSugarView, self.bloodFatView, self.weightView, self.oxygenView, nil];
        _viewItems = [NSMutableArray array];

        for (int i = 0; i < array.count; i++) {
            JZLineChartView *lineChartView = array[[self.items[i] integerValue]];
            [_viewItems addObject: lineChartView];
        }
    }
    return _viewItems;
}

- (void)setTimeLengthString:(NSString *)timeLengthString
{
    [JZOperation cancelAFHTTPRequest];

    self.bloodPressureView.timeLengthString = timeLengthString;
    self.heartRateView.timeLengthString = timeLengthString;
    self.bloodSugarView.timeLengthString = timeLengthString;
    self.bloodFatView.timeLengthString = timeLengthString;
    self.oxygenView.timeLengthString = timeLengthString;
    self.weightView.timeLengthString = timeLengthString;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview: self.segmentControl];
        [self addSubview: self.tbView];

    }
    return self;
}


#pragma mark UITableViewDataSource Methods
- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.viewItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = appBackgroundColor;
    [cell addSubview: self.viewItems[indexPath.row]];
    
    return cell;
}

#pragma mark UITableViewDelegate Methods

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return self.healthIndicatorFrame.cellFrame.size.height + 12;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 50;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, 50)];
    bgView.backgroundColor = appBackgroundColor;
    [bgView addSubview: self.segmentControl];
    return bgView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return tabBarHeight + naviHeight + statusBarHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, screenW, tabBarHeight + naviHeight + statusBarHeight)];
    return view;
}

- (void)longPressGestureRecognized:(id)sender {
   
    UILongPressGestureRecognizer *longPress = (UILongPressGestureRecognizer *)sender;
    UIGestureRecognizerState state = longPress.state;
   
    CGPoint locationInTable = [longPress locationInView:self.tbView];
    CGPoint locationInSelf = [longPress locationInView:self];
    NSIndexPath *indexPath = [self.tbView indexPathForRowAtPoint:locationInTable];
    static UIView       *snapshot = nil;        ///< A snapshot of the row user is moving.
    static NSIndexPath  *sourceIndexPath = nil; ///< Initial index path, where gesture begins.
  
    switch (state) {
        case UIGestureRecognizerStateBegan: {
            if (indexPath) {
                sourceIndexPath = indexPath;
        
                UITableViewCell *cell = [self.tbView cellForRowAtIndexPath:indexPath];
                JZLineChartView *lineChartView = self.viewItems[indexPath.row];
// Take a snapshot of the selected row using helper method.
                snapshot = [self customSnapshoFromView:lineChartView];
                 
// Add the snapshot as subview, centered at cell's center..
                __block CGPoint center = cell.center;
                snapshot.center = center;
                snapshot.alpha = 0.0;
                [self.tbView addSubview:snapshot];
                [UIView animateWithDuration:0.25 animations:^{
                       
// Offset for gesture location.
                    center.y = locationInTable.y;
                    snapshot.center = center;
                    snapshot.transform = CGAffineTransformMakeScale(1.05, 1.05);
                    snapshot.alpha = 0.5;
                    
                    cell.alpha = 0.0f;
                } completion:^(BOOL finished) {
                    cell.hidden = YES;
                }];
            }
            break;
        }
         
        case UIGestureRecognizerStateChanged: {
            CGPoint center = snapshot.center;
            center.y = locationInTable.y;
            snapshot.center = center;

            NSLog(@"self.tbView.contentOffset = %@", NSStringFromCGPoint(self.tbView.contentOffset));
            if (locationInSelf.y < 50 && locationInTable.y > 50) {
                [self.tbView scrollRectToVisible:CGRectMake(0, self.tbView.contentOffset.y - 5, self.tbView.frame.size.width, self.tbView.frame.size.height) animated:NO];
            }
            
            if (locationInSelf.y > screenH - statusBarHeight - naviHeight - 50 && locationInTable.y < 50 + (self.healthIndicatorFrame.cellFrame.size.height + 12) * 6) {
                [self.tbView scrollRectToVisible:CGRectMake(0, self.tbView.contentOffset.y + 5, self.tbView.frame.size.width, self.tbView.frame.size.height) animated:NO];
            }

            NSLog(@"locationInTable = %f", locationInTable.y);
            NSLog(@"locationInSelf = %f", locationInSelf.y);
// Is destination valid and is it different from source?
            if (indexPath && ![indexPath isEqual:sourceIndexPath]) {
               
// ... update data source.
                [self.viewItems exchangeObjectAtIndex:indexPath.row withObjectAtIndex:sourceIndexPath.row];
                [self.items exchangeObjectAtIndex:indexPath.row withObjectAtIndex:sourceIndexPath.row];
                [self.items storeValueByKey:kItems];
// ... move the rows.
                [self.tbView moveRowAtIndexPath:sourceIndexPath toIndexPath:indexPath];

// ... and update source so it is in sync with UI changes.
                sourceIndexPath = indexPath;
            }
            UITableViewCell *cell = [self.tbView cellForRowAtIndexPath:indexPath];
            cell.hidden = YES;
            break;
        }
                        
        default: {
// Clean up.
            UITableViewCell *cell = [self.tbView cellForRowAtIndexPath:sourceIndexPath];
            [UIView animateWithDuration:0.25 animations:^{
                               
                snapshot.center = cell.center;
                snapshot.transform = CGAffineTransformIdentity;
                snapshot.alpha = 0.0;
            
                cell.alpha = 1.0f;
            } completion:^(BOOL finished) {
                cell.hidden = NO;
                [snapshot removeFromSuperview];
                snapshot = nil;
                     
            }];
            sourceIndexPath = nil;
            break;
        }
    }
}
#pragma mark - Helper methods

/** @brief Returns a customized snapshot of a given view. */
- (UIView *)customSnapshoFromView:(UIView *)inputView {
    UIView* snapshot = [inputView snapshotViewAfterScreenUpdates: YES];

    snapshot.layer.masksToBounds = NO;
    snapshot.layer.cornerRadius = 0.0;
    snapshot.layer.shadowOffset = CGSizeMake(-5.0, 0.0);
    snapshot.layer.shadowRadius = 5.0;
    snapshot.layer.shadowOpacity = 0.4;
    
    return snapshot;
}

@end

















