//
//  JZTipView.m
//  tf02
//
//  Created by F7686324 on 2017/1/14.
//  Copyright © 2017年 Jim. All rights reserved.
//

#import "JZTipView.h"
#import "Utility.h"

@implementation JZTipView

- (void)setOK:(BOOL)OK
{
    _OK = OK;
    [self setNeedsDisplay];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    CGContextRef context = UIGraphicsGetCurrentContext();
    if (_OK) {
        CGContextSetRGBFillColor(context, 0, 1, 0, 1);
        CGContextSetRGBStrokeColor(context,1, 1, 1, 1);
        CGContextSetLineCap(context, kCGLineCapRound);
        CGContextSetLineWidth(context, 2);

        CGContextAddArc(context, 15, 15, 15, 0, kDegreeToRadians(360), 0);
        CGContextDrawPath(context, kCGPathFill);

        CGPoint points[3];
        points[0] = CGPointMake(6, 15);
        points[1] = CGPointMake(13, 22);
        points[2] = CGPointMake(23, 8);
        CGContextAddLines(context, points, 3);
        CGContextDrawPath(context, kCGPathStroke);
    } else {
        CGContextSetRGBFillColor(context, 1, 0, 0, 1);
        CGContextSetRGBStrokeColor(context, 1, 1, 1, 1);
        CGContextSetLineCap(context, kCGLineCapRound);
        CGContextSetLineWidth(context, 2);

        CGContextAddArc(context, 15, 15, 15, 0, kDegreeToRadians(360), 0);
        CGContextDrawPath(context, kCGPathFill);

        CGPoint aPoints[2];//坐标点
        aPoints[0] = CGPointMake(8, 8);
        aPoints[1] = CGPointMake(22, 22);
        CGContextAddLines(context, aPoints, 2);

        CGPoint bPoints[2];
        bPoints[0] = CGPointMake(22, 8);
        bPoints[1] = CGPointMake(8, 22);
        CGContextAddLines(context, bPoints, 2);
        
        CGContextDrawPath(context, kCGPathStroke);
    }


}
@end
