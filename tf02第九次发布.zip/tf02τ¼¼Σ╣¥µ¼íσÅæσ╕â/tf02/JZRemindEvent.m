//
//  JZRemindEvent.m
//  tf02
//
//  Created by F7686324 on 12/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZRemindEvent.h"

@implementation JZRemindEvent

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.remindInfo = [NSString stringWithFormat:@"%@", dict[@"remindInfo"]];
        self.remindIdentifier = [NSString stringWithFormat:@"%@", dict[@"remindIdentifier"]];

        self.remindRepeatArray = (NSMutableArray *)dict[@"remindRepeat"];
        
        self.remindDate = (NSDate *)dict[@"remindTime"];
        self.remind = YES;
    }
    return self;
}

+ (instancetype)remindEventWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict:dict];
}

@end
