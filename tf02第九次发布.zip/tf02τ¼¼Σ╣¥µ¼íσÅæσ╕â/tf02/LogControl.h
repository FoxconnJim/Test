//
//  LogControl.h
//  tf02
//
//  Created by AN PEN on 7/26/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#ifndef LogControl_h
#define LogControl_h

//#pragma mark AppDelegate
//#define printShareToHealthLog YES
#define printShareToHealthLog NO

//#pragma mark JZLoginViewController
//#define printLoginRequestPragma YES
#define printLoginRequestPragma NO
//#define printLoginResponseObject YES
#define printLoginResponseObject NO
//
//#pragma mark JZHomePageViewController
//#define printAllFamilyMembers YES
#define printAllFamilyMembers NO


//#define printAllFamilyMembersCount YES
#define printAllFamilyMembersCount NO
//#define printSelectedFamilyMemberCard YES
#define printSelectedFamilyMemberCard NO
//#define printWeatherLog YES
#define printWeatherLog NO
//
//#pragma mark JZHealthECGViewController
//#define printECGLog YES
#define printECGLog NO
//
//#pragma mark JZBloodPressureView
//#define printBloodPressureData YES
#define printBloodPressureData NO
//
//#pragma mark JZBloodOxygenView
//#define printBloodOxygenData YES
#define printBloodOxygenData NO
//
//#pragma mark JZBloodSugarView
//#define printBloodSugarData YES
#define printBloodSugarData NO
//
//#pragma mark JZBodyFatView
//#define printBodyFatData YES
#define printBodyFatData NO
//
//#pragma mark JZHeartRateView
//#define printHeartRateData YES
#define printHeartRateData NO

#pragma mark JZhulizixunViewController
//#define printHotNews YES
#define printHotNews NO

#endif /* LogControl_h */
