//
//  JZECGCell.m
//  tf02
//
//  Created by F7686324 on 27/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZECGCell.h"

@implementation JZECGCell

- (UILabel *)lblTurns
{
    if (!_lblTurns) {
        _lblTurns = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 10, 10)];
        _lblTurns.font = [UIFont systemFontOfSize:10];
        _lblTurns.textAlignment = NSTextAlignmentCenter;
    }
    return _lblTurns;
}

- (UILabel *)lblUnit
{
    if (!_lblUnit) {
        _lblUnit = [[UILabel alloc] initWithFrame:CGRectMake(screenW / 2, 0, screenW / 2 - 10, 10)];
        _lblUnit.font = [UIFont systemFontOfSize:10];
        _lblUnit.text = @"5mm/mV,25mm/s";
        _lblUnit.textAlignment = NSTextAlignmentRight;
    }
    return _lblUnit;
}

- (JZECGScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [[JZECGScrollView alloc] initWithFrame:CGRectMake(0, 0, screenW, ratio * 3)];
    }
    return _scrollView;
}

- (JZECGDataView *)dataView
{
    if (!_dataView) {
        _dataView = [[JZECGDataView alloc] initWithFrame:CGRectZero];
    }
    return _dataView;
}

- (void)setDataArray:(NSMutableArray *)dataArray
{
    _dataArray = dataArray;
//    NSLog(@"ECGdataArray = %@", dataArray);
    if (dataArray.count) {
        [self.dataView removeFromSuperview];
        self.dataView.dataArray = dataArray;
        self.scrollView.contentSize = self.dataView.frame.size;
        [self.scrollView addSubview:self.dataView];
    }
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        ratio = 64;
        smallSpace = ratio / 10;
        bigSpace = ratio / 2;
        space = ratio / 60;
        [self addSubview:self.scrollView];
        [self addSubview:self.lblTurns];
        [self addSubview:self.lblUnit];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.separatorInset = UIEdgeInsetsZero;
    }
    return self;
}

+ (instancetype)ECGCellWithTableView:(UITableView *)tableView
{
    static NSString *cellid = @"ECGCellID";
    JZECGCell *cell = [tableView dequeueReusableCellWithIdentifier:cellid];
    if (!cell) {
        cell = [[JZECGCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellid];

    }
    return cell;
}


@end
