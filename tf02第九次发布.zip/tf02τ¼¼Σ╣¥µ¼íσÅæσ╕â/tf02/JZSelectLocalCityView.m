//
//  JZSelectLocalCityView.m
//  tf02
//
//  Created by F7686324 on 18/11/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZSelectLocalCityView.h"
#import "Utility.h"
@implementation JZSelectLocalCityView

- (UILabel *)lbl
{
    if (!_lbl) {
        _lbl = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, screenW - 15, 44)];
        _lbl.font = [UIFont systemFontOfSize:17];

    }
    return _lbl;
}

- (UIButton *)btn
{
    if (!_btn) {
        _btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, screenW, 44)];
    }
    return _btn;
}

- (UILabel *)detailLabel
{
    if (!_detailLabel) {
        _detailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _detailLabel.text = @"(定位城市)";
        _detailLabel.font = [UIFont systemFontOfSize:17];
        _detailLabel.textColor = [UIColor grayColor];
    }
    return _detailLabel;
}

- (void)setLocalCityName:(NSString *)localCityName
{
    _localCityName = localCityName;
    self.lbl.text = localCityName;
    CGSize size = [localCityName sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17]}];
    self.detailLabel.frame = CGRectMake(size.width + 15, 0, screenW - size.width - 30, 44);
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.lbl];
        [self.lbl addSubview: self.detailLabel];
        [self addSubview:self.btn];

    }
    return self;
}

@end
