//
//  NSDate+JZString.h
//  tf02
//
//  Created by Jim on 16/10/6.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (JZString)

- (NSString *)dateToString;

@end
