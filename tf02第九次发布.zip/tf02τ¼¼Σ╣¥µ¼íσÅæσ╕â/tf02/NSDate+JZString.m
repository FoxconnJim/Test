//
//  NSDate+JZString.m
//  tf02
//
//  Created by Jim on 16/10/6.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "NSDate+JZString.h"

@implementation NSDate (JZString)

- (NSString *)dateToString
{
    NSString *str = [NSString stringWithFormat: @"%@", self];
    NSArray *array = [str componentsSeparatedByString:@" "];
    NSString *jzString = [NSString stringWithFormat:@"%@ %@", array[0], array[1]];
    return jzString;
}

@end
