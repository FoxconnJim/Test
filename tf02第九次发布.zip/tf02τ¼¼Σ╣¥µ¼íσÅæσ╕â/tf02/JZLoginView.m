//
//  JZLoginView.m
//  tf02
//
//  Created by Jim on 16/3/9.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZLoginView.h"

@implementation JZLoginView

- (JZLoginFrame *)loginFrame
{
    if (!_loginFrame) {
        _loginFrame = [[JZLoginFrame alloc] init];
    }
    return _loginFrame;
}

- (UIImageView *)backgroundImageView
{
    if (!_backgroundImageView) {
        UIImage *backgroundImage = [UIImage imageNamed: @"loginBackgroundImage"];
        _backgroundImageView = [[UIImageView alloc] initWithFrame: self.bounds];
        _backgroundImageView.image = backgroundImage;
    }
    return _backgroundImageView;
}

- (UIImageView *)logoImageView
{
    if (!_logoImageView) {
        
        UIImage *image = [UIImage imageNamed:@"loginImage"];
        _logoImageView = [[UIImageView alloc] initWithFrame: self.loginFrame.imageViewFrame];
        _logoImageView.image = image;
    }
    return _logoImageView;
}

- (UILabel *)userLabel
{
    if (!_userLabel) {
        _userLabel = [[UILabel alloc] initWithFrame: self.loginFrame.userLabelFrame];
        _userLabel.text = @"账号:";
        _userLabel.textColor = [UIColor whiteColor];
        _userLabel.adjustsFontSizeToFitWidth = YES;
    }
    return _userLabel;
}

- (JZCustomField *)userTF
{
    if (!_userTF) {
        _userTF = [[JZCustomField alloc] initWithFrame: self.loginFrame.userTFFrame];
        _userTF.clearButtonMode = UITextFieldViewModeWhileEditing;
        _userTF.placeholder = @"手机号码／邮箱";
        [_userTF setValue:[UIColor colorWithWhite:1 alpha:0.5] forKeyPath:@"_placeholderLabel.textColor"];
        _userTF.leftView = [[UIView alloc] initWithFrame: self.loginFrame.marginFrame];
        _userTF.textColor = [UIColor whiteColor];
    }
    return _userTF;
}

- (UILabel *)passwordLabel
{
    if (!_passwordLabel) {
        _passwordLabel = [[UILabel alloc] initWithFrame: self.loginFrame.passwordLabelFrame];
        _passwordLabel.text = @"密码:";
        _passwordLabel.textColor = [UIColor whiteColor];
        _passwordLabel.adjustsFontSizeToFitWidth = YES;
    }
    return _passwordLabel;
}

- (JZCustomField *)passwordTF
{
    if (!_passwordTF) {
        _passwordTF = [[JZCustomField alloc] initWithFrame: self.loginFrame.passwordTFFrame];
        _passwordTF.leftView = [[UIView alloc] initWithFrame: self.loginFrame.marginFrame];
        _passwordTF.clearButtonMode = UITextFieldViewModeWhileEditing;
        _passwordTF.secureTextEntry = YES;
        _passwordTF.textColor = [UIColor whiteColor];
    }
    return _passwordTF;
}

- (UIButton *)loginBtn
{
    if (!_loginBtn) {
        _loginBtn = [[UIButton alloc] initWithFrame: self.loginFrame.loginBtnFrame];
        _loginBtn.layer.cornerRadius = 5;
        [_loginBtn setTitle:@"登录" forState:UIControlStateNormal];
        _loginBtn.backgroundColor = [UIColor colorWithRed:0.31 green:0.89 blue:0.92 alpha:1];
        [_loginBtn setTitleColor:[UIColor colorWithRed:0.18 green:0.55 blue:1.00 alpha:0.5] forState:UIControlStateHighlighted];
    }
    return _loginBtn;
}

- (UIButton *)forgetPasswordBtn
{
    if (!_forgetPasswordBtn) {
        _forgetPasswordBtn = [[UIButton alloc] initWithFrame: self.loginFrame.forgetPasswordBtnFrame];
        [_forgetPasswordBtn setTitle:@"忘记密码" forState:UIControlStateNormal];
        _forgetPasswordBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    }
    return _forgetPasswordBtn;
}

- (JZpromptLabel *)promptLabel
{
    if (!_promptLabel) {
        _promptLabel = [[JZpromptLabel alloc] init];
    }
    return _promptLabel;
}

- (UIView *)leftLineView
{
    if (!_leftLineView) {
        _leftLineView = [[UIView alloc] initWithFrame:self.loginFrame.leftLineFrame];
        _leftLineView.backgroundColor = [UIColor whiteColor];
    }
    return _leftLineView;
}

- (UIView *)rightLineView
{
    if (!_rightLineView) {
        _rightLineView = [[UIView alloc] initWithFrame:self.loginFrame.rightLineFrame];
        _rightLineView.backgroundColor = [UIColor whiteColor];
    }
    return _rightLineView;
}

- (UILabel *)otherLoginWayLabel
{
    if (!_otherLoginWayLabel) {
        _otherLoginWayLabel = [[UILabel alloc] initWithFrame:self.loginFrame.otherLoginWayFrame];
        _otherLoginWayLabel.text = @"其他登录方式";
        _otherLoginWayLabel.textAlignment = NSTextAlignmentCenter;
        _otherLoginWayLabel.textColor = [UIColor whiteColor];
        _otherLoginWayLabel.adjustsFontSizeToFitWidth =YES;
    }
    return _otherLoginWayLabel;
}

- (UIButton *)visitorsBtn
{
    if (!_visitorsBtn) {
        _visitorsBtn = [[UIButton alloc] initWithFrame:self.loginFrame.visitorsImageFrame];
        _visitorsBtn.layer.cornerRadius = self.loginFrame.visitorsImageFrame.size.height / 2;
        _visitorsBtn.layer.masksToBounds = YES;
        _visitorsBtn.layer.borderColor = [UIColor whiteColor].CGColor;
        _visitorsBtn.layer.borderWidth = 1.f;
        [_visitorsBtn setImage:[UIImage imageNamed:@"游客"] forState:UIControlStateNormal];
    }
    return _visitorsBtn;
}

- (UILabel *)visitorLabel
{
    if (!_visitorLabel) {
        _visitorLabel = [[UILabel alloc] initWithFrame:self.loginFrame.visitorFrame];
        _visitorLabel.textColor = [UIColor whiteColor];
        _visitorLabel.textAlignment = NSTextAlignmentCenter;
        _visitorLabel.text = @"游客";
        _visitorLabel.adjustsFontSizeToFitWidth =YES;

    }
    return _visitorLabel;
}

- (JZrememberPasswordView *)rememberPasswordView
{
    if (!_rememberPasswordView) {
        _rememberPasswordView = [[JZrememberPasswordView alloc] initWithFrame:self.loginFrame.rememberPasswordFrame];
    }
    return _rememberPasswordView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.backgroundImageView];
        [self addSubview:self.logoImageView];
        [self addSubview:self.userLabel];
        [self addSubview:self.userTF];
        [self addSubview:self.passwordLabel];
        [self addSubview:self.passwordTF];
        [self addSubview:self.loginBtn];
        [self addSubview:self.forgetPasswordBtn];
        [self addSubview:self.leftLineView];
        [self addSubview:self.otherLoginWayLabel];
        [self addSubview:self.rightLineView];
        [self addSubview:self.visitorsBtn];
        [self addSubview:self.visitorLabel];
        [self addSubview:self.rememberPasswordView];
    }
    return self;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.userTF resignFirstResponder];
    [self.passwordTF resignFirstResponder];
    [self.promptLabel removeFromSuperview];
}




































@end
