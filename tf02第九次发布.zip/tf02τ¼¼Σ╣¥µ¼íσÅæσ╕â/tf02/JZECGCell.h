//
//  JZECGCell.h
//  tf02
//
//  Created by F7686324 on 27/10/2016.
//  Copyright © 2016 Jim. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JZECGDataView.h"
#import "JZECGScrollView.h"
@interface JZECGCell : UITableViewCell
{
    CGFloat ratio;
    CGFloat smallSpace;
    CGFloat bigSpace;
    CGFloat space;
}

@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) JZECGDataView *dataView;
@property (nonatomic, strong) JZECGScrollView *scrollView;
@property (nonatomic, strong) UILabel *lblTurns;
@property (nonatomic, strong) UILabel *lblUnit;

+(JZECGCell *)ECGCellWithTableView:(UITableView *)tableView;

@end
