//
//  JZHealthIndicatorViewController.m
//  tf02
//
//  Created by Jim on 16/3/10.
//  Copyright © 2016年 Jim. All rights reserved.
//

#import "JZHealthIndicatorViewController.h"
#import "JZLoginViewController.h"
#import "Utility.h"

@interface JZHealthIndicatorViewController () <JZLineChartViewDelegate>
{
    BOOL bpEndRefresh;
    BOOL hrEndRefresh;
    BOOL bsEndRefresh;
    BOOL bfEndRefresh;
    BOOL wEndRefresh;
    BOOL oEndRefresh;
}
@end

@implementation JZHealthIndicatorViewController

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (JZHealthIndicatorView *)healthIndicatorView
{
    if (!_healthIndicatorView) {
        _healthIndicatorView = [[JZHealthIndicatorView alloc] initWithFrame:CGRectMake(0, 0, screenW, screenH)];

        _healthIndicatorView.bloodPressureView.delegate = self;
        _healthIndicatorView.heartRateView.delegate = self;
        _healthIndicatorView.bloodSugarView.delegate = self;
        _healthIndicatorView.weightView.delegate = self;
        _healthIndicatorView.bloodFatView.delegate = self;
        _healthIndicatorView.oxygenView.delegate = self;

        //给分段卡添加事件并显示分段卡
        [_healthIndicatorView.segmentControl addTarget:self action: @selector(nextStep:) forControlEvents: UIControlEventValueChanged];
        _healthIndicatorView.tbView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{


            if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 0) {
                NSLog(@"显示天的数据");
                _healthIndicatorView.timeLengthString = jzDay;

            } else if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 1) {
                NSLog(@"显示周的数据");
                _healthIndicatorView.timeLengthString = jzWeek;

            } else if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 2) {
                NSLog(@"显示月的数据");
                _healthIndicatorView.timeLengthString = jzMonth;

            } else if ([[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex] == 3) {
                NSLog(@"显示年的数据");
                _healthIndicatorView.timeLengthString = jzYear;
                
            }
        }];

    }
    return _healthIndicatorView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = appBackgroundColor;
    NSString *colorType = @"灰";
    [colorType storeValueByKey:JZRefreshColor];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
        UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, screenH / 3, screenW, 20)];
        lbl.text = @"游客模式";
        lbl.textColor = [UIColor grayColor];
        lbl.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:lbl];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, screenH / 3 + 20, screenW, 20)];
        label.text = @"无法显示当前数据";
        label.textColor = [UIColor grayColor];
        label.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:label];
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake((screenW - 80) / 2, screenH / 3 + 80, 80, 30)];
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
        [btn setTitle:@"登录" forState:UIControlStateNormal];
        btn.layer.cornerRadius = 15;
        btn.layer.masksToBounds = YES;
        btn.backgroundColor = [UIColor colorWithRed:0.19 green:0.89 blue:0.91 alpha:1.00];
        [btn addTarget:self action:@selector(clickLoginBtn) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btn];
    } else {
        [self.view addSubview:self.healthIndicatorView];
        bpEndRefresh = NO;
        hrEndRefresh = NO;
        oEndRefresh = NO;
        wEndRefresh = NO;
        bsEndRefresh = NO;
        bfEndRefresh = NO;
        UIImageView *imgView = [[UIImageView alloc] initWithFrame: CGRectMake(0, 0, 30, 30)];
        imgView.backgroundColor = [UIColor whiteColor];
        imgView.layer.cornerRadius = 15;
        imgView.layer.masksToBounds = YES;
        imgView.layer.borderWidth = 1.f;
        imgView.layer.borderColor = [UIColor whiteColor].CGColor;

        if ([[NSString valueByKey:kVisitors] isEqualToString:@"visitors"]) {
            imgView.image = [UIImage imageNamed:@"游客"];
        } else {
            JZPersonInfo *currentPersonInfo = [JZPersonInfo valueByKey: kCurrentFamilyMemberInfo];
            [imgView sd_setImageWithURL:[NSURL URLWithString:[currentPersonInfo picture]] placeholderImage:[UIImage imageNamed:@"默认"]];
            [self.healthIndicatorView.segmentControl removeAllSegments];
            [self.healthIndicatorView.segmentControl insertSegmentWithTitle: @"天" atIndex:0 animated: YES];
            [self.healthIndicatorView.segmentControl insertSegmentWithTitle: @"周" atIndex:1 animated: YES];
            [self.healthIndicatorView.segmentControl insertSegmentWithTitle: @"月" atIndex:2 animated: YES];
            [self.healthIndicatorView.segmentControl insertSegmentWithTitle: @"年" atIndex:3 animated: YES];

            NSInteger segmentIndex = [[NSUserDefaults standardUserDefaults] integerForKey:kSegmentIndex];

            self.healthIndicatorView.segmentControl.selectedSegmentIndex = segmentIndex;

            JZRefreshInfo *refreshInfo = [JZRefreshInfo valueByKey:kRefreshInfo];

            if (refreshInfo.canHealthIndicatorRefresh) {

                [self.healthIndicatorView.tbView.mj_header beginRefreshing];
                refreshInfo.canHealthIndicatorRefresh = NO;
                [refreshInfo storeValueByKey:kRefreshInfo];
            } else {
                NSString *timeLengthString;
                switch (segmentIndex) {
                    case 0:
                        timeLengthString = jzDay;
                        break;
                    case 1:
                        timeLengthString = jzWeek;
                        break;
                    case 2:
                        timeLengthString = jzMonth;
                        break;
                    case 3:
                        timeLengthString = jzYear;
                        break;
                    default:
                        timeLengthString = jzWeek;
                        break;
                }

                self.healthIndicatorView.timeLengthString = timeLengthString;
            }

            [[NSUserDefaults standardUserDefaults] setInteger: self.healthIndicatorView.segmentControl.selectedSegmentIndex forKey: kSegmentIndex];
            [[NSUserDefaults standardUserDefaults] synchronize];

        }

        UIBarButtonItem *iconButton = [[UIBarButtonItem alloc]initWithCustomView: imgView];
        self.tabBarController.navigationItem.rightBarButtonItem = iconButton;
    }
}

// segment
- (void)nextStep: (UISegmentedControl *)segment
{
    if (segment.selectedSegmentIndex == 0) {
        NSLog(@"显示天的数据");
        self.healthIndicatorView.timeLengthString = jzDay;

    } else if (segment.selectedSegmentIndex == 1) {
        NSLog(@"显示周的数据");
        self.healthIndicatorView.timeLengthString = jzWeek;

    } else if (segment.selectedSegmentIndex == 2) {
        NSLog(@"显示月的数据");
        self.healthIndicatorView.timeLengthString = jzMonth;

    } else if (segment.selectedSegmentIndex == 3) {
        NSLog(@"显示年的数据");
        self.healthIndicatorView.timeLengthString = jzYear;

    }
    [[NSUserDefaults standardUserDefaults] setInteger:segment.selectedSegmentIndex forKey: kSegmentIndex];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark JZLineChartViewDelegate Methods
- (void)handleSingleTapGesture:(UITapGestureRecognizer *)tap lineChartView:(JZLineChartView *)lineChartView
{
    if (lineChartView.bigDataArray.count) {
        JZHealthDataViewController *healthDataVC = [[JZHealthDataViewController alloc] init];
        healthDataVC.jzType = lineChartView.jzType;
        healthDataVC.detailDataArray = lineChartView.dataArray;
        healthDataVC.timeLengthString = self.healthIndicatorView.timeLengthString;

        [self.tabBarController.navigationController pushViewController:healthDataVC animated:YES];

    }
}

- (void)endMJRefreshWithLineChartView:(JZLineChartView *)lineChartView
{
    if ([lineChartView.jzType isEqualToString:@"血压"]) {
        bpEndRefresh = YES;
    } else if ([lineChartView.jzType isEqualToString:@"心率"]) {
        hrEndRefresh = YES;
    } else if ([lineChartView.jzType isEqualToString:@"血糖"]) {
        bsEndRefresh = YES;
    } else if ([lineChartView.jzType isEqualToString:@"体重"]) {
        wEndRefresh = YES;
    } else if ([lineChartView.jzType isEqualToString:@"血氧"]) {
        oEndRefresh = YES;
    } else if ([lineChartView.jzType isEqualToString:@"体脂"]) {
        bfEndRefresh = YES;
    }
    if (bfEndRefresh & bpEndRefresh & bsEndRefresh & wEndRefresh & oEndRefresh & hrEndRefresh) {
        bpEndRefresh = NO;
        hrEndRefresh = NO;
        oEndRefresh = NO;
        wEndRefresh = NO;
        bsEndRefresh = NO;
        bfEndRefresh = NO;
        [self.healthIndicatorView.tbView.mj_header endRefreshing];
    }
}

- (void)clickLoginBtn
{
    JZLoginViewController *loginVC = [[JZLoginViewController alloc] init];
    [UIApplication sharedApplication].keyWindow.rootViewController = loginVC;
}




























@end
