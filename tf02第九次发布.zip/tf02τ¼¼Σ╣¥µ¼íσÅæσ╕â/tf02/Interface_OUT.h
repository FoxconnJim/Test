//
//  Interface_OUT.h
//  tf02
//
//  Created by F7686324 on 9/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#ifndef Interface_OUT_h
#define Interface_OUT_h

#pragma mark 数据接口
#define bloodPressureURL @"http://120.76.233.207/TF02/V2/medicaldata/bloodpressure/list"
#define heartRateURL @"http://120.76.233.207/TF02/V2/medicaldata/heartrate/list"
#define bloodSugarURL @"http://120.76.233.207/TF02/V2/medicaldata/bloodsugar/list"
#define bodyFatURL @"http://120.76.233.207/TF02/V2/medicaldata/bodyfat/list"
#define oxygenURL @"http://120.76.233.207/TF02/V2/medicaldata/bloodraise/list"

#define usersLoginURL @"http://120.76.233.207/TF02/V2/account/familyaccount/login"
#define changePwdByTel @"http://120.76.233.207/TF02/V2/account/pwdbytel/update"
#define changePwdByMail @"http://120.76.233.207/TF02/V2/account/pwdbymail/update"
#define usersRegisterURL @"http://120.76.233.207/TF02/V2/account/familyaccount/create"
#define bindChannelId @"http://120.76.233.207/TF02/V2/push/messagepush/create"

#define getHeartRateURL @""
#define findAllFamilyMembersURL @"http://120.76.233.207/TF02/V2/info/allfamilymembers/list"
#define listCareNewsBySecondURL @"http://120.76.233.207/TF02/news/listCareNewsBySecond.json"
#define todayrecommendURL @"http://120.76.233.207/TF02/V2/news/todayrecommend/list"
#define moretodayrecommendURL @"http://120.76.233.207/TF02/V2/news/moretodayrecommend/list"
#define todayRemindURL @"http://120.76.233.207/TF02/V2/remind/todayremind/list"
#define historyRemindMemberURL @"http://120.76.233.207/TF02/V2/remind/alltodayremind/list"
#define historyRemindURL @"http://120.76.233.207/TF02/V2/remind/historyremind"

#define chunyuyishengHLZXURL @"https://www.chunyuyisheng.com/health_news/?vendor=foxconn"
#define chunyuyishengJYZXURL @"https://www.chunyuyisheng.com/cooperation/wap/login/"
#define xianshangyaojuURL @"http://m.111.com.cn"
#define weatherURL @"http://apicloud.mob.com/v1/weather/query"
#define cityListURL @"http://apicloud.mob.com/v1/weather/citys"

#define hulizixunNewsURL @"http://120.76.233.207/TF02/V2/news/carenewsbysecond/list"
#define hulizixunADURL @"http://120.76.233.207/TF02/V2/news/carenewsad/list"
#define shoucangURL @"http://120.76.233.207/TF02/V2/collect/newscollect/create"
#define wethercollectionURL @"http://120.76.233.207/TF02/V2/remind/infocollect"
#define cancelshoucangURL @"http://120.76.233.207/TF02/V2/collect/newscollect/delete"
#define loadshoucangURL @"http://120.76.233.207/TF02/V2/collect/newscollect/list"

#define familyaccountbymailURL @"http://120.76.233.207/TF02/V2/account/familyaccountbymail/validate"
#define familyaccountbytelURL @"http://120.76.233.207/TF02/V2/account/familyaccountbytel/validate"
#define findBackPasswordByMailURL @""

#define healthServiceADURL @"http://120.76.233.207/TF02/V2/news/healthservicead/list"

#define submitFeedbackURL @"http://120.76.233.207/TF02/V2/feedback/backinfo/create"
#define getHelplistURL @"http://120.76.233.207/TF02/V2/help/answer/list"
#endif /* Interface_OUT_h */
