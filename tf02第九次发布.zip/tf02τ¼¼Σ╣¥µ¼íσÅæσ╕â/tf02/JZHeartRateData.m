//
//  JZHeartRateData.m
//  tf02
//
//  Created by AN PEN on 7/19/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZHeartRateData.h"

@implementation JZHeartRateData
- (instancetype)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super initWithDictionary:dict]) {
        self.data = [NSString stringWithFormat:@"%@", dict[@"ecgdata"]];
        self.eegdata = [NSString stringWithFormat:@"%@", dict[@"eegdata"]];
        self.numberturns = [NSString stringWithFormat:@"%@", dict[@"numberturns"]];
        self.physicalstate = [NSString stringWithFormat:@"%@", dict[@"physicalstate"]];
        if (self.physicalstate.integerValue == 0) {
            self.physicalstate = @"运动 (运动后身心还未平稳)";
        } else {
            self.physicalstate = @"其他 (除上述情况外正常测量)";
        }
    }
    return self;
}

@end
