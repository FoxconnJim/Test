//
//  JZPersonInfo.m
//  tf02
//
//  Created by AN PEN on 5/17/16.
//  Copyright © 2016 Jim. All rights reserved.
//

#import "JZPersonInfo.h"
#import "NSString+DateFormatter.h"

@implementation JZPersonInfo

- (instancetype)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.address = [dict[@"address"] isEqualToString:@""] ? @"请完善" : dict[@"address"];
        self.allergic = [dict[@"allergic"] isEqualToString:@""] ? @"请完善" : dict[@"allergic"];
        
        self.birthday = [[dict[@"birthday"] turnServiceToMyFormatter] substringToIndex:10];
        
        self.bloodType = [NSString stringWithFormat: @"%@", dict[@"bloodType"]];
        self.createtime = [NSString stringWithFormat: @"%@", dict[@"createtime"]];

        self.delflag = [NSString stringWithFormat: @"%@", dict[@"delflag"]];
        self.family = [dict[@"family"] isEqualToString:@""] ? @"请完善" : dict[@"family"];
        self.height = [NSString stringWithFormat: @"%@", dict[@"height"]];
        self.weight = [NSString stringWithFormat: @"%@", dict[@"weight"]];

        self.history = [dict[@"history"] isEqualToString:@""] ? @"请完善" : dict[@"history"];
        self.home = [dict[@"home"] isEqualToString:@""] ? @"请选择" : dict[@"home"];

        self.idCard = [NSString stringWithFormat: @"%@", dict[@"idCard"]];
        self.idType = [NSString stringWithFormat: @"%@", dict[@"idType"]];
        self.job = [dict[@"job"] isEqualToString:@""] ? @"请完善" : dict[@"job"];
        self.marryStatus = [dict[@"marryStatus"] isEqualToString:@"1"] ? @"未婚" : @"已婚";
        self.membersname = [NSString stringWithFormat: @"%@", dict[@"membersname"]];

        self.nickname = [NSString stringWithFormat: @"%@", dict[@"nickname"]];
        self.picture = [NSString stringWithFormat: @"%@", dict[@"picture"]];
        self.sex = [[NSString stringWithFormat: @"%@", dict[@"sex"]] isEqualToString: @"1"] ? @"女" : @"男";
        self.socialCard = [dict[@"socialCard"] isEqualToString:@""] ? @"请完善" : dict[@"socialCard"];
        self.tel = [NSString stringWithFormat: @"%@", dict[@"tel"]];
        self.memberId = [NSString stringWithFormat:@"%@", dict[@"id"]];
    }
    return self;
}

+ (instancetype)personInfoWithDict:(NSDictionary *)dict
{
    return [[self alloc] initWithDict: dict];
}

@end

