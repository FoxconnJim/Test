//
//  ViewController.m
//  CHTest
//
//  Created by F7686324 on 9/10/16.
//  Copyright © 2016 foxconn.com. All rights reserved.
//

#import "ViewController.h"

#import "JZDrawerViewController.h"
#import "JZMainViewController.h"
#import "JZMenuViewController.h"
@interface ViewController ()

@property (nonatomic, strong) JZDrawerViewController *drawerVC;
@property (nonatomic, strong) JZMainViewController *main;
@property (nonatomic, strong) JZMenuViewController *menu;
@end

@implementation ViewController

- (JZMainViewController *)main
{
    if (!_main) {
        _main = [[JZMainViewController alloc] init];
    }
    return _main;
}

- (JZMenuViewController *)menu
{
    if (!_menu) {
        _menu = [[JZMenuViewController alloc] init];
    }
    return _menu;
}

- (JZDrawerViewController *)drawerVC
{
    if (!_drawerVC) {
        _drawerVC = [[JZDrawerViewController alloc] init];
        UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController: self.main];
        
        [_drawerVC configureWithMainViewController: navi andMenuViewController: self.menu];
    }
    return _drawerVC;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 40, 30)];
    btn.backgroundColor = [UIColor greenColor];
    [self.view addSubview: btn];
    [btn addTarget: self  action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
}

- (void)click {
    self.drawerVC.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    [self presentViewController: self.drawerVC animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
