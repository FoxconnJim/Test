//
//  JZDrawerViewController.h
//  CHTest
//
//  Created by F7686324 on 9/10/16.
//  Copyright © 2016 foxconn.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JZDrawerViewController : UIViewController

@property (nonatomic, strong) UIViewController *mainVC;
@property (nonatomic, strong) UIViewController *menuVC;
@property (nonatomic, strong) UIView *mainView;
@property (nonatomic, strong) UIView *menuView;

@property (nonatomic) BOOL openMenu;

- (void)configureWithMainViewController: (UIViewController *)mainViewController andMenuViewController: (UIViewController *)menuViewController;

@end
