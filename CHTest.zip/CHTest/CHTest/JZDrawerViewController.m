//
//  JZDrawerViewController.m
//  CHTest
//
//  Created by F7686324 on 9/10/16.
//  Copyright © 2016 foxconn.com. All rights reserved.
//

#import "JZDrawerViewController.h"
#import "JZMainViewController.h"
#import "JZHomeViewController.h"

@interface JZDrawerViewController ()

@end

@implementation JZDrawerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)configureWithMainViewController:(UIViewController *)mainViewController andMenuViewController:(UIViewController *)menuViewController {

    _mainVC = mainViewController;
    _menuVC = menuViewController;

    _mainView = mainViewController.view;
    _menuView = menuViewController.view;
    [self.view addSubview: _menuView];
    [self.view addSubview: _mainView];


    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget: self action:@selector(handlePanGesture:)];
    [self.view addGestureRecognizer: panGesture];
}

- (void)handlePanGesture: (UIPanGestureRecognizer *)sender {
    
    CGPoint translation = [sender translationInView: self.view];

    NSLog(@"translation.x = %ld", (long)translation.x);

    CGRect mainFrame = _mainView.frame;

    if ([sender state] == UIGestureRecognizerStateBegan) {

        [sender setTranslation: mainFrame.origin inView: self.view];
    }

    if ([sender state] == UIGestureRecognizerStateChanged) {

        mainFrame.origin.x = translation.x;
    }

    if (mainFrame.origin.x > [UIScreen mainScreen].bounds.size.width - 75) {

        mainFrame.origin.x = [UIScreen mainScreen].bounds.size.width - 75;
    }

    if (mainFrame.origin.x < 0) {

        mainFrame.origin.x = 0;
    }

    _mainView.frame = mainFrame;

    if ([sender state] == UIGestureRecognizerStateEnded) {

        if (mainFrame.origin.x > [UIScreen mainScreen].bounds.size.width / 2) {

            [UIView animateWithDuration: 0.2 animations: ^{

                _mainView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 75, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);

            }];
        } else {

            [UIView animateWithDuration: 0.2 animations: ^{

                _mainView.frame = [UIScreen mainScreen].bounds;

            }];
        }

        CGPoint velocity = [sender velocityInView: self.view];
        NSLog(@"velocity.x = %ld", (long)velocity.x);

        if (velocity.x > 500) {
            [UIView animateWithDuration: 0.2 animations: ^{

                _mainView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 75, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);

            }];
        } else if (velocity.x < -500) {

            [UIView animateWithDuration: 0.2  animations: ^{

                _mainView.frame = [UIScreen mainScreen].bounds;
                
            }];
        }
    }

}




@end



















































