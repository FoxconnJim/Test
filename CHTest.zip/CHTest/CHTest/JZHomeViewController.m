//
//  JZHomeViewController.m
//  CHTest
//
//  Created by F7686324 on 9/12/16.
//  Copyright © 2016 foxconn.com. All rights reserved.
//

#import "JZHomeViewController.h"
#import "subViewController.h"

@interface JZHomeViewController ()
@property (nonatomic, strong) subViewController *subView;

@end

@implementation JZHomeViewController

- (subViewController *)subView
{
    if (!_subView) {
        _subView = [[subViewController alloc] init];
    }
    return _subView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor brownColor];
    self.title = @"hVC";

    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(100, 100, 40, 30)];
    btn.backgroundColor = [UIColor greenColor];
    [self.view addSubview: btn];
    [btn addTarget: self  action:@selector(aclick) forControlEvents:UIControlEventTouchUpInside];
}
- (void)aclick {

    [self.navigationController pushViewController: self.subView animated: YES];
    
}


@end
