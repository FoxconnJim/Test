//
//  JZMainViewController.m
//  CHTest
//
//  Created by F7686324 on 9/12/16.
//  Copyright © 2016 foxconn.com. All rights reserved.
//

#import "JZMainViewController.h"
#import "JZHomeViewController.h"
@interface JZMainViewController () <UITabBarControllerDelegate>
@property (nonatomic, strong) JZHomeViewController *hVC;
@end

@implementation JZMainViewController

- (JZHomeViewController *)hVC
{
    if (!_hVC) {
        _hVC = [[JZHomeViewController alloc] init];

    }
    return _hVC;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    UIViewController *aVC = [[UIViewController alloc] init];
    aVC.tabBarItem.title = @"aVC";
    aVC.title = @"aVC";
    aVC.view.backgroundColor = [UIColor blueColor];

    UIViewController *bVC = [[UIViewController alloc] init];
    bVC.tabBarItem.title = @"bVC";
    aVC.title = @"bVC";

    bVC.view.backgroundColor = [UIColor redColor];

    UIViewController *cVC = [[UIViewController alloc] init];
    cVC.tabBarItem.title = @"cVC";
    aVC.title = @"cVC";

    cVC.view.backgroundColor = [UIColor cyanColor];

    self.tabBar.translucent = NO;
    self.tabBar.itemPositioning = UITabBarItemPositioningFill;
    self.delegate = self;
    self.viewControllers = @[self.hVC, aVC, bVC, cVC];
    self.title = @"hVC";
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {

    if (self.selectedIndex == 0) {
        tabBarController.navigationItem.title = @"hVC";
    } else if (self.selectedIndex == 1) {
        tabBarController.navigationItem.title = @"aVC";
    } else if (self.selectedIndex == 2) {
        tabBarController.navigationItem.title = @"bVC";
    } else if (self.selectedIndex == 3) {
        tabBarController.navigationItem.title = @"cVC";
    }
}







































@end
